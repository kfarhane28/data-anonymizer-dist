# Legal notices

## Proprietary software

**Data Anonymizer** is proprietary software owned by **MagicByte Consulting**.

- Copyright (c) 2026 MagicByte Consulting. All rights reserved.
- Use is governed by the license terms included with the distribution (see `LICENSE` and `EULA.md`).
- The Free edition is **not** open source; it is provided under proprietary terms without a license key.
- The Pro/Premium edition requires a valid commercial license key and applicable commercial terms.

## Trademarks

“MagicByte Consulting” and “Data Anonymizer” may be trademarks of MagicByte Consulting. All other trademarks are the property of their respective owners.

## Contact (placeholders)

- Licensing / sales: `sales@magicbyte.example`
- Support: `support@magicbyte.example`
