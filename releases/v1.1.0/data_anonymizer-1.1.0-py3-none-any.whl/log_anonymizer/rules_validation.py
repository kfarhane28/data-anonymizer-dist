from __future__ import annotations
import json
from typing import Any
from log_anonymizer.rule_actions import parse_action

def validate_rules_json_bytes(raw: bytes) -> str | None:
    """
    Validate that rules.json bytes are UTF-8 JSON and match a supported schema.

    Supported:
    - version 1 (legacy): rule uses `search` + `replace`
    - version 2 (action-based): rule uses `search` + `action`

    Notes:
    - This is intentionally stricter than the runtime loader in non-strict mode, because UIs
      should surface configuration errors early and clearly.
    - The runtime loader (`log_anonymizer.rules_loader.load_rules`) is the source of truth.
    """
    try:
        _o3 = json.loads(raw.decode('utf-8'))
    except UnicodeDecodeError:
        return 'not valid UTF-8'
    except json.JSONDecodeError as exc:
        return f'invalid JSON: {_o1}'
    if not isinstance(_o3, dict):
        return 'root must be a JSON object'
    _o9 = _o3.get('version', 1)
    try:
        _o8 = int(_o9)
    except Exception:
        return 'version must be 1 or 2'
    if _o8 not in (1, 2):
        return 'version must be 1 or 2'
    _o6 = _o3.get('rules')
    if not isinstance(_o6, list):
        return 'rules must be a list'
    for _o2, _o4 in enumerate(_o6):
        if not isinstance(_o4, dict):
            return f'rules[{_o2}] must be an object'
        _o7 = _o4.get('search')
        if not isinstance(_o7, str) or not _o7.strip():
            return f'rules[{_o2}].search must be a non-empty string'
        if 'trigger' in _o4 and _o4['trigger'] is not None and (not isinstance(_o4['trigger'], str)):
            return f'rules[{_o2}].trigger must be a string'
        if 'description' in _o4 and _o4['description'] is not None and (not isinstance(_o4['description'], str)):
            return f'rules[{_o2}].description must be a string'
        if 'caseSensitive' in _o4 and _o4['caseSensitive'] is not None and (not isinstance(_o4['caseSensitive'], (str, bool, int, float))):
            return f'rules[{_o2}].caseSensitive must be boolean or string'
        _o0 = _o4.get('action')
        if _o0 is not None:
            try:
                parse_action(_o0)
            except Exception as exc:
                return f'rules[{_o2}].action invalid: {_o1}'
            continue
        if 'replace' not in _o4:
            return f"rules[{_o2}] missing 'replace' (or provide 'action')"
        _o5 = _o4.get('replace')
        if _o5 is not None and (not isinstance(_o5, str)):
            return f'rules[{_o2}].replace must be a string'
    return None
