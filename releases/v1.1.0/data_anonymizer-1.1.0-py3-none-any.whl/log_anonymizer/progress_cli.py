from __future__ import annotations
import sys
import threading
import time
from dataclasses import dataclass
from queue import Empty, Queue
from typing import TextIO
from log_anonymizer.progress import ProgressEvent, ProgressKind, ProgressStage, ProgressStopToken

@dataclass
class _CliProgressState:
    stage: ProgressStage | None = None
    stage_current: int | None = None
    stage_total: int | None = None
    stage_message: str | None = None
    last_file_path: str | None = None
    last_file_done: int | None = None
    last_file_total: int | None = None
    last_render: float = 0.0

def start_cli_progress_thread(q: Queue[ProgressEvent], stop: ProgressStopToken, *, stream: TextIO | None=None, min_render_interval_s: float=0.1) -> threading.Thread:
    """
    Consume ProgressEvent from `q` and render a single-line progress indicator to `stream`.

    Rendering goes to stderr by default to avoid corrupting stdout output (logs / final path).
    """
    out = stream or sys.stderr
    state = _CliProgressState()

    def _render(force_newline: bool=False) -> None:
        _o3 = time.monotonic()
        if not force_newline and _o3 - state.last_render < min_render_interval_s:
            return
        state.last_render = _o3
        if state.stage is None:
            return
        _o6 = state.stage.value
        if state.stage_total is not None and state.stage_current is not None:
            _o5 = int(100 * state.stage_current / state.stage_total) if state.stage_total > 0 else 100
            _o1 = f'{_o6}: {state.stage_current}/{state.stage_total} ({_o5}%)'
        elif state.stage_current is not None:
            _o1 = f'{_o6}: {state.stage_current}'
        else:
            _o1 = f'{_o6}'
        _o7: list[str] = []
        if state.stage_message:
            _o7.append(state.stage_message)
        if state.last_file_path and state.last_file_done is not None and (state.last_file_total is not None) and (state.last_file_total > 0):
            _o0 = int(100 * state.last_file_done / state.last_file_total)
            _o7.append(f'file={state.last_file_path} {_o0}%')
        elif state.last_file_path:
            _o7.append(f'file={state.last_file_path}')
        _o2 = _o1
        if _o7:
            _o2 += ' | ' + ' '.join(_o7)
        _o4 = ' ' * 20
        out.write('\r' + _o2 + _o4)
        out.flush()
        if force_newline:
            out.write('\n')
            out.flush()

    def _loop() -> None:
        _o1: ProgressStage | None = None
        while True:
            if stop.is_stopped() and q.empty():
                break
            try:
                _o0 = q.get(timeout=0.1)
            except Empty:
                _render()
                continue
            if _o0.kind in (ProgressKind.STAGE_START, ProgressKind.STAGE_PROGRESS, ProgressKind.STAGE_END):
                state.stage = _o0.stage
                state.stage_current = _o0.current
                state.stage_total = _o0.total
                state.stage_message = _o0.message
                if _o0.kind == ProgressKind.STAGE_START:
                    state.last_file_path = None
                    state.last_file_done = None
                    state.last_file_total = None
            if _o0.kind == ProgressKind.FILE_START:
                state.last_file_path = _o0.path
                state.last_file_done = _o0.bytes_done
                state.last_file_total = _o0.bytes_total
            if _o0.kind == ProgressKind.FILE_PROGRESS:
                state.last_file_path = _o0.path
                state.last_file_done = _o0.bytes_done
                state.last_file_total = _o0.bytes_total
            if _o0.kind == ProgressKind.FILE_END:
                state.last_file_path = _o0.path
                if _o0.bytes_total is not None:
                    state.last_file_done = _o0.bytes_total
                    state.last_file_total = _o0.bytes_total
            if _o0.stage != _o1 and _o1 is not None:
                _render(force_newline=True)
            _o1 = _o0.stage
            if _o0.kind == ProgressKind.STAGE_END and _o0.stage in (ProgressStage.ARCHIVE, ProgressStage.PROCESSING):
                _render(force_newline=True)
            else:
                _render()
        _render(force_newline=True)
    _o0 = threading.Thread(target=_loop, name='cli-progress', daemon=True)
    _o0.start()
    return _o0
