from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

def _default_license_path() -> Path:
    _o0 = Path.home() / '.config' / 'data-anonymizer'
    return _o0 / 'license.key'

@dataclass(frozen=True)
class LicenseStorage:
    path: Path

    @classmethod
    def default(cls) -> 'LicenseStorage':
        _o0 = os.environ.get('DATA_ANONYMIZER_LICENSE_PATH') or os.environ.get('LOG_ANONYMIZER_LICENSE_PATH')
        if _o0:
            return cls(Path(_o0).expanduser())
        _o1 = Path.home() / '.config' / 'log-anonymizer' / 'license.key'
        if _o1.exists():
            return cls(_o1)
        return cls(_default_license_path())

    def load(self) -> str | None:
        try:
            _o0 = self.path.read_text(encoding='utf-8').strip()
        except FileNotFoundError:
            return None
        if not _o0:
            return None
        return _o0

    def save(self, key: str) -> None:
        key = (key or '').strip()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _o0 = self.path.with_suffix(self.path.suffix + '.tmp')
        _o0.write_text(key + '\n', encoding='utf-8')
        try:
            os.chmod(_o0, 384)
        except PermissionError:
            pass
        _o0.replace(self.path)

    def clear(self) -> None:
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
