from __future__ import annotations
PUBLIC_KEY_B64 = 'GjRsBFGmhuq1OFhMs8BFItRYRIhVNIzvdXzya6l3M4g='
