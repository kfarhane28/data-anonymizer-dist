from __future__ import annotations
from enum import Enum

class FeatureFlag(str, Enum):
    advanced_rules = 'advanced_rules'
    parallel_processing = 'parallel_processing'
    preview_mode = 'preview_mode'
    profiling = 'profiling'
    spark_connect = 'spark_connect'
    partial_cancel_preservation = 'partial_cancel_preservation'
FREE_FEATURES: frozenset[FeatureFlag] = frozenset()
PRO_FEATURES: frozenset[FeatureFlag] = frozenset({FeatureFlag.advanced_rules, FeatureFlag.parallel_processing, FeatureFlag.preview_mode, FeatureFlag.profiling, FeatureFlag.spark_connect, FeatureFlag.partial_cancel_preservation})
