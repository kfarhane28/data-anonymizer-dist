from __future__ import annotations
import fnmatch
import logging
import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable, Pattern
logger = logging.getLogger(__name__)
DEFAULT_EXCLUDE_PATTERNS: tuple[str, ...] = ('creds.localjceks', 'creds.localjceks.sha', '*.jceks', '*.jceks.sha', '*.keytab', 'krb5.conf', 'jaas.conf', '*.jks', '*keystore*', '*truststore*', '*.p12', '*.pfx', '*.pem', '*.key', '*.crt', '*.cer', '*.der', '*.kdb')

def load_patterns(exclude_file: Path) -> list[str]:
    """
    Load glob-style exclude patterns from a `.exclude` file.

    - Blank lines are ignored
    - Lines starting with `#` are ignored
    """
    _o1 = exclude_file.read_text(encoding='utf-8').splitlines()
    _o2: list[str] = []
    for _o0 in _o1:
        _o3 = _o0.strip()
        if not _o3 or _o3.startswith('#'):
            continue
        _o2.append(_o3)
    return _o2

@dataclass(frozen=True)
class ExcludeFilter:
    """
    Fast matcher for glob-style exclude patterns.

    Matching strategy:
    - Match patterns against:
        - absolute POSIX path
        - relative POSIX path (relative to `base_dir`, if provided and possible)
        - basename
    - Optionally case-insensitive matching
    """
    patterns: tuple[str, ...]
    base_dir: Path | None = None
    case_insensitive: bool = False
    _compiled: tuple[Pattern[str], ...] = ()
    _negate: tuple[bool, ...] = ()

    @classmethod
    def from_file(cls, exclude_file: Path, *, base_dir: Path | None=None, case_insensitive: bool=False) -> 'ExcludeFilter':
        _o2 = tuple(load_patterns(exclude_file))
        _o0, _o1 = _compile_globs(_o2, case_insensitive=case_insensitive)
        return cls(patterns=_o2, base_dir=base_dir.resolve() if base_dir is not None else None, case_insensitive=case_insensitive, _compiled=_o0, _negate=_o1)

    @classmethod
    def from_patterns(cls, patterns: Iterable[str], *, base_dir: Path | None=None, case_insensitive: bool=False) -> 'ExcludeFilter':
        _o2 = tuple((p.strip() for p in patterns if p and p.strip()))
        _o0, _o1 = _compile_globs(_o2, case_insensitive=case_insensitive)
        return cls(patterns=_o2, base_dir=base_dir.resolve() if base_dir is not None else None, case_insensitive=case_insensitive, _compiled=_o0, _negate=_o1)

    def should_exclude(self, file_path: Path) -> bool:
        """
        Return True if `file_path` is excluded by patterns.

        Behavior is gitignore-like:
        - patterns are evaluated in order
        - last match wins
        - patterns starting with '!' re-include (negate)
        """
        _o0 = file_path.resolve().as_posix()
        _o1 = file_path.name
        _o2: list[str] = [_o0, _o1]
        if self.base_dir is not None:
            try:
                _o7 = file_path.resolve().relative_to(self.base_dir).as_posix()
                _o2.append(_o7)
            except ValueError:
                pass
        _o2.append(str(PurePosixPath(file_path.as_posix())))
        _o3 = False
        for _o4, _o8 in enumerate(self._compiled):
            _o6 = self.patterns[_o4] if _o4 < len(self.patterns) else '<unknown>'
            _o5 = self._negate[_o4] if _o4 < len(self._negate) else False
            for _o9 in _o2:
                if _o8.fullmatch(_o9):
                    _o3 = not _o5
                    logger.debug('file_excluded_match', extra={'path': _o0, 'pattern': _o6, 'matched': _o9, 'excluded': _o3})
                    break
        return _o3

def default_patterns() -> tuple[str, ...]:
    return DEFAULT_EXCLUDE_PATTERNS

def _compile_globs(patterns: Iterable[str], *, case_insensitive: bool) -> tuple[tuple[Pattern[str], ...], tuple[bool, ...]]:
    _o2 = re.IGNORECASE if case_insensitive else 0
    _o1: list[Pattern[str]] = []
    _o4: list[bool] = []
    for _o5 in patterns:
        _o3 = _o5.startswith('!')
        _o0 = _o5[1:] if _o3 else _o5
        if not _o0:
            continue
        _o6 = fnmatch.translate(_o0)
        _o1.append(re.compile(_o6, flags=_o2))
        _o4.append(_o3)
    return (tuple(_o1), tuple(_o4))
