from __future__ import annotations
import json
import logging
import os
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any

class LogFormat(str, Enum):
    JSON = 'json'
    TEXT = 'text'

@dataclass(frozen=True)
class _LogContext:
    service: str = 'data-anonymizer'
    pid: int = os.getpid()

class JsonFormatter(logging.Formatter):

    def __init__(self, context: _LogContext) -> None:
        super().__init__()
        self._context = context

    def format(self, record: logging.LogRecord) -> str:
        _o0 = _extract_extras(record)
        _o1: dict[str, Any] = {'ts': datetime.now(timezone.utc).isoformat(timespec='milliseconds'), 'level': record.levelname, 'logger': record.name, 'msg': record.getMessage(), 'service': self._context.service, 'pid': self._context.pid}
        if _o0:
            _o1.update(_o0)
        if record.exc_info:
            _o1['exc_info'] = self.formatException(record.exc_info)
        return json.dumps(_o1, ensure_ascii=False)

class TextWithExtrasFormatter(logging.Formatter):
    """
    Human-readable text formatter that appends `extra={...}` fields as key=value.

    This keeps logs scannable while still surfacing structured context like:
    - file_name, rel, path, dest
    - reason, count, remaining
    """

    def __init__(self) -> None:
        super().__init__('%(asctime)s %(levelname)s %(name)s: %(message)s')

    def format(self, record: logging.LogRecord) -> str:
        _o0 = super().format(record)
        _o1 = _extract_extras(record)
        if not _o1:
            return _o0
        _o3: list[str] = []
        for _o2 in sorted(_o1.keys()):
            _o4 = _o1[_o2]
            if isinstance(_o4, (dict, list)):
                _o3.append(f'{_o2}={json.dumps(_o4, ensure_ascii=False)}')
            else:
                _o3.append(f'{_o2}={_o4}')
        return f'{_o0} ' + ' '.join(_o3)

def setup_logging(*, level: str='INFO', log_format: LogFormat=LogFormat.JSON) -> None:
    logging.raiseExceptions = False
    _o2 = logging.getLogger()
    _o2.handlers.clear()
    _o2.setLevel(level.upper())
    _o0 = logging.StreamHandler(stream=sys.stdout)
    if log_format == LogFormat.JSON:
        _o0.setFormatter(JsonFormatter(_LogContext()))
    else:
        _o0.setFormatter(TextWithExtrasFormatter())
    _o2.addHandler(_o0)
    for _o1 in ('urllib3',):
        logging.getLogger(_o1).setLevel(logging.WARNING)

def _extract_extras(record: logging.LogRecord) -> dict[str, Any]:
    _o2 = {'name', 'msg', 'message', 'asctime', 'args', 'levelname', 'levelno', 'pathname', 'filename', 'module', 'exc_info', 'exc_text', 'stack_info', 'lineno', 'funcName', 'created', 'msecs', 'relativeCreated', 'thread', 'threadName', 'processName', 'process', 'taskName'}
    _o1: dict[str, Any] = {}
    for _o0, _o3 in record.__dict__.items():
        if _o0 in _o2 or _o0.startswith('_'):
            continue
        if _o3 is None or isinstance(_o3, (bool, int, float, str, list, dict)):
            _o1[_o0] = _o3
        else:
            _o1[_o0] = str(_o3)
    return _o1
