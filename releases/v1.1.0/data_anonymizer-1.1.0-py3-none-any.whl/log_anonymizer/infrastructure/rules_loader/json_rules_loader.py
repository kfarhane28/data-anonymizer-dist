from __future__ import annotations
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from log_anonymizer.domain.rules import AnonymizationRule, HashConfig, RuleAction, RuleSet

@dataclass(frozen=True)
class JsonRulesLoader:
    path: Path

    def load(self) -> RuleSet:
        _o2 = json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(_o2, dict):
            raise ValueError('Rules JSON must be an object.')
        _of = int(_o2.get('version', 0))
        if _of != 1:
            raise ValueError(f'Unsupported rules version: {_of}')
        _o5 = _o2.get('hash') or {}
        _o4 = HashConfig(prefix=str(_o5.get('prefix', 'anon_')), length=int(_o5.get('length', 16)))
        if _o4.length < 8 or _o4.length > 64:
            raise ValueError('hash.length must be between 8 and 64.')
        _od = _o2.get('rules')
        if not isinstance(_od, list) or not _od:
            raise ValueError("Rules JSON must contain a non-empty 'rules' array.")
        _oc: list[AnonymizationRule] = []
        for _o6, _o7 in enumerate(_od):
            if not isinstance(_o7, dict):
                raise ValueError(f'Rule at index {_o6} must be an object.')
            _o8 = str(_o7.get('name') or f'rule_{_o6}')
            _oa = _o7.get('pattern')
            if not isinstance(_oa, str) or not _oa:
                raise ValueError(f"Rule '{_o8}' is missing 'pattern'.")
            _o1 = _o7.get('action')
            if not isinstance(_o1, str):
                raise ValueError(f"Rule '{_o8}' is missing 'action'.")
            _o0 = RuleAction(_o1)
            _o3 = _parse_flags(_o7.get('flags'))
            _o9 = re.compile(_oa, flags=_o3)
            _ob = _o7.get('replacement')
            _oe = _o7.get('token')
            if _o0 == RuleAction.REPLACE:
                if not isinstance(_ob, str):
                    raise ValueError(f"Rule '{_o8}' requires string 'replacement'.")
            if _o0 == RuleAction.TOKEN:
                if not isinstance(_oe, str):
                    raise ValueError(f"Rule '{_o8}' requires string 'token'.")
            _oc.append(AnonymizationRule(name=_o8, pattern=_o9, action=_o0, replacement=_ob if isinstance(_ob, str) else None, token=_oe if isinstance(_oe, str) else None, flags=_o3))
        return RuleSet(version=_of, rules=tuple(_oc), hash_config=_o4)

def _parse_flags(raw: Any) -> int:
    if raw is None:
        return 0
    if isinstance(raw, int):
        return raw
    if isinstance(raw, str):
        _o1 = {'I': re.IGNORECASE, 'IGNORECASE': re.IGNORECASE, 'M': re.MULTILINE, 'MULTILINE': re.MULTILINE, 'S': re.DOTALL, 'DOTALL': re.DOTALL}
        _o0 = 0
        _o3 = [_o2.strip().upper() for _o2 in raw.split('|') if _o2.strip()]
        for _o2 in _o3:
            if _o2 not in _o1:
                raise ValueError(f'Unknown regex flag: {_o2}')
            _o0 |= _o1[_o2]
        return _o0
    raise ValueError("flags must be int or string (e.g., 'IGNORECASE|MULTILINE').")
