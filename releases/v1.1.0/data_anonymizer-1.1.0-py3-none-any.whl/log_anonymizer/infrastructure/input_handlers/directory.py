from __future__ import annotations
from pathlib import Path
from log_anonymizer.infrastructure.input_handlers.base import PreparedInput

class DirectoryInputHandler:

    def prepare(self, input_path: Path) -> PreparedInput:
        _o0 = input_path.resolve()
        if not _o0.is_dir():
            raise ValueError(f'Not a directory: {input_path}')
        return PreparedInput(root_dir=_o0, only_relative=None, cleanup=lambda: None)
