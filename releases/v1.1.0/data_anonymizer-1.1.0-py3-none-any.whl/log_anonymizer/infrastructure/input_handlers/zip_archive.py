from __future__ import annotations
import logging
import shutil
import tempfile
import zipfile
from pathlib import Path
from log_anonymizer.infrastructure.input_handlers.base import PreparedInput
from log_anonymizer.utils.io import is_text_bytes
logger = logging.getLogger(__name__)

class ZipArchiveInputHandler:

    def prepare(self, input_path: Path) -> PreparedInput:
        _o1 = input_path.resolve()
        if not _o1.is_file() or _o1.suffix.lower() != '.zip':
            raise ValueError(f'Not a zip archive: {input_path}')
        tmp_dir = Path(tempfile.mkdtemp(prefix='log-anonymizer-in-'))
        try:
            with zipfile.ZipFile(_o1, 'r') as _o0:
                _safe_extractall(_o0, tmp_dir, archive_path=_o1)
        except Exception:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise

        def _cleanup() -> None:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        return PreparedInput(root_dir=tmp_dir, only_relative=None, cleanup=_cleanup)

def _safe_extractall(zf: zipfile.ZipFile, dest: Path, *, archive_path: Path) -> None:
    """
    Protect against Zip Slip (path traversal) by ensuring every extracted member stays within `dest`.
    """
    _o0 = dest.resolve()
    for _o3 in zf.infolist():
        if _o3.is_dir():
            continue
        _o4 = (dest / _o3.filename).resolve()
        if _o0 not in _o4.parents and _o4 != _o0:
            raise ValueError(f'Unsafe zip member path: {_o3.filename}')
        _o4.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(_o3, 'r') as _o5:
            _o2 = _o5.read(8192)
            if not is_text_bytes(_o2):
                logger.info('Skipping non-text file: %s', archive_path / _o3.filename)
                continue
            with _o4.open('wb') as _o1:
                _o1.write(_o2)
                shutil.copyfileobj(_o5, _o1, length=1024 * 1024)
