from __future__ import annotations
import gzip
import logging
import shutil
import tarfile
import tempfile
from pathlib import Path
from log_anonymizer.infrastructure.input_handlers.base import PreparedInput
logger = logging.getLogger(__name__)

class TarGzArchiveInputHandler:

    def prepare(self, input_path: Path) -> PreparedInput:
        _o0 = input_path.resolve()
        if not _o0.is_file() or not _is_tar_gz(_o0):
            raise ValueError(f'Not a tar.gz archive: {input_path}')
        tmp_dir = Path(tempfile.mkdtemp(prefix='log-anonymizer-in-'))
        try:
            _safe_extract_tar_gz(_o0, tmp_dir)
        except Exception:
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise

        def _cleanup() -> None:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        return PreparedInput(root_dir=tmp_dir, only_relative=None, cleanup=_cleanup)

def _is_tar_gz(path: Path) -> bool:
    _o0 = path.name.lower()
    return _o0.endswith('.tar.gz') or _o0.endswith('.tgz')

def _safe_extract_tar_gz(tar_gz_path: Path, dest: Path) -> None:
    """
    Protect against Tar Slip (path traversal) by ensuring every extracted member stays within `dest`.

    Only extracts regular files; skips symlinks/hardlinks/devices.
    """
    dest.mkdir(parents=True, exist_ok=True)
    _o0 = dest.resolve()
    try:
        with tarfile.open(tar_gz_path, mode='r:gz', ignore_zeros=True, errorlevel=0) as _o2:
            _extract_tar_streaming_from_tarfile(_o2, tar_gz_path=tar_gz_path, dest=dest, dest_resolved=_o0)
            return
    except (EOFError, gzip.BadGzipFile, tarfile.ReadError) as exc:
        raise ValueError(f'Invalid .tar.gz archive (corrupted or truncated): {tar_gz_path}') from _o1

def _extract_tar_streaming_from_tarfile(tf: tarfile.TarFile, *, tar_gz_path: Path, dest: Path, dest_resolved: Path) -> bool:
    _o3 = False
    while True:
        try:
            _o4 = tf.next()
        except EOFError as exc:
            raise EOFError(f'Unexpected EOF while reading tar members: {tar_gz_path}') from _o2
        except tarfile.ReadError as exc:
            raise tarfile.ReadError(f'Error while reading tar members: {tar_gz_path}') from _o2
        if _o4 is None:
            break
        if _o4.isdir():
            continue
        if not _o4.isreg():
            continue
        _o6 = _o4.name
        if _o6.startswith(('/', '\\')) or '..' in Path(_o6).parts:
            raise ValueError(f'Unsafe tar member path: {_o6}')
        _o5 = (dest / _o6).resolve()
        if dest_resolved not in _o5.parents and _o5 != dest_resolved:
            raise ValueError(f'Unsafe tar member path: {_o6}')
        _o5.parent.mkdir(parents=True, exist_ok=True)
        try:
            _o7 = tf.extractfile(_o4)
        except tarfile.ExtractError as exc:
            raise tarfile.ExtractError(f'Failed extracting member {_o6} from {tar_gz_path}') from _o2
        except EOFError as exc:
            raise EOFError(f'Unexpected EOF extracting member {_o6} from {tar_gz_path}') from _o2
        if _o7 is None:
            continue
        with _o7:
            with _o5.open('wb') as _o1:
                while True:
                    try:
                        _o0 = _o7.read(1024 * 1024)
                    except EOFError as exc:
                        raise EOFError(f'Unexpected EOF reading member {_o6} from {tar_gz_path}') from _o2
                    if not _o0:
                        break
                    _o1.write(_o0)
                    _o3 = True
    return _o3
