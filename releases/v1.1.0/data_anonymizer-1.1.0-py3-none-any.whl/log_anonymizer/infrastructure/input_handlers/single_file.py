from __future__ import annotations
from pathlib import Path
from log_anonymizer.infrastructure.input_handlers.base import PreparedInput
from log_anonymizer.utils.paths import as_posix_relpath

class SingleFileInputHandler:

    def prepare(self, input_path: Path) -> PreparedInput:
        _o0 = input_path.resolve()
        if not _o0.is_file():
            raise ValueError(f'Not a file: {input_path}')
        _o2 = _o0.parent
        _o1 = as_posix_relpath(_o0, _o2)
        return PreparedInput(root_dir=_o2, only_relative=_o1, cleanup=lambda: None)
