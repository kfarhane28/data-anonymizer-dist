from __future__ import annotations
import fnmatch
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

@dataclass(frozen=True)
class ExcludeFilter:
    patterns: tuple[str, ...]

    @classmethod
    def from_file(cls, path: Path) -> 'ExcludeFilter':
        _o1 = path.read_text(encoding='utf-8').splitlines()
        _o2: list[str] = []
        for _o0 in _o1:
            _o3 = _o0.strip()
            if not _o3 or _o3.startswith('#'):
                continue
            _o2.append(_o3)
        return cls(patterns=tuple(_o2))

    def is_excluded(self, rel_path: str) -> bool:
        """
        Basic gitignore-like behavior:
        - patterns are glob matched against the POSIX-style rel path and basename
        - last match wins
        - patterns starting with '!' re-include (negate)
        """
        _o5 = str(PurePosixPath(rel_path))
        _o0 = PurePosixPath(_o5).name
        _o2 = False
        for _o4 in self.patterns:
            _o3 = _o4.startswith('!')
            _o1 = _o4[1:] if _o3 else _o4
            if not _o1:
                continue
            if _match(_o1, _o5) or _match(_o1, _o0):
                _o2 = not _o3
        return _o2

def _match(pattern: str, value: str) -> bool:
    return fnmatch.fnmatch(value, pattern)
