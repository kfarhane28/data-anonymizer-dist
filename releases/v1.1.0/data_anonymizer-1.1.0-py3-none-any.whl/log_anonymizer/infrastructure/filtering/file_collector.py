from __future__ import annotations
import logging
from dataclasses import dataclass
from pathlib import Path
from log_anonymizer.infrastructure.filtering.exclude_filter import ExcludeFilter
from log_anonymizer.utils.io import is_text_file
from log_anonymizer.utils.paths import as_posix_relpath
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class CollectedFile:
    absolute_path: Path
    relative_path: str

def collect_files(*, root_dir: Path, only_relative: str | None, exclude: ExcludeFilter | None) -> list[CollectedFile]:
    if only_relative is not None:
        _o0 = (root_dir / only_relative).resolve()
        if not _o0.is_file():
            raise ValueError(f'Input file not found: {_o0}')
        if exclude and exclude.is_excluded(only_relative):
            return []
        if not is_text_file(_o0):
            logger.info('Skipping non-text file: %s', _o0)
            return []
        return [CollectedFile(absolute_path=_o0, relative_path=only_relative)]
    _o1: list[CollectedFile] = []
    for _o2 in root_dir.rglob('*'):
        if not _o2.is_file():
            continue
        if not is_text_file(_o2):
            logger.info('Skipping non-text file: %s', _o2)
            continue
        _o3 = as_posix_relpath(_o2, root_dir)
        if exclude and exclude.is_excluded(_o3):
            continue
        _o1.append(CollectedFile(absolute_path=_o2, relative_path=_o3))
    return sorted(_o1, key=lambda f: f.relative_path)
