from __future__ import annotations
import hashlib

def stable_hash(value: str, *, salt: str, length: int=16) -> str:
    """
    Stable SHA-256 digest truncated to `length` hex chars.
    """
    _o0 = hashlib.sha256()
    _o0.update(salt.encode('utf-8'))
    _o0.update(b':')
    _o0.update(value.encode('utf-8', errors='replace'))
    return _o0.hexdigest()[:length]
