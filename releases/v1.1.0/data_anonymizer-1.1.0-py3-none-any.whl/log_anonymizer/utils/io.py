from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, TextIO

@contextmanager
def open_text_best_effort(path: Path) -> Iterator[TextIO]:
    """
    Open a file as text with best-effort decoding:
    - try UTF-8
    - fallback to Latin-1

    Uses universal newlines on read; write side forces LF in output zip.
    """
    if not is_text_file(path):
        raise ValueError(f'Binary/non-text file: {path}')
    try:
        _o1 = path.open('r', encoding='utf-8', errors='strict', newline='')
        try:
            _o0 = _o1.read(4096)
            _o1.seek(0)
            yield _o1
        finally:
            _o1.close()
        return
    except UnicodeDecodeError:
        pass
    _o1 = path.open('r', encoding='latin-1', errors='replace', newline='')
    try:
        yield _o1
    finally:
        _o1.close()

def is_text_file(path: str | Path, *, sniff_bytes: int=8192) -> bool:
    """
    Robust text detection (extension-agnostic).

    Strategy:
    - Read a small initial chunk
    - Reject known binary signatures and NUL bytes
    - Reject chunks with a high ratio of control/non-printable bytes
    - Try UTF-8 strict decoding; if it fails, accept as text only if the chunk still
      looks like text (e.g., Latin-1 logs are common in the wild)
    """
    _o2 = Path(path)
    if not _o2.exists() or not _o2.is_file():
        return False
    try:
        with _o2.open('rb') as _o1:
            _o0 = _o1.read(sniff_bytes)
    except OSError:
        return False
    return is_text_bytes(_o0)

def is_text_bytes(chunk: bytes) -> bool:
    if not chunk:
        return True
    if _has_binary_signature(chunk):
        return False
    if _looks_binary_bytes(chunk):
        return False
    try:
        chunk.decode('utf-8', errors='strict')
        return True
    except UnicodeDecodeError:
        return True

def _has_binary_signature(chunk: bytes) -> bool:
    _o1 = (b'%PDF-', b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a', b'PK\x03\x04', b'\x1f\x8b', b'PAR1', b'Obj\x01')
    for _o0 in _o1:
        if chunk.startswith(_o0):
            return True
    return False

def _looks_binary_bytes(chunk: bytes) -> bool:
    if b'\x00' in chunk:
        return True
    _o0 = {9, 10, 12, 13}
    _o2 = 0
    for _o1 in chunk:
        if _o1 == 127 or (_o1 < 32 and _o1 not in _o0) or 128 <= _o1 < 160:
            _o2 += 1
    return _o2 / len(chunk) > 0.3

def is_probably_text_file(path: Path, *, sniff_bytes: int=8192) -> bool:
    """
    Backward-compatible alias for older code paths.
    """
    return is_text_file(path, sniff_bytes=sniff_bytes)
