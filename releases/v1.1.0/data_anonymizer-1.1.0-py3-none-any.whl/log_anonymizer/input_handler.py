from __future__ import annotations
import gzip
import logging
import shutil
import tempfile
import tarfile
import time
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator
from log_anonymizer.input_limits import ArchiveExtractionLimiter, FreeEditionInputLimits, validate_archive_compressed_size, validate_archive_file_count, validate_single_file_size
logger = logging.getLogger(__name__)
try:
    from log_anonymizer.progress import ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:
    ProgressReporter = object
    ProgressKind = None
    ProgressStage = None

    def now_event(**kwargs):
        raise RuntimeError('progress module unavailable')

@dataclass(frozen=True)
class InputHandlingResult:
    """
    Result of preparing an input for processing.

    Attributes:
        working_dir: Directory that contains the returned files. For a directory input,
            this is the input directory. For a single-file input, this is the file's
            parent directory. For a zip input, this is a temporary extraction directory.
        files: Absolute file paths to process.
    """
    working_dir: Path
    files: list[Path]

@contextmanager
def handle_input(input_path: Path, *, progress: ProgressReporter | None=None, limits: FreeEditionInputLimits | None=None) -> Iterator[InputHandlingResult]:
    """
    Prepare an input path (directory, file, or archive) for processing.

    Responsibilities:
    - Detect input type automatically.
    - If directory: recursively list all files.
    - If file: treat as a single file.
    - If archive (.zip / .tar.gz / .tgz): safely extract to a temporary directory and recursively list extracted files.

    Returns:
        A context manager yielding an InputHandlingResult. Temporary directories created
        for archive inputs are cleaned up automatically on exit.

    Notes:
        For very large archives, a streaming approach (reading zip members without full
        extraction) can be more efficient, but most anonymization pipelines expect
        file paths. This implementation extracts in a safe, streaming manner (member
        by member) to avoid loading whole files into memory.
    """
    _o2 = input_path.expanduser().resolve()
    if not _o2.exists():
        raise FileNotFoundError(_o2)
    _o3: Path | None = None
    try:
        if _o2.is_dir():
            logger.info('input_detected', extra={'type': 'directory', 'path': str(_o2)})
            _o0 = list(_iter_files(_o2, progress=progress))
            logger.info('input_files_listed', extra={'count': len(_o0)})
            yield InputHandlingResult(working_dir=_o2, files=_o0)
            return
        if _o2.is_file() and _o2.suffix.lower() == '.zip':
            logger.info('input_detected', extra={'type': 'zip', 'path': str(_o2)})
            if limits is not None:
                validate_archive_compressed_size(_o2.stat().st_size, limits=limits)
            _o3 = Path(tempfile.mkdtemp(prefix='log-anonymizer-input-')).resolve()
            logger.debug('zip_extract_start', extra={'zip': str(_o2), 'tmp_dir': str(_o3)})
            _o1 = ArchiveExtractionLimiter(limits) if limits is not None else None
            _extract_zip_streaming(_o2, _o3, progress=progress, limiter=_o1, limits=limits)
            _o0 = list(_iter_files(_o3, progress=progress))
            logger.info('input_files_listed', extra={'count': len(_o0), 'working_dir': str(_o3)})
            yield InputHandlingResult(working_dir=_o3, files=_o0)
            return
        if _o2.is_file() and _is_tar_gz(_o2):
            logger.info('input_detected', extra={'type': 'tar.gz', 'path': str(_o2)})
            if limits is not None:
                validate_archive_compressed_size(_o2.stat().st_size, limits=limits)
            _o3 = Path(tempfile.mkdtemp(prefix='log-anonymizer-input-')).resolve()
            logger.debug('tar_extract_start', extra={'tar': str(_o2), 'tmp_dir': str(_o3)})
            _o1 = ArchiveExtractionLimiter(limits) if limits is not None else None
            _extract_tar_gz_streaming(_o2, _o3, progress=progress, limiter=_o1)
            _o0 = list(_iter_files(_o3, progress=progress))
            logger.info('input_files_listed', extra={'count': len(_o0), 'working_dir': str(_o3)})
            yield InputHandlingResult(working_dir=_o3, files=_o0)
            return
        if _o2.is_file():
            logger.info('input_detected', extra={'type': 'file', 'path': str(_o2)})
            if limits is not None:
                validate_single_file_size(_o2.stat().st_size, limits=limits)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.DISCOVERY, current=1, total=1, message='single_file'))
            yield InputHandlingResult(working_dir=_o2.parent, files=[_o2])
            return
        raise ValueError(f'Unsupported input path: {_o2}')
    finally:
        if _o3 is not None:
            logger.debug('cleanup_tmp_dir', extra={'tmp_dir': str(_o3)})
            shutil.rmtree(_o3, ignore_errors=True)

def _iter_files(root_dir: Path, *, progress: ProgressReporter | None=None) -> Iterator[Path]:
    """
    Recursively yield file paths under root_dir.

    Uses an explicit stack to avoid recursion depth issues on deeply nested trees.
    Skips symlinks to avoid potential cycles.
    """
    _o6: list[Path] = [root_dir]
    _o1 = 0
    _o4 = 0.0
    while _o6:
        _o0 = _o6.pop()
        try:
            for _o2 in _o0.iterdir():
                if _o2.is_symlink():
                    logger.debug('skip_symlink', extra={'path': str(_o2)})
                    continue
                if _o2.is_dir():
                    _o6.append(_o2)
                elif _o2.is_file():
                    logger.debug('discovered_file', extra={'path': str(_o2)})
                    _o1 += 1
                    if progress is not None:
                        _o5 = time.monotonic()
                        if _o1 == 1 or _o1 % 200 == 0 or _o5 - _o4 >= 0.2:
                            _o4 = _o5
                            progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.DISCOVERY, current=_o1, total=None, message='listing_files'))
                    yield _o2
        except OSError as exc:
            logger.debug('skip_unreadable_dir', extra={'path': str(_o0), 'reason': str(_o3)})

def _extract_zip_streaming(zip_path: Path, dest_dir: Path, *, progress: ProgressReporter | None=None, limiter: ArchiveExtractionLimiter | None=None, limits: FreeEditionInputLimits | None=None) -> None:
    """
    Extract `zip_path` into `dest_dir` in a safe, streaming way.

    - Defends against Zip Slip (path traversal)
    - Streams each member to disk (does not load whole members into memory)
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    _o1 = dest_dir.resolve()
    with zipfile.ZipFile(zip_path, 'r') as _ob:
        _o6 = [_o4 for _o4 in _ob.infolist() if not _o4.is_dir()]
        _oa = len(_o6)
        if limits is not None:
            validate_archive_file_count(_oa, limits=limits)
        _o3 = 0
        _o5 = 0.0
        for _o4 in _o6:
            _o9 = (dest_dir / _o4.filename).resolve()
            if _o1 not in _o9.parents and _o9 != _o1:
                raise ValueError(f'Unsafe zip member path: {_o4.filename}')
            _o9.parent.mkdir(parents=True, exist_ok=True)
            if limiter is not None:
                limiter.on_new_file()
            with _ob.open(_o4, 'r') as _o8:
                with _o9.open('wb') as _o2:
                    while True:
                        _o0 = _o8.read(1024 * 1024)
                        if not _o0:
                            break
                        _o2.write(_o0)
                        if limiter is not None:
                            limiter.on_bytes(len(_o0))
            _o3 += 1
            if progress is not None:
                _o7 = time.monotonic()
                if _o3 == 1 or _o3 == _oa or _o7 - _o5 >= 0.2:
                    _o5 = _o7
                    progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.DISCOVERY, current=_o3, total=_oa, message='extracting_zip'))

def _is_tar_gz(path: Path) -> bool:
    _o0 = path.name.lower()
    return _o0.endswith('.tar.gz') or _o0.endswith('.tgz')

def _extract_tar_gz_streaming(tar_gz_path: Path, dest_dir: Path, *, progress: ProgressReporter | None=None, limiter: ArchiveExtractionLimiter | None=None) -> None:
    """
    Extract `tar_gz_path` into `dest_dir` in a safe, streaming way.

    - Defends against Tar Slip (path traversal)
    - Only extracts regular files (skips symlinks, hardlinks, devices, etc.)
    - Streams each member to disk (does not load whole members into memory)
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    _o0 = dest_dir.resolve()
    try:
        with tarfile.open(tar_gz_path, mode='r:gz', ignore_zeros=True, errorlevel=0) as _o2:
            _extract_tar_streaming_from_tarfile(_o2, tar_gz_path=tar_gz_path, dest_dir=dest_dir, dest_root=_o0, progress=progress, limiter=limiter)
            return
    except (EOFError, gzip.BadGzipFile, tarfile.ReadError) as exc:
        raise ValueError(f'Invalid .tar.gz archive (corrupted or truncated): {tar_gz_path}') from _o1

def _extract_tar_streaming_from_tarfile(tf: tarfile.TarFile, *, tar_gz_path: Path, dest_dir: Path, dest_root: Path, progress: ProgressReporter | None=None, limiter: ArchiveExtractionLimiter | None=None) -> bool:
    _o3 = False
    _o4 = 0
    _o5 = 0.0
    while True:
        try:
            _o6 = tf.next()
        except EOFError as exc:
            raise EOFError(f'Unexpected EOF while reading tar members: {tar_gz_path}') from _o2
        except tarfile.ReadError as exc:
            raise tarfile.ReadError(f'Error while reading tar members: {tar_gz_path}') from _o2
        if _o6 is None:
            break
        if _o6.isdir():
            continue
        if not _o6.isreg():
            logger.debug('skip_non_regular_tar_member', extra={'member': _o6.name, 'type': _o6.type})
            continue
        _o7 = _o6.name
        if _o7.startswith(('/', '\\')) or '..' in Path(_o7).parts:
            raise ValueError(f'Unsafe tar member path: {_o7}')
        _oa = (dest_dir / _o7).resolve()
        if dest_root not in _oa.parents and _oa != dest_root:
            raise ValueError(f'Unsafe tar member path: {_o7}')
        _oa.parent.mkdir(parents=True, exist_ok=True)
        try:
            _o9 = tf.extractfile(_o6)
        except tarfile.ExtractError as exc:
            raise tarfile.ExtractError(f'Failed extracting member {_o7} from {tar_gz_path}') from _o2
        except EOFError as exc:
            raise EOFError(f'Unexpected EOF extracting member {_o7} from {tar_gz_path}') from _o2
        if _o9 is None:
            continue
        with _o9:
            with _oa.open('wb') as _o1:
                if limiter is not None:
                    limiter.on_new_file()
                while True:
                    try:
                        _o0 = _o9.read(1024 * 1024)
                    except EOFError as exc:
                        raise EOFError(f'Unexpected EOF reading member {_o7} from {tar_gz_path}') from _o2
                    if not _o0:
                        break
                    _o1.write(_o0)
                    if limiter is not None:
                        limiter.on_bytes(len(_o0))
                    _o3 = True
        _o4 += 1
        if progress is not None:
            _o8 = time.monotonic()
            if _o4 == 1 or _o8 - _o5 >= 0.2:
                _o5 = _o8
                progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.DISCOVERY, current=_o4, total=None, message='extracting_tar'))
    return _o3
