from __future__ import annotations
import argparse
import signal
import sys
from pathlib import Path
from queue import Queue
from typing import NoReturn
from log_anonymizer.builtin_rules import default_rules, merge_rules
from log_anonymizer.config.app_config import load_config, resolve_config_path
from log_anonymizer.config.logging_config import LogFormat, setup_logging
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns, load_patterns
from log_anonymizer.input_limits import resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer import __version__
from log_anonymizer.licensing.features import FeatureFlag
from log_anonymizer.licensing.models import Edition
from log_anonymizer.licensing.service import LicensingService
from log_anonymizer.profiling.runner import run_sensitive_data_profiling
from log_anonymizer.processor import ProcessorConfig, process
from log_anonymizer.progress import ProgressEvent, ProgressStopToken, QueueProgressReporter
from log_anonymizer.progress_cli import start_cli_progress_thread
from log_anonymizer.rules_loader import Rule, load_rules
from log_anonymizer.rule_actions import ReplacementAction

def _build_parser() -> argparse.ArgumentParser:
    _o1 = argparse.ArgumentParser(description='Anonymize sensitive data in files and archives (logs, text files, extracted datasets). Outputs a single .tar.gz archive.', epilog='© 2026 MagicByte Consulting. Proprietary software. See LICENSE and EULA.md.')
    _o1.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    _o1.add_argument('--input', '-i', type=Path, required=True, help='Input path (directory, single file, or .zip/.tar.gz archive).')
    _o1.add_argument('--output', '-o', type=Path, required=True, help='Output directory where a single .tar.gz archive will be written.')
    _o1.add_argument('--rules', '-r', type=Path, default=None, help='Optional rules JSON file. If omitted, the built-in rules are used (unless --no-default-rules).')
    _o1.add_argument('--exclude', '-x', type=Path, default=None, help="Optional .exclude file with glob patterns (appended after built-in excludes; use '!pattern' to re-include).")
    _o1.add_argument('--config', type=Path, default=None, help='Optional config file (INI). Default: ./log-anonymizer.ini or $DATA_ANONYMIZER_CONFIG (legacy: $LOG_ANONYMIZER_CONFIG)')
    _o1.add_argument('--dry-run', action='store_true', help='Validate and report what would be processed without writing output.')
    _o1.add_argument('-v', '--verbose', action='store_true', help='Enable DEBUG logging.')
    _o1.add_argument('--exclude-case-insensitive', action='store_true', help='Case-insensitive exclude matching.')
    _o1.add_argument('--no-default-rules', action='store_true', help='Do not include built-in baseline rules.')
    _o1.add_argument('--profile-sensitive-data', action='store_true', help='Enable optional sensitive-data profiling (heuristic) and rule suggestions.')
    _o1.add_argument('--profiling-detectors', default='email,ipv4,token,card', help='Comma-separated detectors to run in profiling mode (default: email,ipv4,token,card).')
    _o1.add_argument('--profiling-report', type=Path, default=None, help='Optional path to write profiling report JSON (default: <output>/profiling_report.json).')
    _o1.add_argument('--suggest-rules-output', type=Path, default=None, help='Optional path to write suggested rules JSON (default: <output>/suggested_rules.json).')
    _o1.add_argument('--log-level', default=None, help='Logging level (overrides config; default: INFO).')
    _o1.add_argument('--log-format', choices=[_o0.value for _o0 in LogFormat], default=None, help='Logging format: json or text (overrides config; default: json).')
    _o1.add_argument('--parallel', action='store_true', help='Enable parallel processing of files (default: disabled, sequential).')
    _o1.add_argument('--max-workers', type=int, default=5, help='Max parallel workers when --parallel is enabled (default: 5).')
    _o2 = _o1.add_mutually_exclusive_group()
    _o2.add_argument('--progress', action='store_true', help='Force progress display (writes to stderr).')
    _o2.add_argument('--no-progress', action='store_true', help='Disable progress display (useful when redirecting stderr).')
    return _o1

def main(argv: list[str] | None=None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if hasattr(signal, 'SIGPIPE'):
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    if argv and argv[0] == 'license':
        _license_main(argv[1:])
        return
    _o0 = _build_parser().parse_args(argv)
    _run_main(_o0)

def _license_main(argv: list[str]) -> None:
    _o7 = argparse.ArgumentParser(prog=None, description='Manage and validate the local license key (Free vs Pro edition).')
    _o7.add_argument('--path', type=Path, default=None, help='Optional license key file path (default: $DATA_ANONYMIZER_LICENSE_PATH or ~/.config/data-anonymizer/license.key).')
    _ob = _o7.add_subparsers(dest='cmd')
    _ob.add_parser('status', help='Show current edition, enabled features, and validation details.')
    _o6 = _ob.add_parser('validate', help='Validate the current license key and exit non-zero if invalid.')
    _o6.add_argument('--quiet', action='store_true', help='Only set exit code (no output).')
    _o5 = _ob.add_parser('install', help='Install a license key into the local license file.')
    _o2 = _o5.add_mutually_exclusive_group(required=True)
    _o2.add_argument('--key', type=str, help='License key string (LA1.<payload>.<sig>).')
    _o2.add_argument('--file', type=Path, help='File containing the license key string.')
    _ob.add_parser('clear', help='Remove the local license key file.')
    _o4 = _o7.parse_args(argv if argv else ['status'])
    _o9 = LicensingService.default()
    _oa = _o9.storage if _o4.path is None else type(_o9.storage)(Path(_o4.path))
    _o9 = LicensingService(storage=_oa)
    if _o4.cmd == 'clear':
        _oa.clear()
        print(f'cleared: {_oa.path}')
        return
    if _o4.cmd == 'install':
        _o3 = _o4.key
        if _o3 is None:
            _o3 = Path(_o4.file).read_text(encoding='utf-8')
        _oa.save(_o3)
        _o8 = _o9.validate()
        if _o8.valid:
            print(f'installed: {_oa.path}')
        else:
            print(f'installed: {_oa.path} (but license is invalid: {_o8.reason.value})')
            if _o8.message:
                print(_o8.message)
        return
    _o8 = _o9.validate()
    _o0 = _o9.edition().value
    _o1 = sorted((f.value for f in _o9.enabled_features()))
    if _o4.cmd == 'validate':
        if not bool(_o4.quiet):
            print(f'edition={_o0}')
            print(f'valid={_o8.valid}')
            print(f'reason={_o8.reason.value}')
            if _o8.message:
                print(f'message={_o8.message}')
            print(f'path={_oa.path}')
        raise SystemExit(0 if _o8.valid else 1)
    print(f'edition={_o0}')
    print(f'valid={_o8.valid}')
    print(f'reason={_o8.reason.value}')
    if _o8.license_info is not None:
        print(f'customer_name={_o8.license_info.customer_name}')
        print(f'customer_id={_o8.license_info.customer_id}')
        print(f'expiry_date={_o8.license_info.expiry_date.isoformat()}')
        if _o8.license_info.max_version:
            print(f'max_version={_o8.license_info.max_version}')
    if _o8.message:
        print(f'message={_o8.message}')
    print(f'path={_oa.path}')
    print('features=' + (','.join(_o1) if _o1 else '<none>'))

def _run_main(args: argparse.Namespace) -> None:
    _o12 = LicensingService.default()
    _o7 = _o12.enabled_features()
    _o3 = _o12.edition()
    _o1 = resolve_config_path(args.config)
    _o0 = load_config(_o1)
    _o8 = args.log_format or _o0.logging.fmt or LogFormat.JSON.value
    _ob = LogFormat(_o8)
    if args.verbose:
        _oa = 'DEBUG'
    else:
        _oa = args.log_level or _o0.logging.level or 'INFO'
    setup_logging(level=_oa, log_format=_ob)
    _o9 = args.input
    _od = args.output
    _o11 = args.rules
    _o6 = args.exclude
    if args.parallel and FeatureFlag.parallel_processing not in _o7:
        _die('Parallel processing requires a Pro license.')
    if args.profile_sensitive_data and FeatureFlag.profiling not in _o7:
        _die('Sensitive-data profiling requires a Pro license.')
    if not _o9.exists():
        _die(f'Input path does not exist: {_o9}')
    if _o11 is not None and (not _o11.exists()):
        _die(f'Rules file does not exist: {_o11}')
    if _o6 is not None and (not _o6.exists()):
        _die(f'Exclude file does not exist: {_o6}')
    if args.no_default_rules and _o11 is None:
        _die('--no-default-rules requires providing --rules (otherwise there are no rules to apply).')
    if args.max_workers is not None and args.max_workers <= 0:
        _die(f'--max-workers must be >= 1 (got {args.max_workers})')
    if _o11 is not None and FeatureFlag.advanced_rules not in _o7:
        _enforce_free_rules(_o11)
    _o9 = _o9.resolve()
    _od = _od.resolve()
    _o11 = _o11.resolve() if _o11 is not None else None
    _o6 = _o6.resolve() if _o6 is not None else None
    try:
        if args.dry_run:
            _o2 = tuple((p.strip() for p in str(args.profiling_detectors or '').split(',') if p.strip())) or ('email', 'ipv4', 'token', 'card')
            if args.profile_sensitive_data:
                _o10 = run_sensitive_data_profiling(input_path=_o9, output_dir=_od, exclude_path=_o6, exclude_case_insensitive=bool(args.exclude_case_insensitive), detectors=_o2, profiling_report_path=args.profiling_report, suggest_rules_output_path=args.suggest_rules_output)
                print('DRY RUN (profiling only)')
                print(f'- Input: {_o9}')
                print(f'- Output dir: {_od}')
                print(f'- Profiling report: {_o10.profiling_report_path}')
                print(f'- Suggested rules: {_o10.suggested_rules_path}')
                print(f'- Files: total={_o10.total_files}, excluded={_o10.excluded_files}, profiled={_o10.profiled_files}')
                return
            _dry_run(input_path=_o9, output_dir=_od, rules_path=_o11, exclude_path=_o6, exclude_case_insensitive=bool(args.exclude_case_insensitive), include_builtin=not bool(args.no_default_rules), allow_advanced_rules=FeatureFlag.advanced_rules in _o7, edition=_o3)
            return
        _o2 = tuple((p.strip() for p in str(args.profiling_detectors or '').split(',') if p.strip())) or ('email', 'ipv4', 'token', 'card')
        _o0 = ProcessorConfig(parallel_enabled=bool(args.parallel), max_workers=int(args.max_workers or 5), exclude_case_insensitive=bool(args.exclude_case_insensitive), include_builtin_rules=not bool(args.no_default_rules), profile_sensitive_data=bool(args.profile_sensitive_data), profiling_detectors=_o2, profiling_report_path=args.profiling_report.resolve() if args.profiling_report is not None else None, suggest_rules_output_path=args.suggest_rules_output.resolve() if args.suggest_rules_output is not None else None, rollback_on_cancel=FeatureFlag.partial_cancel_preservation not in _o7, anonymization_salt=_o0.anonymization.salt, edition=_o3)
        _o4 = bool(args.progress) or (not bool(args.no_progress) and sys.stderr.isatty())
        _oe: Queue[ProgressEvent] | None = None
        _o13: ProgressStopToken | None = None
        _o14 = None
        _of = None
        if _o4:
            _oe = Queue(maxsize=5000)
            _o13 = ProgressStopToken()
            _of = QueueProgressReporter(_oe)
            _o14 = start_cli_progress_thread(_oe, _o13)
        try:
            _oc = process(input_path=_o9, rules_path=_o11, output_dir=_od, exclude_path=_o6, config=_o0, progress=_of)
        finally:
            if _o13 is not None:
                _o13.stop()
            if _o14 is not None:
                _o14.join(timeout=2.0)
        print(str(_oc))
    except KeyboardInterrupt:
        raise SystemExit(130) from None
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            raise SystemExit(141) from None
    except Exception as exc:
        print(f'ERROR: {_o5}', file=sys.stderr)
        raise SystemExit(1) from _o5

def _dry_run(*, input_path: Path, output_dir: Path, rules_path: Path | None, exclude_path: Path | None, exclude_case_insensitive: bool, include_builtin: bool, allow_advanced_rules: bool, edition: Edition) -> None:
    """
    Dry-run mode: validate inputs, load rules, apply excludes, and report what would be done.
    """
    if output_dir.exists() and (not output_dir.is_dir()):
        _die(f'--output must be a directory: {output_dir}')
    _oa = load_rules(rules_path, strict=True) if rules_path is not None else []
    if rules_path is not None and (not allow_advanced_rules):
        _enforce_rules_are_replacement_only(_oa)
    _o9 = merge_rules(builtin=default_rules(), user=_oa) if include_builtin else _oa
    if not _o9:
        _die('No valid rules loaded; nothing to do.')
    _o5 = resolve_free_input_limits(edition=edition)
    with handle_input(input_path, limits=_o5) as _o8:
        _o0 = _o8.working_dir
        _o3 = _o8.files
        _o7 = list(default_patterns())
        if exclude_path is not None:
            _o7.extend(load_patterns(exclude_path))
        _o1 = ExcludeFilter.from_patterns(_o7, base_dir=_o0, case_insensitive=exclude_case_insensitive) if _o7 else None
        _o4 = [_o2 for _o2 in _o3 if not (_o1 and _o1.should_exclude(_o2))]
    _ob = _default_output_archive_path(output_dir, input_path)
    print('DRY RUN')
    print(f'- Input: {input_path}')
    print(f'- Output dir: {output_dir}')
    print(f'- Output archive: {_ob}')
    print(f"- Rules: {len(_o9)} (user={len(_oa)}, builtin={('on' if include_builtin else 'off')})")
    print(f'- Files: total={len(_o3)}, excluded={len(_o3) - len(_o4)}, to_process={len(_o4)}')
    for _o6 in _o4[:20]:
        print(f'  - {_o6}')
    if len(_o4) > 20:
        print(f'  ... ({len(_o4) - 20} more)')

def _die(message: str) -> 'NoReturn':
    print(f'ERROR: {message}', file=sys.stderr)
    raise SystemExit(2)

def _enforce_free_rules(rules_path: Path) -> None:
    """
    Free edition supports legacy rules only: fixed string replacements.
    """
    try:
        _o1 = load_rules(rules_path, strict=True)
    except Exception as exc:
        _die(str(_o0))
    _enforce_rules_are_replacement_only(_o1)

def _enforce_rules_are_replacement_only(user_rules: list[Rule]) -> None:
    for _o0 in user_rules:
        if not isinstance(getattr(_o0, 'action', None), ReplacementAction):
            _die('Advanced rule actions require a Pro license (enable `advanced_rules`).')

def _default_output_archive_path(output_dir: Path, input_path: Path) -> Path:
    _o3 = output_dir.resolve()
    _o2 = input_path.name
    _o1 = _o2.lower()
    if _o1.endswith('.tar.gz'):
        _o0 = _o2[:-len('.tar.gz')]
    elif _o1.endswith('.tgz'):
        _o0 = _o2[:-len('.tgz')]
    elif _o1.endswith('.zip'):
        _o0 = input_path.stem
    else:
        _o0 = input_path.stem or _o2
    return _o3 / f'{_o0}.tar.gz'
