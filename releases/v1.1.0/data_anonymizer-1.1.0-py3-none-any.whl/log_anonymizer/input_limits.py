from __future__ import annotations
from dataclasses import dataclass
from log_anonymizer.licensing.models import Edition

class InputLimitError(ValueError):
    """
    Raised when the Free edition workload limits are exceeded.

    This is intentionally a ValueError so it is handled consistently at CLI/UI boundaries.
    """

def _format_bytes(n: int) -> str:
    n = int(n)
    if n < 0:
        n = 0
    _o2 = ['B', 'KB', 'MB', 'GB', 'TB']
    _o3 = float(n)
    _o1 = _o2[0]
    for _o0 in _o2[1:]:
        if _o3 < 1024.0:
            break
        _o3 /= 1024.0
        _o1 = _o0
    if _o1 == 'B':
        return f'{int(_o3)} {_o1}'
    return f'{_o3:.1f} {_o1}'

def _format_bytes_with_exact(n: int) -> str:
    return f'{_format_bytes(n)} ({int(n):,} bytes)'

def _size_limit_error(*, scope: str, detected_bytes: int, limit_bytes: int) -> InputLimitError:
    return InputLimitError(f'Free edition workload limit exceeded: {scope}. Detected {_format_bytes_with_exact(detected_bytes)}; Free limit {_format_bytes_with_exact(limit_bytes)}. Pro edition supports larger workloads. Action: reduce the input size (or exclude large files) or activate Pro.')

def _count_limit_error(*, scope: str, detected_count: int, limit_count: int) -> InputLimitError:
    return InputLimitError(f'Free edition workload limit exceeded: {scope}. Detected {int(detected_count):,}; Free limit {int(limit_count):,}. Pro edition supports larger workloads. Action: reduce the input (or exclude files) or activate Pro.')

@dataclass(frozen=True)
class FreeEditionInputLimits:
    """
    Workload limits for the Free edition.

    Defaults are production limits. Tests can override by passing a custom instance.
    """
    max_single_file_bytes: int = 10 * 1024 * 1024
    max_archive_compressed_bytes: int = 50 * 1024 * 1024
    max_archive_extracted_total_bytes: int = 200 * 1024 * 1024
    max_archive_extracted_file_count: int = 200
DEFAULT_FREE_LIMITS = FreeEditionInputLimits()

def resolve_free_input_limits(*, edition: Edition, override_free_limits: FreeEditionInputLimits | None=None) -> FreeEditionInputLimits | None:
    """
    Return Free edition limits when running in Free mode, otherwise None.

    Pro edition should bypass all Free-specific workload caps.
    """
    if edition == Edition.pro:
        return None
    return override_free_limits or DEFAULT_FREE_LIMITS

def validate_single_file_size(path_size_bytes: int, *, limits: FreeEditionInputLimits) -> None:
    if path_size_bytes <= limits.max_single_file_bytes:
        return
    raise _size_limit_error(scope='single file input exceeds the supported size', detected_bytes=path_size_bytes, limit_bytes=limits.max_single_file_bytes)

def validate_archive_compressed_size(path_size_bytes: int, *, limits: FreeEditionInputLimits) -> None:
    if path_size_bytes <= limits.max_archive_compressed_bytes:
        return
    raise _size_limit_error(scope='archive input exceeds the supported compressed size', detected_bytes=path_size_bytes, limit_bytes=limits.max_archive_compressed_bytes)

def validate_archive_file_count(file_count: int, *, limits: FreeEditionInputLimits) -> None:
    if file_count <= limits.max_archive_extracted_file_count:
        return
    raise _count_limit_error(scope='archive input exceeds the supported extracted file count', detected_count=file_count, limit_count=limits.max_archive_extracted_file_count)

class ArchiveExtractionLimiter:
    """
    Enforces extracted archive limits (total bytes + file count) during extraction.
    """

    def __init__(self, limits: FreeEditionInputLimits) -> None:
        self._limits = limits
        self._extracted_files = 0
        self._extracted_bytes = 0

    def on_new_file(self) -> None:
        self._extracted_files += 1
        if self._extracted_files > self._limits.max_archive_extracted_file_count:
            raise _count_limit_error(scope='archive input exceeds the supported extracted file count', detected_count=self._extracted_files, limit_count=self._limits.max_archive_extracted_file_count)

    def on_bytes(self, n: int) -> None:
        if n <= 0:
            return
        self._extracted_bytes += int(n)
        if self._extracted_bytes > self._limits.max_archive_extracted_total_bytes:
            raise _size_limit_error(scope='archive input exceeds the supported extracted total size', detected_bytes=self._extracted_bytes, limit_bytes=self._limits.max_archive_extracted_total_bytes)
