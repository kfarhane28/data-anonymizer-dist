from __future__ import annotations
import logging
import re
from dataclasses import dataclass
from typing import Callable, Iterable
from log_anonymizer.domain.rules import AnonymizationRule, HashConfig, RuleAction
from log_anonymizer.utils.hashing import stable_hash
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class AnonymizationEngine:
    rules: tuple[AnonymizationRule, ...]
    hash_config: HashConfig
    salt: str

    def anonymize_text(self, text: str) -> str:
        _o0 = text
        for _o1 in self.rules:
            _o0 = self._apply_rule(_o1, _o0)
        return _o0

    def anonymize_lines(self, lines: Iterable[str]) -> Iterable[str]:
        for _o0 in lines:
            yield self.anonymize_text(_o0)

    def _apply_rule(self, rule: AnonymizationRule, text: str) -> str:
        if rule.action == RuleAction.REPLACE:
            assert rule.replacement is not None
            return rule.pattern.sub(rule.replacement, text)
        if rule.action == RuleAction.TOKEN:
            assert rule.token is not None
            return rule.pattern.sub(rule.token, text)
        if rule.action == RuleAction.MASK:
            return rule.pattern.sub(lambda m: '*' * len(m.group(0)), text)
        if rule.action == RuleAction.HASH:
            return rule.pattern.sub(self._hash_repl(rule.pattern), text)
        raise ValueError(f'Unsupported action: {rule.action}')

    def _hash_repl(self, pattern: re.Pattern[str]) -> Callable[[re.Match[str]], str]:
        prefix = self.hash_config.prefix
        length = self.hash_config.length

        def _repl(match: re.Match[str]) -> str:
            _o1 = match.group(0)
            _o0 = stable_hash(_o1, salt=self.salt, length=length)
            return f'{prefix}{_o0}'
        return _repl
