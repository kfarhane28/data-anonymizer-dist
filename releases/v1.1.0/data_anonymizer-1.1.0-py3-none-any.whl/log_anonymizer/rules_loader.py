from __future__ import annotations
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from log_anonymizer.rule_actions import ReplacementAction, RuleAction, parse_action
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class Rule:
    """
    A single anonymization rule.

    Attributes:
        description: Human-readable description (may be empty).
        trigger: Optional substring used as a fast pre-check before running the regex.
        regex: Compiled regex used for the replacement.
        replacement: Replacement string passed to `re.sub`.
        case_sensitive: Whether trigger check and regex are case sensitive.
        action: Optional action strategy controlling how replacements are produced.
    """
    description: str
    trigger: str
    regex: re.Pattern[str]
    replacement: str
    case_sensitive: bool
    action: RuleAction | None = None

    def __post_init__(self) -> None:
        if self.action is None:
            object.__setattr__(self, 'action', ReplacementAction(value=self.replacement))
        elif isinstance(self.action, ReplacementAction) and self.replacement != self.action.value:
            object.__setattr__(self, 'replacement', self.action.value)

    def triggered_by(self, line: str) -> bool:
        if not self.trigger:
            return True
        if self.case_sensitive:
            return self.trigger in line
        return self.trigger.lower() in line.lower()

def load_rules(rules_path: Path, *, strict: bool=False) -> list[Rule]:
    """
    Load and validate rules from a JSON file.

    Expected format:
    {
      "version": 1,   # or 2
      "rules": [
        {
          "description": "...",
          "trigger": "...",
          "search": "...",
          "replace": "...",              # legacy fixed replacement
          "action": {"type": "...", ...} # new action-based format
          "caseSensitive": "false"
        }
      ]
    }

    Behavior:
    - Validates presence of required fields.
    - Normalizes `caseSensitive` to a boolean (default: true).
    - Compiles regex patterns; invalid rules are skipped with a warning.
    - When `strict=True`, invalid rules raise ValueError with explicit context.
    """
    _o0 = _load_json(rules_path)
    _o8 = _o0.get('version', 1)
    try:
        _o7 = int(_o8)
    except Exception as exc:
        raise ValueError(f'Unsupported rules version: {_o8!r} (expected 1 or 2)') from _o1
    if _o7 not in (1, 2):
        raise ValueError(f'Unsupported rules version: {_o7!r} (expected 1 or 2)')
    _o5 = _o0.get('rules')
    if not isinstance(_o5, list):
        raise ValueError("'rules' must be a list")
    _o3: list[Rule] = []
    for _o2, _o4 in enumerate(_o5):
        _o6 = _parse_rule(_o4, index=_o2, rules_path=rules_path, strict=strict)
        if _o6 is not None:
            _o3.append(_o6)
    logger.info('rules_loaded', extra={'path': str(rules_path), 'count': len(_o3)})
    return _o3

def _load_json(path: Path) -> dict[str, Any]:
    try:
        _o0 = json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        raise
    except json.JSONDecodeError as exc:
        raise ValueError(f'Invalid JSON in {path}: {_o1}') from _o1
    if not isinstance(_o0, dict):
        raise ValueError('rules.json must contain a JSON object')
    return _o0

def _parse_rule(raw: Any, *, index: int, rules_path: Path, strict: bool) -> Rule | None:
    if not isinstance(raw, dict):
        return _invalid_rule(index=index, description='', strict=strict, reason='not_an_object')
    _o2 = str(raw.get('description') or '')
    _oa = raw.get('trigger', '')
    if _oa is None:
        _o9 = ''
    elif isinstance(_oa, str):
        _o9 = _oa
    else:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='trigger_not_string')
    _o8 = raw.get('search')
    if not isinstance(_o8, str) or not _o8:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='missing_search')
    _o0: RuleAction | None = None
    _o7 = ''
    if 'action' in raw and raw.get('action') is not None:
        try:
            _o0 = parse_action(raw.get('action'))
        except Exception as exc:
            return _invalid_rule(index=index, description=_o2, strict=strict, reason='invalid_action', error=str(_o3))
    elif 'replace' in raw:
        _o6 = raw.get('replace')
        if _o6 is None:
            _o7 = ''
        elif isinstance(_o6, str):
            _o7 = _o6
        else:
            return _invalid_rule(index=index, description=_o2, strict=strict, reason='replace_not_string')
        _o0 = ReplacementAction(value=_o7)
    else:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='missing_replace_or_action')
    _o1 = _normalize_case_sensitive(raw.get('caseSensitive'), default=True)
    _o4 = 0 if _o1 else re.IGNORECASE
    try:
        _o5 = re.compile(_o8, flags=_o4)
    except re.error as exc:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='invalid_regex', error=str(_o3), search=_o8, path=str(rules_path))
    return Rule(description=_o2, trigger=_o9, regex=_o5, replacement=_o7, case_sensitive=_o1, action=_o0)

def _normalize_case_sensitive(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        _o0 = value.strip().lower()
        if _o0 in ('true', '1', 'yes', 'y'):
            return True
        if _o0 in ('false', '0', 'no', 'n'):
            return False
    if isinstance(value, (int, float)):
        return bool(value)
    logger.warning('invalid_caseSensitive_value', extra={'value': str(value)})
    return default

def _invalid_rule(*, index: int, description: str, strict: bool, reason: str, error: str | None=None, **extra: Any) -> Rule | None:
    payload: dict[str, Any] = {'index': index, 'reason': reason, 'description': description}
    if error is not None:
        payload['error'] = error
    payload.update(extra)
    _o1 = 'invalid_rule'
    if strict:
        _o0 = ', '.join((f'{k}={payload[k]!r}' for k in sorted(payload.keys())))
        raise ValueError(f'{_o1}: {_o0}')
    logger.warning('invalid_rule_skipped', extra=payload)
    return None
