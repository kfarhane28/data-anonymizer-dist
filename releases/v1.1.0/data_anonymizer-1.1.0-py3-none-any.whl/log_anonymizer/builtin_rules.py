from __future__ import annotations
import logging
import re
from dataclasses import dataclass
from typing import Iterable
from log_anonymizer.rules_loader import Rule
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class BuiltinRulesConfig:
    """
    Controls built-in baseline anonymization rules.
    """
    enabled: bool = True

def default_rules() -> list[Rule]:
    """
    Built-in baseline rules for common sensitive patterns found in logs and text files.

    These provide a baseline; users can override or add rules via `merge_rules()`.

    Note:
        This set is intentionally small. Most patterns (paths, hostnames, etc.) live in
        `examples/rules.json` so users can tailor them to their environments without
        code changes.
    """
    _o0: list[Rule] = []
    _o0.append(_make('user=...', trigger='user=', search='\\buser\\s*=\\s*([A-Za-z0-9._-]+)\\b', replace='user=[USER]', case_sensitive=False))
    _o0.append(_make('username=...', trigger='username=', search='\\busername\\s*=\\s*([A-Za-z0-9._-]+)\\b', replace='username=[USER]', case_sensitive=False))
    _o0.append(_make('password=...', trigger='password=', search='\\bpassword\\s*=\\s*([^\\s\\"\']+)\\b', replace='password=[REDACTED]', case_sensitive=False))
    _o0.append(_make('Kerberos service principal', trigger='@', search='\\b[A-Za-z0-9._-]+/[A-Za-z0-9._-]+@[A-Za-z0-9._-]+\\b', replace='[KRB_PRINCIPAL]', case_sensitive=True))
    return _o0

def merge_rules(*, builtin: Iterable[Rule], user: Iterable[Rule]) -> list[Rule]:
    """
    Merge built-in and user rules.

    Override behavior:
    - If a user rule has the same `description` as a built-in rule, the user rule replaces it.
    - Otherwise, user rules are appended (so they can further transform/redact).
    """
    _o1 = list(builtin)
    _o6 = list(user)
    _o0: dict[str, int] = {}
    for _o2, _o4 in enumerate(_o1):
        if _o4.description:
            _o0[_o4.description] = _o2
    _o3 = list(_o1)
    for _o5 in _o6:
        if _o5.description and _o5.description in _o0:
            _o3[_o0[_o5.description]] = _o5
        else:
            _o3.append(_o5)
    return _o3

def _make(description: str, *, trigger: str, search: str, replace: str, case_sensitive: bool=True) -> Rule:
    _o1 = 0 if case_sensitive else re.IGNORECASE
    try:
        _o2 = re.compile(search, flags=_o1)
    except re.error as exc:
        raise RuntimeError(f'Invalid built-in rule regex ({description}): {_o0}') from _o0
    return Rule(description=description, trigger=trigger, regex=_o2, replacement=replace, case_sensitive=case_sensitive)
