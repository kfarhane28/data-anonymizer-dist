from __future__ import annotations
import logging
import json
import os
import shutil
import tarfile
import tempfile
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass
from pathlib import Path
from threading import Event
from typing import Callable, Iterable, Literal
from log_anonymizer.anonymizer import AnonymizationCancelled, anonymize_file
from log_anonymizer.builtin_rules import default_rules, merge_rules
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns, load_patterns
from log_anonymizer.input_limits import FreeEditionInputLimits, resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer.profiling.profiler import ProfilingConfig, SensitiveDataProfiler
from log_anonymizer.rules_loader import Rule, load_rules
from log_anonymizer.rule_actions import ActionContext
from log_anonymizer.utils.io import is_text_file
from log_anonymizer.licensing.models import Edition
logger = logging.getLogger(__name__)
try:
    from log_anonymizer.progress import ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:
    ProgressReporter = object
    ProgressKind = None
    ProgressStage = None

    def now_event(**kwargs):
        raise RuntimeError('progress module unavailable')

@dataclass(frozen=True)
class ProcessorConfig:
    parallel_enabled: bool = False
    max_workers: int = 5
    exclude_case_insensitive: bool = False
    include_builtin_rules: bool = True
    profile_sensitive_data: bool = False
    profiling_detectors: tuple[str, ...] = ('email', 'ipv4', 'token', 'card')
    profiling_report_path: Path | None = None
    suggest_rules_output_path: Path | None = None
    cancellation_token: 'CancellationToken | None' = None
    rollback_on_cancel: bool = False
    anonymization_salt: str | None = None
    edition: Edition = Edition.free
    input_limits: FreeEditionInputLimits | None = None

@dataclass(frozen=True)
class ProcessorResult:
    output_zip: Path
    total_files: int
    processed_files: int
    failed_files: int
    excluded_files: int
    profiling_report_path: Path | None = None
    suggested_rules_path: Path | None = None
    cancelled: bool = False
    rolled_back: bool = False

class CancellationToken:
    """Thread-safe cancellation flag shared across UI and processing workers."""

    def __init__(self) -> None:
        self._event = Event()

    def cancel(self) -> None:
        self._event.set()

    def is_cancelled(self) -> bool:
        return self._event.is_set()
WorkerOutcome = Literal['processed', 'failed', 'cancelled']

def process(*, input_path: Path, rules_path: Path | None, output_dir: Path, output_zip_path: Path | None=None, exclude_path: Path | None=None, config: ProcessorConfig | None=None, progress: ProgressReporter | None=None) -> Path:
    return process_with_result(input_path=input_path, rules_path=rules_path, output_dir=output_dir, output_zip_path=output_zip_path, exclude_path=exclude_path, config=config, progress=progress).output_zip

def process_with_result(*, input_path: Path, rules_path: Path | None, output_dir: Path, output_zip_path: Path | None=None, exclude_path: Path | None=None, config: ProcessorConfig | None=None, progress: ProgressReporter | None=None) -> ProcessorResult:
    """
    Main processing pipeline.

    Responsibilities:
    1) Load input (file/dir/archive)
    2) Load exclude patterns
    3) Load rules
    4) Filter files
    5) Process each file with anonymizer (parallel)
    6) Write results to a temporary directory
    7) Compress the temporary directory into a tar.gz archive in `output_dir`

    Robustness:
    - Continues on per-file errors (logs and skips failing files)
    - Always cleans up temporary directories created during processing

    Returns:
        ProcessorResult including generated archive file path.
    """
    cfg = config or ProcessorConfig()
    _o0 = ActionContext(salt=cfg.anonymization_salt or '')
    _o7 = False
    _o1a = False
    _o1: list[Path] = []
    _o16 = 0
    _ob = 0
    _o9 = 0
    _o18: Path | None = None
    _o1c: Path | None = None
    _of = output_dir.expanduser().resolve()
    if _of.exists() and (not _of.is_dir()):
        raise ValueError(f'--output must be a directory: {_of}')
    _of.mkdir(parents=True, exist_ok=True)
    _oe = _resolve_output_archive_path(_of, input_path, output_zip_path)
    _oe.parent.mkdir(parents=True, exist_ok=True)
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.FINISHED, message='start'))
    _o1e = load_rules(rules_path) if rules_path is not None else []
    _o1b = merge_rules(builtin=default_rules(), user=_o1e) if cfg.include_builtin_rules else _o1e
    _o1d = Path(tempfile.mkdtemp(prefix='log-anonymizer-out-')).resolve()
    try:
        if progress is not None:
            progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.DISCOVERY, message='start'))
        _oc = resolve_free_input_limits(edition=cfg.edition, override_free_limits=cfg.input_limits)
        with handle_input(input_path, progress=progress, limits=_oc) as _o15:
            _o1f = _o15.working_dir
            _o1 = _o15.files
            logger.info('pipeline_input_ready', extra={'working_dir': str(_o1f), 'files': len(_o1)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.DISCOVERY, current=len(_o1), total=len(_o1), message='done'))
            _o8 = _load_exclude_filter(exclude_path, base_dir=_o1f, case_insensitive=cfg.exclude_case_insensitive)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.FILTERING, current=0, total=len(_o1), message='start'))
            _od, _oa = _filter_included_files(_o1, _o8)
            _o9 = len(_oa)
            _log_file_paths('file_excluded_from_output', _oa, working_dir=_o1f, limit=200, extra={'reason': 'exclude_match'})
            _o2: list[Path] = []
            _o13: list[Path] = []
            for _o10 in _od:
                if is_text_file(_o10):
                    _o2.append(_o10)
                else:
                    _o13.append(_o10)
            _log_file_paths('file_skipped_anonymization_non_text', _o13, working_dir=_o1f, limit=200, extra={'reason': 'non_text'})
            if _o2 and (not _o1b):
                raise ValueError('No valid rules loaded; refusing to process.')
            logger.info('pipeline_files_filtered', extra={'to_process': len(_o2), 'passthrough': len(_o13), 'excluded': _o9, 'total': len(_o1)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.FILTERING, current=len(_od), total=len(_o1), message=f'included={len(_od)} excluded={_o9}'))
            if cfg.profile_sensitive_data and (not _is_cancelled(cfg)):
                _o17 = SensitiveDataProfiler(config=ProfilingConfig(detectors=cfg.profiling_detectors))
                _o19 = _o17.profile_files(_o2, base_dir=_o1f)
                _o18 = cfg.profiling_report_path or (_of / 'profiling_report.json').resolve()
                _o18.write_text(_o19.to_json(), encoding='utf-8')
                logger.info('profiling_report_written', extra={'path': str(_o18)})
                _o1c = cfg.suggest_rules_output_path or (_of / 'suggested_rules.json').resolve()
                _o1c.write_text(json.dumps(_o19.suggested_rules, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                logger.info('suggested_rules_written', extra={'path': str(_o1c)})
            elif _is_cancelled(cfg):
                _o7 = True
            total_in_output = len(_od)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.PROCESSING, current=0, total=total_in_output, message=f'anonymize={len(_o2)} passthrough={len(_o13)}'))
            done_count = 0

            def _on_file_done(ok: bool) -> None:
                nonlocal done_count
                done_count += 1
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.PROCESSING, current=done_count, total=total_in_output, ok=ok))
            _o5, _o4, _o3 = _process_files_parallel(files=_o2, working_dir=_o1f, output_dir=_o1d, rules=_o1b, parallel_enabled=bool(cfg.parallel_enabled), max_workers=int(cfg.max_workers), progress=progress, on_file_done=_on_file_done, cancel_requested=lambda: _is_cancelled(cfg), action_context=_o0)
            _o7 = _o7 or _o3 > 0 or _is_cancelled(cfg)
            _o14 = 0
            _o12 = 0
            _o11 = 0
            if not _o7:
                _o14, _o12, _o11 = _copy_passthrough_files(files=_o13, working_dir=_o1f, output_dir=_o1d, parallel_enabled=bool(cfg.parallel_enabled), max_workers=int(cfg.max_workers), progress=progress, on_file_done=_on_file_done, cancel_requested=lambda: _is_cancelled(cfg))
                _o7 = _o7 or _o11 > 0 or _is_cancelled(cfg)
            _o16 = _o5 + _o14
            _ob = _o4 + _o12
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.PROCESSING, current=done_count, total=total_in_output, message=f'processed={_o16} failed={_ob} cancelled={int(_o7)}'))
            if _o7 and cfg.rollback_on_cancel:
                _o1a = True
                if _oe.exists():
                    _oe.unlink()
            else:
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.ARCHIVE, message='start'))
                try:
                    _o6 = (lambda: _is_cancelled(cfg)) if not _o7 else None
                    _tar_gz_dir(_o1d, _oe, progress=progress, cancel_requested=_o6)
                except AnonymizationCancelled:
                    _o7 = True
                    _o1a = True
                    if _oe.exists():
                        _oe.unlink()
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.ARCHIVE, message='done' if not _o1a else 'cancelled'))
    finally:
        shutil.rmtree(_o1d, ignore_errors=True)
    logger.info('pipeline_done', extra={'output_dir': str(_of), 'output_zip': str(_oe), 'processed': _o16, 'failed': _ob, 'excluded': _o9, 'total': len(_o1), 'cancelled': _o7, 'rolled_back': _o1a})
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.FINISHED, message='done'))
    return ProcessorResult(output_zip=_oe, total_files=len(_o1), processed_files=_o16, failed_files=_ob, excluded_files=_o9, profiling_report_path=_o18, suggested_rules_path=_o1c, cancelled=_o7, rolled_back=_o1a)

def _is_cancelled(cfg: ProcessorConfig) -> bool:
    _o0 = cfg.cancellation_token
    return bool(_o0 is not None and _o0.is_cancelled())

def _load_exclude_filter(exclude_path: Path | None, *, base_dir: Path, case_insensitive: bool) -> ExcludeFilter | None:
    _o1: list[str] = list(default_patterns())
    if exclude_path is not None:
        _o0 = exclude_path.expanduser().resolve()
        if not _o0.exists():
            raise FileNotFoundError(_o0)
        logger.info('exclude_loaded', extra={'path': str(_o0)})
        _o1.extend(load_patterns(_o0))
    if not _o1:
        return None
    return ExcludeFilter.from_patterns(_o1, base_dir=base_dir, case_insensitive=case_insensitive)

def _is_excluded(path: Path, exclude_filter: ExcludeFilter | None) -> bool:
    if exclude_filter is None:
        return False
    return exclude_filter.should_exclude(path)

def _should_anonymize(path: Path, exclude_filter: ExcludeFilter | None) -> bool:
    return not _is_excluded(path, exclude_filter) and is_text_file(path)

def _should_include_in_output(path: Path, exclude_filter: ExcludeFilter | None) -> bool:
    return not _is_excluded(path, exclude_filter)

def _filter_included_files(files: Iterable[Path], exclude_filter: ExcludeFilter | None) -> tuple[list[Path], list[Path]]:
    _o2: list[Path] = []
    _o0: list[Path] = []
    for _o1 in files:
        if _should_include_in_output(_o1, exclude_filter):
            _o2.append(_o1)
        else:
            _o0.append(_o1)
    return (_o2, _o0)

def _copy_passthrough_files(*, files: list[Path], working_dir: Path, output_dir: Path, parallel_enabled: bool, max_workers: int, progress: ProgressReporter | None=None, on_file_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None) -> tuple[int, int, int]:
    if not files:
        return (0, 0, 0)

    def _worker(src: Path) -> WorkerOutcome:
        try:
            if cancel_requested is not None and cancel_requested():
                return 'cancelled'
            _o3 = _safe_relative(src, working_dir)
            _o1 = output_dir / _o3
            _o1.parent.mkdir(parents=True, exist_ok=True)
            if progress is not None:
                try:
                    _o4 = int(src.stat().st_size)
                except OSError:
                    _o4 = None
                progress.emit(now_event(kind=ProgressKind.FILE_START, stage=ProgressStage.PROCESSING, path=_o3.as_posix(), bytes_done=0, bytes_total=_o4, message='passthrough_start'))
            logger.info('file_passthrough_start', extra={'file_name': src.name, 'path': str(src), 'rel': _o3.as_posix(), 'dest': str(_o1)})
            _o0 = _copy_file_atomic(src, _o1, cancel_requested=cancel_requested)
            if not _o0:
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_o3.as_posix(), ok=False, message='passthrough_cancelled'))
                return 'cancelled'
            logger.info('file_passthrough_done', extra={'file_name': src.name, 'path': str(src), 'rel': _o3.as_posix(), 'dest': str(_o1)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_o3.as_posix(), ok=True, message='passthrough_done'))
            return 'processed'
        except Exception as exc:
            logger.exception('file_passthrough_error', extra={'file_name': src.name, 'src': str(src), 'error': str(_o2)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_safe_relative(src, working_dir).as_posix(), ok=False, message='passthrough_failed'))
            return 'failed'
    return _run_file_workers(files=files, worker=_worker, parallel_enabled=parallel_enabled, max_workers=max_workers, phase='passthrough', on_item_done=on_file_done, cancel_requested=cancel_requested)

def _log_file_paths(event: str, files: list[Path], *, working_dir: Path, limit: int, extra: dict[str, object] | None=None) -> None:
    """
    Log per-file paths for pipeline decisions (exclusion, skipping anonymization, etc.).

    Uses INFO level but caps output to avoid flooding logs on huge support bundles.
    """
    if not files:
        return
    _o0 = dict(extra or {})
    _o0.update({'count': len(files), 'limit': limit})
    logger.info(f'{event}_summary', extra=_o0)
    _o3 = 0
    for _o1 in files:
        if _o3 >= limit:
            break
        _o2 = _safe_relative(_o1, working_dir)
        logger.info(event, extra={**(extra or {}), 'file_name': _o1.name, 'path': str(_o1), 'rel': _o2.as_posix()})
        _o3 += 1
    if len(files) > limit:
        logger.info(f'{event}_truncated', extra={**(extra or {}), 'shown': limit, 'remaining': len(files) - limit})

def _process_files_parallel(*, files: list[Path], working_dir: Path, output_dir: Path, rules: list[Rule], parallel_enabled: bool, max_workers: int, progress: ProgressReporter | None=None, on_file_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None, action_context: ActionContext | None=None) -> tuple[int, int, int]:
    if not files:
        return (0, 0, 0)

    def _worker(src: Path) -> WorkerOutcome:
        try:
            if cancel_requested is not None and cancel_requested():
                return 'cancelled'
            _o2 = _safe_relative(src, working_dir)
            _o0 = output_dir / _o2
            try:
                anonymize_file(src, _o0, rules, progress=progress, rel_path=_o2.as_posix(), cancel_requested=cancel_requested, action_context=action_context)
            except TypeError:
                anonymize_file(src, _o0, rules)
            return 'processed'
        except AnonymizationCancelled:
            return 'cancelled'
        except Exception as exc:
            logger.exception('file_error', extra={'src': str(src), 'error': str(_o1)})
            return 'failed'
    return _run_file_workers(files=files, worker=_worker, parallel_enabled=parallel_enabled, max_workers=max_workers, phase='anonymize', on_item_done=on_file_done, cancel_requested=cancel_requested)

def _run_file_workers(*, files: list[Path], worker: Callable[[Path], WorkerOutcome], parallel_enabled: bool, max_workers: int, phase: str, on_item_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None) -> tuple[int, int, int]:
    _o8 = 0
    _o4 = 0
    _o0 = 0
    if not parallel_enabled:
        logger.info('parallel_mode_disabled', extra={'phase': phase, 'mode': 'sequential', 'files': len(files)})
        logger.info('processing_start', extra={'phase': phase, 'files': len(files), 'workers': 1})
        for _o6, _o3 in enumerate(files, start=1):
            if cancel_requested is not None and cancel_requested():
                _o0 += len(files) - (_o6 - 1)
                break
            _o7 = worker(_o3)
            if _o7 == 'processed':
                _o8 += 1
            elif _o7 == 'failed':
                _o4 += 1
            else:
                _o0 += 1
            if on_item_done is not None:
                on_item_done(_o7 == 'processed')
            if _o6 == 1 or _o6 % 100 == 0 or _o6 == len(files):
                logger.info('processing_progress', extra={'phase': phase, 'done': _o6, 'total': len(files), 'processed': _o8, 'failed': _o4, 'cancelled': _o0})
        return (_o8, _o4, _o0)
    if max_workers <= 0:
        raise ValueError(f'max_workers must be >= 1 (got {max_workers})')
    logger.info('parallel_mode_enabled', extra={'phase': phase, 'mode': 'parallel', 'max_workers': max_workers, 'files': len(files)})
    logger.info('processing_start', extra={'phase': phase, 'files': len(files), 'workers': max_workers})
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        pending = set()
        files_iter = iter(files)
        started = 0
        _o1 = 0

        def _submit_next() -> bool:
            nonlocal started
            try:
                _o0 = next(files_iter)
            except StopIteration:
                return False
            pending.add(pool.submit(worker, _o0))
            started += 1
            return True
        while len(pending) < max_workers:
            if cancel_requested is not None and cancel_requested():
                break
            if not _submit_next():
                break
        while pending:
            _o2, pending = wait(pending, return_when=FIRST_COMPLETED)
            for _o5 in _o2:
                _o1 += 1
                try:
                    _o7 = _o5.result()
                except Exception:
                    logger.exception('worker_future_failed', extra={'phase': phase})
                    _o7 = 'failed'
                if _o7 == 'processed':
                    _o8 += 1
                elif _o7 == 'failed':
                    _o4 += 1
                else:
                    _o0 += 1
                if on_item_done is not None:
                    on_item_done(_o7 == 'processed')
                if _o1 == 1 or _o1 % 100 == 0 or _o1 == len(files):
                    logger.info('processing_progress', extra={'phase': phase, 'done': _o1, 'total': len(files), 'processed': _o8, 'failed': _o4, 'cancelled': _o0})
            while len(pending) < max_workers:
                if cancel_requested is not None and cancel_requested():
                    break
                if not _submit_next():
                    break
        _o0 += max(0, len(files) - started)
    return (_o8, _o4, _o0)

def _copy_file_atomic(src: Path, dest: Path, *, cancel_requested: Callable[[], bool] | None=None) -> bool:
    _o1, _o2 = tempfile.mkstemp(prefix=f'.{dest.name}.', suffix='.tmp', dir=str(dest.parent))
    os.close(_o1)
    _o0 = Path(_o2)
    try:
        if cancel_requested is not None and cancel_requested():
            return False
        shutil.copy2(src, _o0)
        if cancel_requested is not None and cancel_requested():
            return False
        os.replace(_o0, dest)
        return True
    finally:
        try:
            if _o0.exists():
                _o0.unlink()
        except OSError:
            pass

def _safe_relative(path: Path, root: Path) -> Path:
    """
    Compute a stable relative path to preserve structure.
    Falls back to filename if `path` is not under `root`.
    """
    try:
        return path.resolve().relative_to(root.resolve())
    except ValueError:
        return Path(path.name)

def _is_tar_gz_path(path: Path) -> bool:
    _o0 = path.name.lower()
    return _o0.endswith('.tar.gz') or _o0.endswith('.tgz')

def _resolve_output_archive_path(output_dir: Path, input_path: Path, output_zip_path: Path | None) -> Path:
    """
    Resolve the output archive path (tar.gz) such that the CLI output is a single archive
    inside `output_dir`.
    """
    output_dir = output_dir.resolve()
    if output_zip_path is None:
        _o0 = _archive_base_name(input_path)
        return (output_dir / f'{_o0}.tar.gz').resolve()
    _o1 = output_zip_path.expanduser().resolve()
    if not _is_tar_gz_path(_o1):
        raise ValueError(f'Output archive must end with .tar.gz or .tgz: {_o1}')
    if output_dir != _o1.parent and output_dir not in _o1.parents:
        raise ValueError(f'Output archive must be inside --output directory: {_o1}')
    return _o1

def _archive_base_name(input_path: Path) -> str:
    _o2 = input_path.expanduser()
    _o1 = _o2.name
    _o0 = _o1.lower()
    if _o0.endswith('.tar.gz'):
        return _o1[:-len('.tar.gz')]
    if _o0.endswith('.tgz'):
        return _o1[:-len('.tgz')]
    if _o0.endswith('.zip'):
        return _o2.stem
    return _o2.stem or _o1

def _tar_gz_dir(root_dir: Path, out_tar_gz: Path, *, progress: ProgressReporter | None=None, cancel_requested: Callable[[], bool] | None=None) -> None:
    _o4, _o5 = tempfile.mkstemp(prefix=f'.{out_tar_gz.name}.', suffix='.tmp', dir=str(out_tar_gz.parent))
    os.close(_o4)
    _o6 = Path(_o5)
    if out_tar_gz.exists():
        out_tar_gz.unlink()
    try:
        with tarfile.open(_o6, mode='w:gz') as _o3:
            _o0 = [_o2 for _o2 in root_dir.rglob('*') if _o2.is_file()]
            _o0.sort(key=lambda p: _o2.relative_to(root_dir).as_posix())
            _o7 = len(_o0)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.ARCHIVE, current=0, total=_o7, message='collect'))
            for _o1, _o2 in enumerate(_o0, start=1):
                if cancel_requested is not None and cancel_requested():
                    raise AnonymizationCancelled('cancelled while writing archive')
                if _o2.resolve() == out_tar_gz.resolve():
                    continue
                _o3.add(_o2, arcname=_o2.relative_to(root_dir).as_posix(), recursive=False)
                if progress is not None:
                    if _o1 == 1 or _o1 == _o7 or _o1 % 200 == 0:
                        progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.ARCHIVE, current=_o1, total=_o7, message='writing'))
        os.replace(_o6, out_tar_gz)
    finally:
        try:
            if _o6.exists():
                _o6.unlink()
        except OSError:
            pass
