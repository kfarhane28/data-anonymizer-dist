from __future__ import annotations
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from log_anonymizer.profiling.detectors import Detection, SensitivePatternDetector, default_detectors
from log_anonymizer.profiling.suggestions import suggested_rules_json
from log_anonymizer.utils.io import open_text_best_effort
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class ProfilingConfig:
    detectors: tuple[str, ...] = ('email', 'ipv4', 'token', 'card')
    max_examples_per_kind: int = 5

@dataclass
class ProfilingReport:
    version: int
    generated_at: str
    detectors: tuple[str, ...]
    files_scanned: int
    matches_by_kind: dict[str, int]
    files_by_kind: dict[str, dict[str, int]]
    masked_examples_by_kind: dict[str, list[str]]
    suggested_rules: dict[str, Any]

    def to_json_obj(self) -> dict[str, Any]:
        return {'version': self.version, 'generated_at': self.generated_at, 'detectors': list(self.detectors), 'files_scanned': self.files_scanned, 'matches_by_kind': dict(sorted(self.matches_by_kind.items(), key=lambda kv: kv[0])), 'files_by_kind': {_o0: dict(sorted(_o1.items(), key=lambda kv: kv[0])) for _o0, _o1 in sorted(self.files_by_kind.items(), key=lambda kv: kv[0])}, 'masked_examples_by_kind': dict(sorted(self.masked_examples_by_kind.items(), key=lambda kv: kv[0])), 'suggested_rules': self.suggested_rules}

    def to_json(self) -> str:
        return json.dumps(self.to_json_obj(), ensure_ascii=False, indent=2) + '\n'

class SensitiveDataProfiler:

    def __init__(self, *, config: ProfilingConfig | None=None) -> None:
        self._config = config or ProfilingConfig()
        self._registry = default_detectors()

    def _selected_detectors(self) -> list[SensitivePatternDetector]:
        _o1: list[SensitivePatternDetector] = []
        for _o2 in self._config.detectors:
            _o0 = self._registry.get(_o2)
            if _o0 is None:
                raise ValueError(f'Unknown detector: {_o2}')
            _o1.append(_o0)
        return _o1

    def profile_text(self, text: str, *, source_name: str='<text>') -> ProfilingReport:
        _o0 = text.splitlines()
        return self._profile_iter(_o0, source_name=source_name)

    def profile_files(self, files: list[Path], *, base_dir: Path | None=None) -> ProfilingReport:
        _o4 = self._selected_detectors()
        _o0: dict[str, int] = {}
        _o6: dict[str, dict[str, int]] = {}
        _o5: dict[str, list[str]] = {}
        _oc = 0
        for _o9 in files:
            _oc += 1
            _oa = _safe_rel(_o9, base_dir)
            try:
                with open_text_best_effort(_o9) as _o7:
                    for _o8 in _o7:
                        for _o1 in _o4:
                            for _o3 in _o1.detect(_o8):
                                _accumulate(_o3, file_key=_oa, counts=_o0, files_by_kind=_o6, examples=_o5, max_examples=self._config.max_examples_per_kind)
            except ValueError:
                logger.info('Skipping non-text file: %s', _o9)
                continue
        _o2 = set(_o0.keys())
        _ob = ProfilingReport(version=1, generated_at=_now_iso(), detectors=tuple(self._config.detectors), files_scanned=_oc, matches_by_kind=_o0, files_by_kind=_o6, masked_examples_by_kind=_o5, suggested_rules=suggested_rules_json(_o2))
        return _ob

    def _profile_iter(self, lines: list[str], *, source_name: str) -> ProfilingReport:
        _o4 = self._selected_detectors()
        _o0: dict[str, int] = {}
        _o6: dict[str, dict[str, int]] = {}
        _o5: dict[str, list[str]] = {}
        for _o7 in lines:
            for _o1 in _o4:
                for _o3 in _o1.detect(_o7):
                    _accumulate(_o3, file_key=source_name, counts=_o0, files_by_kind=_o6, examples=_o5, max_examples=self._config.max_examples_per_kind)
        _o2 = set(_o0.keys())
        return ProfilingReport(version=1, generated_at=_now_iso(), detectors=tuple(self._config.detectors), files_scanned=1, matches_by_kind=_o0, files_by_kind=_o6, masked_examples_by_kind=_o5, suggested_rules=suggested_rules_json(_o2))

def _accumulate(detection: Detection, *, file_key: str, counts: dict[str, int], files_by_kind: dict[str, dict[str, int]], examples: dict[str, list[str]], max_examples: int) -> None:
    _o0 = detection.kind
    counts[_o0] = counts.get(_o0, 0) + 1
    files_by_kind.setdefault(_o0, {})
    files_by_kind[_o0][file_key] = files_by_kind[_o0].get(file_key, 0) + 1
    if max_examples <= 0:
        return
    examples.setdefault(_o0, [])
    if len(examples[_o0]) < max_examples and detection.masked_example not in examples[_o0]:
        examples[_o0].append(detection.masked_example)

def _safe_rel(path: Path, base_dir: Path | None) -> str:
    try:
        if base_dir is None:
            return str(path)
        return path.resolve().relative_to(base_dir.resolve()).as_posix()
    except Exception:
        return str(path)

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
