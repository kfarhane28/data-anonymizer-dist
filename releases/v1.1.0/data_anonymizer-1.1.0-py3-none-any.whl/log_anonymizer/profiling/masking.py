from __future__ import annotations
import re

def mask_email(value: str) -> str:
    _o2 = value.strip()
    if '@' not in _o2:
        return '[EMAIL]'
    _o1, _o0 = _o2.split('@', 1)
    _o1 = _o1.strip()
    _o0 = _o0.strip()
    if not _o0:
        return '[EMAIL]'
    if not _o1:
        return f'***@{_o0}'
    return f'{_o1[:1]}***@{_o0}'
_ipv4_rx = re.compile('^(?P<a>\\d{1,3})\\.(?P<b>\\d{1,3})\\.(?P<c>\\d{1,3})\\.(?P<d>\\d{1,3})$')

def mask_ipv4(value: str) -> str:
    _o2 = _ipv4_rx.match(value.strip())
    if not _o2:
        return '[IP]'
    _o0 = _o2.group('a')
    _o1 = _o2.group('d')
    return f'{_o0}.***.***.{_o1}'

def mask_token(value: str) -> str:
    _o2 = value.strip()
    if len(_o2) <= 8:
        return '***'
    _o0 = _o2[:3]
    _o1 = _o2[-4:]
    return f'{_o0}-***{_o1}'

def mask_card_number(value: str) -> str:
    _o0 = ''.join((ch for ch in value if ch.isdigit()))
    if len(_o0) < 4:
        return '****'
    return f'**** **** **** {_o0[-4:]}'
