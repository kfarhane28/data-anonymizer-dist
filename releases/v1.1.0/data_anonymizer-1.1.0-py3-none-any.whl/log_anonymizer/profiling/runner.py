from __future__ import annotations
import json
import logging
from dataclasses import dataclass
from pathlib import Path
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns, load_patterns
from log_anonymizer.input_handler import handle_input
from log_anonymizer.profiling.profiler import ProfilingConfig, SensitiveDataProfiler
from log_anonymizer.utils.io import is_text_file
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class ProfilingRunResult:
    profiling_report_path: Path
    suggested_rules_path: Path
    total_files: int
    excluded_files: int
    profiled_files: int

def run_sensitive_data_profiling(*, input_path: Path, output_dir: Path, exclude_path: Path | None=None, exclude_case_insensitive: bool=False, detectors: tuple[str, ...]=('email', 'ipv4', 'token', 'card'), profiling_report_path: Path | None=None, suggest_rules_output_path: Path | None=None) -> ProfilingRunResult:
    """
    Profiling-only pipeline:
    - list input files (dir/file/archive)
    - apply excludes (built-in + optional user file)
    - scan remaining text files for potential sensitive patterns
    - write report + suggested rules JSON files
    """
    input_path = input_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    _o8 = profiling_report_path.expanduser().resolve() if profiling_report_path is not None else (output_dir / 'profiling_report.json').resolve()
    _o9 = suggest_rules_output_path.expanduser().resolve() if suggest_rules_output_path is not None else (output_dir / 'suggested_rules.json').resolve()
    with handle_input(input_path) as _o5:
        _oa = _o5.working_dir
        _o0 = _o5.files
        _o4 = list(default_patterns())
        if exclude_path is not None:
            _o4.extend(load_patterns(exclude_path.expanduser().resolve()))
        _o1 = ExcludeFilter.from_patterns(_o4, base_dir=_oa, case_insensitive=exclude_case_insensitive) if _o4 else None
        _o3 = [_o2 for _o2 in _o0 if is_text_file(_o2) and (not (_o1 and _o1.should_exclude(_o2)))]
        _o6 = SensitiveDataProfiler(config=ProfilingConfig(detectors=detectors))
        _o7 = _o6.profile_files(_o3, base_dir=_oa)
    _o8.write_text(_o7.to_json(), encoding='utf-8')
    _o9.write_text(json.dumps(_o7.suggested_rules, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    logger.info('profiling_only_done', extra={'report': str(_o8), 'suggested_rules': str(_o9), 'total_files': len(_o0), 'excluded': len(_o0) - len(_o3), 'profiled': len(_o3)})
    return ProfilingRunResult(profiling_report_path=_o8, suggested_rules_path=_o9, total_files=len(_o0), excluded_files=len(_o0) - len(_o3), profiled_files=len(_o3))
