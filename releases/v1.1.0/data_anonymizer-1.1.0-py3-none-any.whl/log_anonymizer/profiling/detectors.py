from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Iterable, Protocol
from log_anonymizer.profiling.masking import mask_card_number, mask_email, mask_ipv4, mask_token

@dataclass(frozen=True)
class Detection:
    detector: str
    kind: str
    masked_example: str

class SensitivePatternDetector(Protocol):
    name: str
    kinds: tuple[str, ...]

    def detect(self, line: str) -> Iterable[Detection]:
        ...

class EmailDetector:
    name = 'email'
    kinds = ('email',)

    def __init__(self) -> None:
        self._rx = re.compile('\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b')

    def detect(self, line: str) -> Iterable[Detection]:
        if '@' not in line:
            return []
        _o1: list[Detection] = []
        for _o0 in self._rx.finditer(line):
            _o1.append(Detection(detector=self.name, kind='email', masked_example=mask_email(_o0.group(0))))
        return _o1

class IPv4Detector:
    name = 'ipv4'
    kinds = ('ipv4',)

    def __init__(self) -> None:
        self._rx = re.compile('\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b')

    def detect(self, line: str) -> Iterable[Detection]:
        if '.' not in line:
            return []
        _o1: list[Detection] = []
        for _o0 in self._rx.finditer(line):
            _o1.append(Detection(detector=self.name, kind='ipv4', masked_example=mask_ipv4(_o0.group(0))))
        return _o1

class TokenDetector:
    name = 'token'
    kinds = ('bearer_token', 'kv_secret', 'probable_token')

    def __init__(self) -> None:
        self._bearer = re.compile('\\bBearer\\s+([A-Za-z0-9._-]{10,})\\b', flags=re.IGNORECASE)
        self._kv = re.compile('\\b(api[_-]?key|token|secret|password)\\s*=\\s*([^\\s\\"\']{8,})\\b', flags=re.IGNORECASE)
        self._probable = re.compile('\\b[A-Za-z0-9+/=_-]{24,}\\b')

    @staticmethod
    def _is_probably_token(s: str) -> bool:
        if len(s) < 24:
            return False
        _o0 = any((ch.isalpha() for ch in s))
        _o1 = any((ch.isdigit() for ch in s))
        return _o0 and _o1

    def detect(self, line: str) -> Iterable[Detection]:
        _o2: list[Detection] = []
        if 'bearer' in line.lower():
            for _o1 in self._bearer.finditer(line):
                _o3 = _o1.group(1)
                _o2.append(Detection(detector=self.name, kind='bearer_token', masked_example=f'Bearer {mask_token(_o3)}'))
        if '=' in line:
            for _o1 in self._kv.finditer(line):
                _o0 = _o1.group(1)
                _o4 = _o1.group(2)
                _o2.append(Detection(detector=self.name, kind='kv_secret', masked_example=f'{_o0}={mask_token(_o4)}'))
        for _o1 in self._probable.finditer(line):
            _o3 = _o1.group(0)
            if not self._is_probably_token(_o3):
                continue
            _o2.append(Detection(detector=self.name, kind='probable_token', masked_example=mask_token(_o3)))
        return _o2

class CardNumberDetector:
    name = 'card'
    kinds = ('card_number',)

    def __init__(self) -> None:
        self._rx = re.compile('\\b(?:\\d[ -]*?){13,19}\\b')

    @staticmethod
    def _luhn_ok(number: str) -> bool:
        _o4 = [int(_o0) for _o0 in number if _o0.isdigit()]
        if len(_o4) < 13 or len(_o4) > 19:
            return False
        _o1 = 0
        _o6 = len(_o4) % 2
        for _o5, _o2 in enumerate(_o4):
            if _o5 % 2 == _o6:
                _o3 = _o2 * 2
                _o1 += _o3 - 9 if _o3 > 9 else _o3
            else:
                _o1 += _o2
        return _o1 % 10 == 0

    def detect(self, line: str) -> Iterable[Detection]:
        _o2: list[Detection] = []
        for _o1 in self._rx.finditer(line):
            _o3 = _o1.group(0)
            _o0 = ''.join((ch for ch in _o3 if ch.isdigit()))
            if not _o0:
                continue
            if not self._luhn_ok(_o0):
                continue
            _o2.append(Detection(detector=self.name, kind='card_number', masked_example=mask_card_number(_o0)))
        return _o2

def default_detectors() -> dict[str, SensitivePatternDetector]:
    _o1: list[SensitivePatternDetector] = [EmailDetector(), IPv4Detector(), TokenDetector(), CardNumberDetector()]
    return {_o0.name: _o0 for _o0 in _o1}
