from __future__ import annotations
import importlib.util
import sys

def main(argv: list[str] | None=None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if '--version' in argv:
        from log_anonymizer import __version__
        print(__version__)
        return
    if '--check' in argv:
        argv = [_o0 for _o0 in argv if _o0 != '--check']
        try:
            import streamlit
            import pandas
        except ModuleNotFoundError:
            raise SystemExit('UI dependencies are not installed.\nInstall with: pip install "data-anonymizer[ui]" (legacy: "log-anonymizer[ui]")') from None
        try:
            import log_anonymizer.ui_app
        except Exception as exc:
            raise SystemExit(f'UI import check failed: {_o1}') from _o1
        try:
            from importlib import resources
            _o2 = resources.files('log_anonymizer').joinpath('assets/logo.svg')
            if not _o2.is_file():
                raise SystemExit('UI asset missing: log_anonymizer/assets/logo.svg')
        except Exception as exc:
            raise SystemExit(f'UI asset check failed: {_o1}') from _o1
        print('OK')
        return
    try:
        import streamlit.web.cli as stcli
    except ModuleNotFoundError:
        raise SystemExit('UI dependencies are not installed.\nInstall with: pip install "data-anonymizer[ui]" (legacy: "log-anonymizer[ui]")') from None
    _o3 = importlib.util.find_spec('log_anonymizer.ui_app')
    if _o3 is None or _o3.origin is None:
        raise SystemExit('Could not locate `log_anonymizer.ui_app` to launch the UI.')
    sys.argv = ['streamlit', 'run', _o3.origin, *argv]
    stcli.main()
