from __future__ import annotations
import difflib
from dataclasses import dataclass

@dataclass(frozen=True)
class ChangedSpan:
    """
    Half-open span [start, end) in the anonymized line.

    Used by the Console preview to highlight which output segments were
    transformed by anonymization.
    """
    start: int
    end: int

def compute_changed_spans(original_line: str, anonymized_line: str) -> tuple[ChangedSpan, ...]:
    """
    Compute output-side spans that differ from the input line.

    Notes:
    - Only highlights what exists in the anonymized output (replace/insert).
    - Deletes can't be highlighted because the content is removed.
    """
    if original_line == anonymized_line:
        return ()
    _o7 = difflib.SequenceMatcher(a=original_line, b=anonymized_line, autojunk=False)
    _o8: list[ChangedSpan] = []
    for _o9, _o0, _o1, _o2, _o3 in _o7.get_opcodes():
        if _o9 in {'replace', 'insert'} and _o2 != _o3:
            _o8.append(ChangedSpan(start=_o2, end=_o3))
    if not _o8:
        return ()
    _o8.sort(key=lambda s: (_o6.start, _o6.end))
    _o5: list[ChangedSpan] = [_o8[0]]
    for _o6 in _o8[1:]:
        _o4 = _o5[-1]
        if _o6.start <= _o4.end:
            _o5[-1] = ChangedSpan(start=_o4.start, end=max(_o4.end, _o6.end))
        else:
            _o5.append(_o6)
    return tuple(_o5)
