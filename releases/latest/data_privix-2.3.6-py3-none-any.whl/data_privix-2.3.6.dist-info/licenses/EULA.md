# MagicByte Consulting — End User License Agreement (EULA)

**IMPORTANT — READ CAREFULLY.** This End User License Agreement (“Agreement”) is a legal agreement between you (either an individual or an entity) (“You”) and **MagicByte Consulting** (“MagicByte”) for the use of the **Data Privix** software, including any updates, components, and accompanying documentation (collectively, the “Software”).

By installing, copying, or using the Software, You agree to be bound by this Agreement. If You do not agree, do not install or use the Software.

This is a first-version EULA intended for legal review. Placeholders are marked as such.

## 1) Ownership

The Software is proprietary and confidential. MagicByte (and/or its licensors) owns all right, title, and interest in and to the Software, including all intellectual property rights. This Agreement grants You limited rights to use the Software; it does not transfer any ownership.

## 2) License grant (Free vs Pro)

The Software has two editions:

- **Free edition**: A limited, proprietary license to use the Software without a license key, subject to the restrictions in this Agreement and any accompanying written terms.
- **Pro/Premium edition (“Pro”)**: Enabled only when a valid commercial license key is installed/active. Pro may unlock additional features and/or higher limits.

Subject to Your compliance with this Agreement, MagicByte grants You a **non-exclusive, non-transferable, revocable** license to install and use the Software solely for Your internal business purposes (or personal use, if applicable), in accordance with the edition and any commercial terms You have purchased.

## 3) Activation and license keys

If You have purchased Pro, MagicByte may provide a license key (e.g., a signed license string) that activates Pro functionality. You are responsible for keeping license keys confidential and using them only as permitted by Your commercial license terms.

If a license key is missing, invalid, or expired, the Software will operate in Free edition mode.

## 4) Restrictions

Unless MagicByte explicitly permits otherwise in writing, You may not:

1. Copy, reproduce, publish, redistribute, or make the Software available to any third party (including by posting it to public repositories, file sharing, or app stores).
2. Modify, translate, adapt, or create derivative works of the Software.
3. Reverse engineer, decompile, disassemble, or otherwise attempt to derive source code, algorithms, or underlying ideas from the Software, except to the extent such restriction is prohibited by applicable law.
4. Remove, alter, or obscure any proprietary notices or labels.
5. Use the Software to provide a hosted service, time-sharing, service bureau, or SaaS offering to third parties, unless explicitly licensed for such use.
6. Circumvent or attempt to circumvent technical limitations, feature gating, or license enforcement mechanisms.

## 5) Free edition terms (high-level)

The Free edition is proprietary software. “Free” means the Software may be used without a license key under this Agreement; it does **not** mean open-source. MagicByte may impose reasonable limitations for the Free edition (such as feature limitations, usage limits, or support limitations) and may change such limitations in future releases.

## 6) Updates and changes

MagicByte may provide updates, patches, or new versions of the Software. Unless otherwise stated in writing, updates are subject to this Agreement. Some updates may change functionality, including edition capabilities.

## 7) Confidentiality

The Software and any non-public information about the Software are MagicByte’s confidential information. You agree to protect MagicByte’s confidential information using at least reasonable care and not to disclose it to third parties, except as permitted by applicable law or a written agreement with MagicByte.

## 8) Support

Support, if any, is provided only under a separate written agreement (e.g., a commercial support contract). The Free edition may receive limited or no support.

## 9) Term and termination

This Agreement is effective until terminated. MagicByte may terminate this Agreement immediately if You breach any term. Upon termination, You must stop using the Software and destroy all copies in Your possession or control.

## 10) Warranty disclaimer

TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED “AS IS” AND “AS AVAILABLE,” WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS, IMPLIED, OR STATUTORY, INCLUDING WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. MAGICBYTE DOES NOT WARRANT THAT THE SOFTWARE WILL BE ERROR-FREE OR UNINTERRUPTED.

## 11) Limitation of liability

TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT WILL MAGICBYTE (OR ITS LICENSORS) BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR EXEMPLARY DAMAGES, OR FOR ANY LOSS OF PROFITS, REVENUE, DATA, OR GOODWILL, ARISING OUT OF OR RELATING TO THE SOFTWARE OR THIS AGREEMENT, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

MAGICBYTE’S TOTAL LIABILITY FOR ALL CLAIMS ARISING OUT OF OR RELATING TO THIS AGREEMENT OR THE SOFTWARE WILL NOT EXCEED THE AMOUNTS PAID BY YOU TO MAGICBYTE FOR THE SOFTWARE IN THE TWELVE (12) MONTHS PRECEDING THE EVENT GIVING RISE TO THE CLAIM, OR ONE HUNDRED U.S. DOLLARS (USD $100) IF YOU DID NOT PAY FOR THE SOFTWARE, WHICHEVER IS GREATER. (PLACEHOLDER — LEGAL REVIEW RECOMMENDED.)

## 12) Export and compliance

You agree to comply with all applicable laws and regulations, including export control laws, sanctions, and privacy regulations, as applicable to Your use of the Software.

## 13) Governing law; venue

Governing law and venue are **placeholders** pending legal review:

- Governing law: [INSERT JURISDICTION]
- Venue: [INSERT VENUE]

## 14) Entire agreement; severability

This Agreement is the entire agreement between You and MagicByte regarding the Software and supersedes any prior or contemporaneous agreements or understandings. If any provision is found unenforceable, the remainder will remain in effect.

## 15) Contact

MagicByte Consulting (placeholder contact)

- Licensing / sales: `sales@magicbyte.example`
- Support: `support@magicbyte.example`
