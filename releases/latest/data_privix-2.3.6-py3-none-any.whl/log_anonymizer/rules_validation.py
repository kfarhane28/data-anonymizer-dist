from __future__ import annotations
import json
from log_anonymizer.rule_actions import parse_action

def validate_rules_json_bytes(raw: bytes) -> str | None:
    """
    Validate that rules.json bytes are UTF-8 JSON and match a supported schema.

    Supported:
    - version 1 (legacy): rule uses `search` + `replace`
    - version 2 (action-based): rule uses `search` + `action`

    Notes:
    - This is intentionally stricter than the runtime loader in non-strict mode, because UIs
      should surface configuration errors early and clearly.
    - The runtime loader (`log_anonymizer.rules_loader.load_rules`) is the source of truth.
    """
    try:
        _o3 = json.loads(raw.decode('utf-8'))
    except UnicodeDecodeError:
        return 'not valid UTF-8'
    except json.JSONDecodeError as _o1:
        return f'invalid JSON: {_o1}'
    if not isinstance(_o3, dict):
        return 'root must be a JSON object'
    _oa = _o3.get('version', 1)
    try:
        _o9 = int(_oa)
    except Exception:
        return 'version must be 1 or 2'
    if _o9 not in (1, 2):
        return 'version must be 1 or 2'
    _o7 = _o3.get('rules')
    if not isinstance(_o7, list):
        return 'rules must be a list'
    for _o2, _o5 in enumerate(_o7):
        if not isinstance(_o5, dict):
            return f'rules[{_o2}] must be an object'
        _o8 = _o5.get('search')
        if not isinstance(_o8, str) or not _o8.strip():
            return f'rules[{_o2}].search must be a non-empty string'
        if 'enable' in _o5 and _o5['enable'] is not None and (not isinstance(_o5['enable'], (bool, str, int, float))):
            return f'rules[{_o2}].enable must be boolean'
        if 'enabled' in _o5 and _o5['enabled'] is not None and (not isinstance(_o5['enabled'], (bool, str, int, float))):
            return f'rules[{_o2}].enabled must be boolean'
        if 'priority' in _o5:
            _o4 = _o5.get('priority')
            if _o4 is None or isinstance(_o4, bool) or (not isinstance(_o4, int)):
                return f'rules[{_o2}].priority must be an integer'
        if 'trigger' in _o5 and _o5['trigger'] is not None and (not isinstance(_o5['trigger'], str)):
            return f'rules[{_o2}].trigger must be a string'
        if 'description' in _o5 and _o5['description'] is not None and (not isinstance(_o5['description'], str)):
            return f'rules[{_o2}].description must be a string'
        if 'caseSensitive' in _o5 and _o5['caseSensitive'] is not None and (not isinstance(_o5['caseSensitive'], (str, bool, int, float))):
            return f'rules[{_o2}].caseSensitive must be boolean or string'
        _o0 = _o5.get('action')
        if _o0 is not None:
            try:
                parse_action(_o0)
            except Exception as _o1:
                return f'rules[{_o2}].action invalid: {_o1}'
            continue
        if 'replace' not in _o5:
            return f"rules[{_o2}] missing 'replace' (or provide 'action')"
        _o6 = _o5.get('replace')
        if _o6 is not None and (not isinstance(_o6, str)):
            return f'rules[{_o2}].replace must be a string'
    return None
