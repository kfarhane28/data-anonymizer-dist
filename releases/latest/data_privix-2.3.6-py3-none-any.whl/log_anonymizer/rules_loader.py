from __future__ import annotations
import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from log_anonymizer.rule_actions import ReplacementAction, RuleAction, parse_action
from log_anonymizer.rules_engine.behavior import RuleOutputBehavior, parse_output_behavior
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class Rule:
    """
    A single anonymization rule.

    Attributes:
        description: Human-readable description (may be empty).
        trigger: Optional substring used as a fast pre-check before running the regex.
        regex: Compiled regex used for the replacement.
        replacement: Replacement string passed to `re.sub`.
        case_sensitive: Whether trigger check and regex are case sensitive.
        action: Optional action strategy controlling how replacements are produced.
        enabled: Whether the rule is active (default: true). Disabled rules are ignored.
        priority: Precedence for evaluation (default: 0). Higher priority rules run first.
        original_index: Stable tie-breaker for equal priority (lower wins); derived from file/merge order.
    """
    description: str
    trigger: str
    regex: re.Pattern[str]
    replacement: str
    case_sensitive: bool
    action: RuleAction | None = None
    enabled: bool = True
    priority: int = 0
    original_index: int = 0
    outputs: frozenset[RuleOutputBehavior] = frozenset((RuleOutputBehavior.text_replacement, RuleOutputBehavior.pdf_redaction))

    def __post_init__(self) -> None:
        if self.action is None:
            object.__setattr__(self, 'action', ReplacementAction(value=self.replacement))
        elif isinstance(self.action, ReplacementAction) and self.replacement != self.action.value:
            object.__setattr__(self, 'replacement', self.action.value)
        if getattr(self, 'outputs', None) is None:
            object.__setattr__(self, 'outputs', frozenset((RuleOutputBehavior.text_replacement, RuleOutputBehavior.pdf_redaction)))

    def triggered_by(self, line: str) -> bool:
        if not self.enabled:
            return False
        if not self.trigger:
            return True
        if self.case_sensitive:
            return self.trigger in line
        return self.trigger.lower() in line.lower()

def load_rules(rules_path: Path, *, strict: bool=False) -> list[Rule]:
    """
    Load and validate rules from a JSON file.

    Expected format:
    {
      "version": 1,   # or 2
      "rules": [
        {
          "description": "...",
          "trigger": "...",
          "search": "...",
          "enable": true,               # optional; when omitted defaults to true
          "priority": 10,               # optional; higher runs first (default: 0)
          "replace": "...",              # legacy fixed replacement
          "action": {"type": "...", ...} # new action-based format
          "caseSensitive": "false"
        }
      ]
    }

    Behavior:
    - Validates presence of required fields.
    - Normalizes `caseSensitive` to a boolean (default: true).
    - Compiles regex patterns; invalid rules are skipped with a warning.
    - When `strict=True`, invalid rules raise ValueError with explicit context.
    """
    _o0 = _load_json(rules_path)
    _o8 = _o0.get('version', 1)
    try:
        _o7 = int(_o8)
    except Exception as _o1:
        raise ValueError(f'Unsupported rules version: {_o8!r} (expected 1 or 2)') from _o1
    if _o7 not in (1, 2):
        raise ValueError(f'Unsupported rules version: {_o7!r} (expected 1 or 2)')
    _o5 = _o0.get('rules')
    if not isinstance(_o5, list):
        raise ValueError("'rules' must be a list")
    _o3: list[Rule] = []
    for _o2, _o4 in enumerate(_o5):
        _o6 = _parse_rule(_o4, index=_o2, rules_path=rules_path, strict=strict)
        if _o6 is not None:
            _o3.append(_o6)
    logger.info('rules_loaded', extra={'path': str(rules_path), 'count': len(_o3)})
    return _o3

def _load_json(path: Path) -> dict[str, Any]:
    try:
        _o0 = json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:
        raise
    except json.JSONDecodeError as _o1:
        raise ValueError(f'Invalid JSON in {path}: {_o1}') from _o1
    if not isinstance(_o0, dict):
        raise ValueError('rules.json must contain a JSON object')
    return _o0

def _parse_rule(raw: Any, *, index: int, rules_path: Path, strict: bool) -> Rule | None:
    if not isinstance(raw, dict):
        return _invalid_rule(index=index, description='', strict=strict, reason='not_an_object')
    _o2 = str(raw.get('description') or '')
    _of = raw.get('trigger', '')
    if _of is None:
        _oe = ''
    elif isinstance(_of, str):
        _oe = _of
    else:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='trigger_not_string')
    _od = raw.get('search')
    if not isinstance(_od, str) or not _od:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='missing_search')
    _o4 = raw.get('enable', raw.get('enabled', None))
    _o3 = _normalize_enabled(_o4, default=True)
    if 'priority' not in raw:
        _o8 = 0
    else:
        _o9 = raw.get('priority')
        _o8 = _normalize_priority(_o9)
        if _o8 is None:
            return _invalid_rule(index=index, description=_o2, strict=strict, reason='priority_not_int', value=str(_o9))
    _o0: RuleAction | None = None
    _oc = ''
    if 'action' in raw and raw.get('action') is not None:
        try:
            _o0 = parse_action(raw.get('action'))
        except Exception as _o5:
            return _invalid_rule(index=index, description=_o2, strict=strict, reason='invalid_action', error=str(_o5))
    elif 'replace' in raw:
        _ob = raw.get('replace')
        if _ob is None:
            _oc = ''
        elif isinstance(_ob, str):
            _oc = _ob
        else:
            return _invalid_rule(index=index, description=_o2, strict=strict, reason='replace_not_string')
        _o0 = ReplacementAction(value=_oc)
    else:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='missing_replace_or_action')
    _o1 = _normalize_case_sensitive(raw.get('caseSensitive'), default=True)
    _o6 = 0 if _o1 else re.IGNORECASE
    try:
        _oa = re.compile(_od, flags=_o6)
    except re.error as _o5:
        return _invalid_rule(index=index, description=_o2, strict=strict, reason='invalid_regex', error=str(_o5), search=_od, path=str(rules_path))
    _o7 = _parse_outputs(raw.get('outputs'), raw.get('output'), strict=strict)
    return Rule(description=_o2, trigger=_oe, regex=_oa, replacement=_oc, case_sensitive=_o1, action=_o0, enabled=_o3, priority=_o8, original_index=int(index), outputs=_o7)

def _normalize_case_sensitive(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        _o0 = value.strip().lower()
        if _o0 in ('true', '1', 'yes', 'y'):
            return True
        if _o0 in ('false', '0', 'no', 'n'):
            return False
    if isinstance(value, (int, float)):
        return bool(value)
    logger.warning('invalid_caseSensitive_value', extra={'value': str(value)})
    return default

def _normalize_enabled(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        _o0 = value.strip().lower()
        if _o0 in ('true', '1', 'yes', 'y'):
            return True
        if _o0 in ('false', '0', 'no', 'n'):
            return False
    if isinstance(value, (int, float)):
        return bool(value)
    logger.warning('invalid_enable_value', extra={'value': str(value)})
    return default

def _normalize_priority(value: Any) -> int | None:
    """
    Strict, predictable integer parsing:
    - Accept only int (but not bool)
    - Reject null/float/string/etc. (return None so caller can surface a clear error)
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return int(value)
    return None

def _parse_outputs(outputs_raw: Any, output_raw: Any, *, strict: bool) -> frozenset[RuleOutputBehavior]:
    """
    Supports either:
      - "output": "text" | "pdf" | "text_replacement" | "pdf_redaction"
      - "outputs": ["text", "pdf", ...]

    Backward compatibility:
      - when missing/invalid, defaults to supporting both.
    """
    _o0 = frozenset((RuleOutputBehavior.text_replacement, RuleOutputBehavior.pdf_redaction))
    if outputs_raw is None and output_raw is None:
        return _o0
    _o3: list[str] = []
    if output_raw is not None:
        if not isinstance(output_raw, str):
            if strict:
                raise ValueError("'output' must be a string")
            logger.warning('invalid_rule_output_value', extra={'value': str(output_raw)})
            return _o0
        _o3 = [output_raw]
    else:
        if not isinstance(outputs_raw, list):
            if strict:
                raise ValueError("'outputs' must be a list of strings")
            logger.warning('invalid_rule_outputs_value', extra={'value': str(outputs_raw)})
            return _o0
        for _o4 in outputs_raw:
            if isinstance(_o4, str):
                _o3.append(_o4)
            else:
                if strict:
                    raise ValueError("'outputs' must be a list of strings")
                logger.warning('invalid_rule_outputs_entry', extra={'value': str(_o4)})
                return _o0
    _o2: set[RuleOutputBehavior] = set()
    for _o4 in _o3:
        try:
            _o2.add(parse_output_behavior(_o4))
        except Exception as _o1:
            if strict:
                raise
            logger.warning('invalid_rule_output_behavior', extra={'value': _o4, 'error': str(_o1)})
            return _o0
    if not _o2:
        return _o0
    return frozenset(_o2)

def _invalid_rule(*, index: int, description: str, strict: bool, reason: str, error: str | None=None, **extra: Any) -> Rule | None:
    payload: dict[str, Any] = {'index': index, 'reason': reason, 'description': description}
    if error is not None:
        payload['error'] = error
    payload.update(extra)
    _o1 = 'invalid_rule'
    if strict:
        _o0 = ', '.join((f'{k}={payload[k]!r}' for k in sorted(payload.keys())))
        raise ValueError(f'{_o1}: {_o0}')
    logger.warning('invalid_rule_skipped', extra=payload)
    return None
