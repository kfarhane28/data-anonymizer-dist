from __future__ import annotations
import sys
from log_anonymizer.cli import main as _cli_main
from log_anonymizer.ui import main as _ui_main

def _warn_deprecated(*, old: str, new: str) -> None:
    sys.stderr.write(f'{old} is deprecated; use {new} instead.\n')

def data_privix() -> None:
    _cli_main()

def data_privix_ui() -> None:
    _ui_main()

def data_anonymizer() -> None:
    _warn_deprecated(old='data-anonymizer', new='data-privix')
    _cli_main()

def data_anonymizer_ui() -> None:
    _warn_deprecated(old='data-anonymizer-ui', new='data-privix-ui')
    _ui_main()

def log_anonymizer() -> None:
    _warn_deprecated(old='log-anonymizer', new='data-privix')
    _cli_main()

def log_anonymizer_ui() -> None:
    _warn_deprecated(old='log-anonymizer-ui', new='data-privix-ui')
    _ui_main()
