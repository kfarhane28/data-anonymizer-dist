from __future__ import annotations
import logging
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, TextIO
from log_anonymizer.rules_loader import Rule
from log_anonymizer.rule_actions import ActionContext
from log_anonymizer.rules_engine import RuleOutputBehavior, order_rules_for_evaluation, rule_key
from log_anonymizer.utils.io import is_text_file
logger = logging.getLogger(__name__)
try:
    from log_anonymizer.progress import ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:
    ProgressReporter = object
    ProgressKind = None
    ProgressStage = None

    def now_event(**kwargs):
        raise RuntimeError('progress module unavailable')

@dataclass(frozen=True)
class AnonymizeFileStats:
    input_path: Path
    output_path: Path
    total_replacements: int
    triggered_rules: tuple[str, ...]
    replacements_by_rule: dict[str, int]

@dataclass
class AnonymizeTextStats:
    total_replacements: int
    triggered_rules: tuple[str, ...]
    replacements_by_rule: dict[str, int]

@dataclass
class _AnonymizationAccumulator:
    triggered: set[str]
    replacements_by_rule: dict[str, int]
    total_replacements: int

class AnonymizationCancelled(Exception):
    """Raised when anonymization is cancelled before output is committed."""

def anonymize_text_block(text: str, rules: Iterable[Rule], *, action_context: ActionContext | None=None) -> tuple[str, AnonymizeTextStats]:
    """
    Anonymize a block of text line-by-line using the provided rules.

    This is the same anonymization logic as `anonymize_file`, but in-memory.
    Newlines are preserved.
    """
    _o0 = text.splitlines(keepends=True)
    _o1, _o2 = _anonymize_lines(_o0, rules, action_context=action_context)
    return (''.join(_o1), _o2)

def _anonymize_lines(lines: Iterable[str], rules: Iterable[Rule], *, action_context: ActionContext | None) -> tuple[list[str], AnonymizeTextStats]:
    _o3 = order_rules_for_evaluation(rules)
    _o1 = action_context or ActionContext()
    _o0 = _AnonymizationAccumulator(triggered=set(), replacements_by_rule={}, total_replacements=0)
    _o2 = list(_iter_anonymized_lines(lines, _o3, _o0, _o1))
    _o4 = AnonymizeTextStats(total_replacements=_o0.total_replacements, triggered_rules=tuple(sorted(_o0.triggered)), replacements_by_rule=dict(sorted(_o0.replacements_by_rule.items(), key=lambda kv: kv[0])))
    return (_o2, _o4)

def _iter_anonymized_lines(lines: Iterable[str], rules_list: list[Rule], acc: _AnonymizationAccumulator, ctx: ActionContext) -> Iterator[str]:
    for _o2 in lines:
        _o4 = _o2
        for _o6 in rules_list:
            if RuleOutputBehavior.text_replacement not in _o6.outputs:
                continue
            if not _o6.triggered_by(_o4):
                continue
            _o1 = rule_key(_o6)
            acc.triggered.add(_o1)
            _o0 = _o6.action
            if _o0 is None:
                raise RuntimeError(f'Rule action missing for {_o1!r}')
            _o5 = _o0.as_replacement(context=ctx, rule_key=_o1)
            _o4, _o3 = _o6.regex.subn(_o5, _o4)
            if _o3:
                acc.replacements_by_rule[_o1] = acc.replacements_by_rule.get(_o1, 0) + _o3
                acc.total_replacements += _o3
        yield _o4

def anonymize_file(input_path: Path, output_path: Path, rules: Iterable[Rule], *, progress: ProgressReporter | None=None, rel_path: str | None=None, progress_min_bytes: int=5 * 1024 * 1024, progress_min_interval_s: float=0.2, cancel_requested: Callable[[], bool] | None=None, action_context: ActionContext | None=None) -> AnonymizeFileStats:
    """
    Anonymize a log file line-by-line using the provided rules.

    Rules are applied as:
    - Check if rule.trigger is present in the line (fast substring check).
    - If triggered, apply regex replacement (`re.sub`) for that rule.

    Constraints:
    - Streaming (does not load full file in memory)
    - UTF-8 safe with fallback to Latin-1
    - Creates parent directories for output_path
    """
    _o7 = input_path.resolve()
    _ob = output_path.resolve()
    _ob.parent.mkdir(parents=True, exist_ok=True)
    _oc = order_rules_for_evaluation(rules)
    _o3 = action_context or ActionContext()
    _o0 = _AnonymizationAccumulator(triggered=set(), replacements_by_rule={}, total_replacements=0)
    _od: int | None = None
    if progress is not None:
        try:
            _od = int(_o7.stat().st_size)
        except OSError:
            _od = None
        progress.emit(now_event(kind=ProgressKind.FILE_START, stage=ProgressStage.PROCESSING, path=rel_path or _o7.name, bytes_done=0, bytes_total=_od, message='anonymize_start'))
    logger.info('file_start', extra={'file_name': _o7.name, 'input': str(_o7), 'output': str(_ob)})
    _of, _o10 = tempfile.mkstemp(prefix=f'.{_ob.name}.', suffix='.tmp', dir=str(_ob.parent))
    os.close(_of)
    _o11 = Path(_o10)
    try:
        with _open_text_best_effort(_o7) as _o5, _o11.open('w', encoding='utf-8', errors='replace', newline='') as _o6:
            _o8 = 0.0
            for _o9 in _iter_anonymized_lines(_o5, _oc, _o0, _o3):
                if cancel_requested is not None and cancel_requested():
                    raise AnonymizationCancelled(f'cancelled while processing {_o7}')
                _o6.write(_o9)
                if progress is not None and _od is not None and (_od >= progress_min_bytes):
                    _oa = time.monotonic()
                    if _oa - _o8 >= progress_min_interval_s:
                        _o8 = _oa
                        _o2: int | None = None
                        try:
                            _o1 = getattr(_o5, 'buffer', None)
                            if _o1 is not None and hasattr(_o1, 'tell'):
                                _o2 = int(_o1.tell())
                        except Exception:
                            _o2 = None
                        if _o2 is not None:
                            progress.emit(now_event(kind=ProgressKind.FILE_PROGRESS, stage=ProgressStage.PROCESSING, path=rel_path or _o7.name, bytes_done=_o2, bytes_total=_od))
        if cancel_requested is not None and cancel_requested():
            raise AnonymizationCancelled(f'cancelled before commit for {_o7}')
        os.replace(_o11, _ob)
    except AnonymizationCancelled:
        logger.info('file_cancelled', extra={'input': str(_o7), 'output': str(_ob)})
        if progress is not None:
            progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=rel_path or _o7.name, bytes_done=_od, bytes_total=_od, ok=False, message='anonymize_cancelled'))
        raise
    except OSError as _o4:
        logger.exception('file_failed', extra={'input': str(_o7), 'output': str(_ob), 'error': str(_o4)})
        if progress is not None:
            progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=rel_path or _o7.name, bytes_done=_od, bytes_total=_od, ok=False, message='anonymize_failed'))
        raise
    finally:
        try:
            if _o11.exists():
                _o11.unlink()
        except OSError:
            pass
    _oe = AnonymizeFileStats(input_path=_o7, output_path=_ob, total_replacements=_o0.total_replacements, triggered_rules=tuple(sorted(_o0.triggered)), replacements_by_rule=dict(sorted(_o0.replacements_by_rule.items(), key=lambda kv: kv[0])))
    logger.info('file_done', extra={'file_name': _o7.name, 'input': str(_o7), 'output': str(_ob), 'replacements': _oe.total_replacements, 'triggered_rules': len(_oe.triggered_rules)})
    logger.debug('file_rule_stats', extra={'input': str(_o7), 'by_rule': _oe.replacements_by_rule})
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=rel_path or _o7.name, bytes_done=_od, bytes_total=_od, ok=True, message='anonymize_done'))
    return _oe

def _open_text_best_effort(path: Path) -> TextIO:
    """
    Open file for reading with decoding fallback.

    Returns an open file handle; caller must close it.
    """
    if not is_text_file(path):
        raise ValueError(f'Binary/non-text file: {path}')
    try:
        _o1 = path.open('r', encoding='utf-8', errors='strict', newline='')
        _o0 = _o1.read(4096)
        _o1.seek(0)
        return _o1
    except UnicodeDecodeError:
        return path.open('r', encoding='latin-1', errors='replace', newline='')

def _looks_binary(path: Path, *, sniff_bytes: int=8192) -> bool:
    return not is_text_file(path, sniff_bytes=sniff_bytes)
