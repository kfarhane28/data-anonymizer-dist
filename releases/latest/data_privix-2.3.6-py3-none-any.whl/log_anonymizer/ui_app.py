from __future__ import annotations
import html
import json
import hashlib
import logging
import os
import base64
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Literal
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
from log_anonymizer import __version__
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns
from log_anonymizer.input_limits import DEFAULT_FREE_LIMITS, InputLimitError, resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer.exclude_filter import load_patterns as _load_exclude_patterns
from log_anonymizer.application.preview_anonymization import PreviewAnonymizationRequest, PreviewLineDetail, preview_anonymization
from log_anonymizer.profiling.profiler import ProfilingConfig, SensitiveDataProfiler
from log_anonymizer.profiling.runner import run_sensitive_data_profiling
from log_anonymizer.batch import process_batch_with_result
from log_anonymizer.processor import CancellationToken, ProcessorConfig, process_with_result
from log_anonymizer.progress import ProgressEvent, ProgressKind, ProgressStage, QueueProgressReporter
from log_anonymizer.rules_loader import load_rules
from log_anonymizer.rules_engine import RuleOutputBehavior, iter_rule_match_spans
from log_anonymizer.rules_validation import validate_rules_json_bytes
from log_anonymizer.rule_actions import ReplacementAction
from log_anonymizer.licensing.features import FeatureFlag
from log_anonymizer.licensing.models import Edition
from log_anonymizer.licensing.service import LicensingService
from log_anonymizer.utils.io import is_text_file
InputMode = Literal['Upload file', 'Use Path']
logger = logging.getLogger(__name__)

def _tool_version_label() -> str:
    _o0 = (__version__ or '').strip()
    if not _o0:
        return ''
    return _o0 if _o0.startswith('v') else f'v{_o0}'

@dataclass(frozen=True)
class PreparedRun:
    input_mode: InputMode
    input_paths: list[Path]
    rules_path: Path
    exclude_path: Path | None
    output_dir: Path
    verbose: bool
    dry_run: bool
    anonymize_filenames: bool
    profile_sensitive_data: bool
    profiling_detectors: tuple[str, ...]
    parallel_enabled: bool
    max_workers: int
    features: frozenset[FeatureFlag]
    edition: Edition
    keep_partial_on_cancel: bool
    batch_parallel_enabled: bool
    batch_max_workers: int

class _QueueHandler(logging.Handler):

    def __init__(self, q: Queue[str], level: int) -> None:
        super().__init__(level=level)
        self._q = q

    def emit(self, record: logging.LogRecord) -> None:
        try:
            _o0 = self.format(record)
            self._q.put_nowait(_o0)
        except Exception:
            pass

def _render_header() -> None:
    _o2 = Path(__file__).resolve().parent / 'assets' / 'logo_svg_gemini.svg'
    _o3 = _o2.read_text(encoding='utf-8')
    _o0 = base64.b64encode(_o3.encode('utf-8')).decode('ascii')
    _o1 = f'\n    <div style="display:flex; align-items:center; gap:12px; margin: 4px 0 8px 0;">\n      <img src="data:image/svg+xml;base64,{_o0}" width="44" height="44" />\n      <div>\n        <div style="font-size: 34px; font-weight: 700; line-height: 1.0;">Data Privix</div>\n        <div style="font-size: 12px; font-weight: 650; opacity: 0.72; letter-spacing: 0.16em; text-transform: uppercase;">Console</div>\n      </div>\n    </div>\n    '
    st.markdown(_o1, unsafe_allow_html=True)
    st.markdown('\n        <style>\n          /* Avoid button label wrapping (e.g., "Clear log" splitting on 2 lines). */\n          div.stButton > button {\n            white-space: nowrap;\n            display: inline-flex;\n            align-items: center;\n            justify-content: center;\n            min-height: 52px;\n            padding: 0.75rem 1.35rem;\n            border-radius: 14px;\n            font-weight: 650;\n            letter-spacing: 0.1px;\n            transition: transform 120ms ease, box-shadow 120ms ease;\n          }\n          /* The Console UI runtime can render button labels inside a <p> with default margins,\n             which can push text outside the button\'s visual frame. */\n          div.stButton > button p { margin: 0; line-height: 1.1; }\n          div.stButton > button [data-testid="stMarkdownContainer"] {\n            display: flex;\n            align-items: center;\n            justify-content: center;\n          }\n          div.stButton > button:hover:enabled { box-shadow: 0 10px 24px rgba(0, 0, 0, 0.20); transform: translateY(-1px); }\n          div.stButton > button:active:enabled { transform: translateY(0px); box-shadow: 0 6px 14px rgba(0, 0, 0, 0.16); }\n        </style>\n        ', unsafe_allow_html=True)

def main() -> None:
    st.set_page_config(page_title='Data Privix', layout='wide')
    _init_state()
    _pump_logs_once()
    _render_header()
    _o16 = _render_sidebar()
    _o4, _o14 = st.columns([5.5, 1.0], gap='large')
    _o19 = _o16.input_paths[0] if len(_o16.input_paths) == 1 else None
    _of = bool(_o19 is not None and _o19.suffix.lower() == '.pdf')
    with _o4:
        if _of:
            _o1e = st.columns([3.2, 0.3, 2.2, 6.3], gap='large')
            _o12 = _o1e[0].button('Run PDF redaction', type='primary', use_container_width=True, disabled=bool(st.session_state.get('pdf_run_in_progress', False)) or st.session_state.get('pdf_is_supported') is False or _o16.edition != Edition.pro)
            _o5 = _o1e[2].button('Clear', use_container_width=True, disabled=bool(st.session_state.get('pdf_run_in_progress', False)))
            if _o12:
                _run_pdf_redaction(_o16)
            if _o5:
                _clear_pdf_state()
                st.rerun()
            if st.session_state.get('pdf_run_status'):
                st.info(st.session_state['pdf_run_status'])
            if st.session_state.get('pdf_run_error'):
                st.error(st.session_state['pdf_run_error'])
            if _o16.edition != Edition.pro:
                st.error('PDF redaction requires a Pro license.')
        else:
            _o1e = st.columns([2.2, 2.2, 2.6, 6.0], gap='large')
            _o17 = _o1e[0].button('Run', type='primary', use_container_width=True)
            _o3 = _o1e[1].button('Cancel', use_container_width=True, disabled=not st.session_state.get('run_in_progress', False))
            _o5 = _o1e[2].button('Clear log', use_container_width=True, disabled=st.session_state.get('run_in_progress', False))
            if _o17:
                _start_run(_o16)
            if _o3:
                _request_cancel()
            if _o5:
                st.session_state['log_lines'] = []
                st.session_state['run_error'] = ''
                st.session_state['run_status'] = ''
                st.session_state['result_zip_bytes'] = None
                st.session_state['result_zip_name'] = None
                st.session_state['batch_items'] = None
                st.session_state['profiling_report_bytes'] = None
                st.session_state['profiling_report_name'] = None
                st.session_state['suggested_rules_bytes'] = None
                st.session_state['suggested_rules_name'] = None
                st.rerun()
            if st.session_state.get('run_status'):
                st.info(st.session_state['run_status'])
            if st.session_state.get('run_error'):
                st.error(st.session_state['run_error'])
            if st.session_state.get('run_in_progress'):
                _render_progress_panel()
        _o7 = st.session_state.get('license_features', frozenset())
        if _of:
            _o10, _o15 = st.tabs(['PDF', 'Rules'])
            with _o10:
                _render_pdf_panel(_o16)
            with _o15:
                _render_rules_editor()
        else:
            _o1c = ['Logs', 'Rules', 'Exclude']
            _o18 = FeatureFlag.preview_mode in _o7
            if _o18:
                _o1c.append('Anonymization Preview')
            _o1d = st.tabs(_o1c)
            _ob, _o15, _o6 = (_o1d[0], _o1d[1], _o1d[2])
            _o11 = _o1d[3] if _o18 else None
            with _ob:
                _oa = st.container(border=True, height=760)
                with _oa:
                    st.code('\n'.join(st.session_state['log_lines'][-1200:]), language='text')
                if st.session_state.get('profiling_report_bytes') is not None or st.session_state.get('suggested_rules_bytes') is not None:
                    st.markdown('---')
                    st.subheader('Profiling outputs')
                    if st.session_state.get('profiling_report_bytes') is not None:
                        _o1, _o2 = st.columns([10, 1])
                        with _o1:
                            st.markdown('**Profiling report**')
                        with _o2:
                            st.download_button('⬇', data=st.session_state['profiling_report_bytes'], file_name=st.session_state.get('profiling_report_name', 'profiling_report.json'), mime='application/json', help='Download profiling report', use_container_width=True)
                        try:
                            _o13 = st.session_state['profiling_report_bytes'].decode('utf-8', errors='replace')
                        except Exception:
                            _o13 = ''
                        with st.expander('View report', expanded=True):
                            st.code(_o13 or '(unreadable report)', language='json')
                    if st.session_state.get('suggested_rules_bytes') is not None:
                        _o1, _o2 = st.columns([10, 1])
                        with _o1:
                            st.markdown('**Suggested rules**')
                        with _o2:
                            st.download_button('⬇', data=st.session_state['suggested_rules_bytes'], file_name=st.session_state.get('suggested_rules_name', 'suggested_rules.json'), mime='application/json', help='Download suggested rules', use_container_width=True)
                        try:
                            _o1b = st.session_state['suggested_rules_bytes'].decode('utf-8', errors='replace')
                        except Exception:
                            _o1b = ''
                        with st.expander('View suggested rules', expanded=True):
                            st.code(_o1b or '(unreadable suggested rules)', language='json')
                if st.session_state.get('run_in_progress'):
                    st.caption('Updating logs…')
                    time.sleep(0.25)
                    st.rerun()
            with _o15:
                _render_rules_editor()
            with _o6:
                _render_exclude_editor()
            if _o11 is not None:
                with _o11:
                    _render_preview_tab(_o16)
    with _o14:
        st.subheader('Output')
        st.write(f'Output directory: `{_o16.output_dir}`')
        if _of:
            st.write('Output: redacted PDF + summary (direct download)')
            if st.session_state.get('pdf_result_bytes') is not None:
                st.download_button('Download redacted PDF', data=st.session_state['pdf_result_bytes'], file_name=st.session_state.get('pdf_result_name', 'redacted.pdf'), mime='application/pdf', width='stretch')
            if st.session_state.get('pdf_summary') is not None:
                st.download_button('Download summary JSON', data=json.dumps(st.session_state['pdf_summary'], ensure_ascii=False, indent=2) + '\n', file_name='pdf_redaction_summary.json', mime='application/json', width='stretch')
            if st.session_state.get('pdf_result_bytes') is not None:
                st.success('Done.')
        else:
            if _o19 is not None:
                from log_anonymizer.processor import default_output_archive_path
                st.write(f'Output archive: `{default_output_archive_path(_o16.output_dir, _o19, anonymize_filenames=bool(_o16.anonymize_filenames))}`')
            elif len(_o16.input_paths) > 1:
                st.write('Batch output: one subfolder per input (plus `batch_summary.json`).')
            else:
                st.write('Output archive: (missing input)')
            _o8 = st.session_state.get('result_zip_bytes') is not None or st.session_state.get('batch_items') is not None or st.session_state.get('profiling_report_bytes') is not None or (st.session_state.get('suggested_rules_bytes') is not None)
            if _o8:
                st.success('Done.')
            if st.session_state.get('result_zip_bytes') is not None:
                st.download_button('Download archive', data=st.session_state['result_zip_bytes'], file_name=st.session_state.get('result_zip_name', 'anonymized.tar.gz'), mime='application/gzip', width='stretch')
            _o0 = st.session_state.get('batch_items')
            if isinstance(_o0, list) and _o0:
                st.markdown('### Batch outputs')
                for _o9 in _o0:
                    _oc = str(_o9.get('input_name') or _o9.get('input_path') or 'input')
                    _o1a = str(_o9.get('status') or '')
                    _od = _o9.get('output_archive')
                    if _o1a.lower() == 'success' and isinstance(_od, str) and _od:
                        _oe = Path(_od)
                        if _oe.exists():
                            st.download_button(f'Download: {_oc}', data=_read_bytes_cached(str(_oe)), file_name=_oe.name, mime='application/gzip', width='stretch')
                    else:
                        st.caption(f'{_oc}: {_o1a}')
        st.subheader('Run')
        st.write(f'Verbose: `{_o16.verbose}`')
        st.write(f'Dry run: `{_o16.dry_run}`')
        st.write(f'Sensitive-data profiling: `{bool(_o16.profile_sensitive_data)}`')
        st.write(f'Exclude provided: `{bool(_o16.exclude_path)}`')
        st.write(f"Rules file: `{(_o16.rules_path.name if _o16.rules_path else 'default (built-in only)')}`")

def _init_state() -> None:
    st.session_state.setdefault('log_queue', Queue())
    st.session_state.setdefault('outcome_queue', Queue())
    st.session_state.setdefault('progress_queue', Queue())
    st.session_state.setdefault('log_lines', [])
    st.session_state.setdefault('run_in_progress', False)
    st.session_state.setdefault('run_status', '')
    st.session_state.setdefault('run_error', '')
    st.session_state.setdefault('result_zip_bytes', None)
    st.session_state.setdefault('result_zip_name', None)
    st.session_state.setdefault('profiling_report_bytes', None)
    st.session_state.setdefault('profiling_report_name', None)
    st.session_state.setdefault('suggested_rules_bytes', None)
    st.session_state.setdefault('suggested_rules_name', None)
    st.session_state.setdefault('batch_items', None)
    st.session_state.setdefault('tmp_dir', None)
    st.session_state.setdefault('log_handler', None)
    st.session_state.setdefault('log_prev_handlers', None)
    st.session_state.setdefault('ui_warnings', [])
    st.session_state.setdefault('ui_errors', [])
    st.session_state.setdefault('rules_editor_df_v1', None)
    st.session_state.setdefault('rules_editor_df_v2', None)
    st.session_state.setdefault('rules_editor_mode', 'table_v1')
    st.session_state.setdefault('rules_editor_mode_radio', None)
    st.session_state.setdefault('rules_editor_text', None)
    st.session_state.setdefault('rules_editor_json_widget', None)
    st.session_state.setdefault('rules_editor_table_counter', 0)
    st.session_state.setdefault('exclude_editor_df', None)
    st.session_state.setdefault('exclude_editor_counter', 0)
    st.session_state.setdefault('rules_upload_sig', None)
    st.session_state.setdefault('exclude_upload_sig', None)
    st.session_state.setdefault('input_upload_cache', {})
    st.session_state.setdefault('download_cache', {})
    st.session_state.setdefault('preview_input', '')
    st.session_state.setdefault('preview_output_value', '')
    st.session_state.setdefault('preview_status', '')
    st.session_state.setdefault('preview_error', '')
    st.session_state.setdefault('preview_profile_report', '')
    st.session_state.setdefault('preview_suggested_rules', '')
    st.session_state.setdefault('preview_line_details', ())
    st.session_state.setdefault('preview_replacements_by_rule', {})
    st.session_state.setdefault('progress_stage', None)
    st.session_state.setdefault('progress_stage_current', None)
    st.session_state.setdefault('progress_stage_total', None)
    st.session_state.setdefault('progress_stage_message', '')
    st.session_state.setdefault('progress_files_done', 0)
    st.session_state.setdefault('progress_files_total', None)
    st.session_state.setdefault('progress_file_path', None)
    st.session_state.setdefault('progress_file_done', None)
    st.session_state.setdefault('progress_file_total', None)
    st.session_state.setdefault('batch_done', 0)
    st.session_state.setdefault('batch_total', None)
    st.session_state.setdefault('batch_current_input', '')
    st.session_state.setdefault('cancel_token', None)
    st.session_state.setdefault('license_features', frozenset())
    st.session_state.setdefault('license_status', '')
    st.session_state.setdefault('license_upload_counter', 0)
    st.session_state.setdefault('license_input_text', '')
    st.session_state.setdefault('license_input_counter', 0)
    st.session_state.setdefault('pdf_detect_sig', None)
    st.session_state.setdefault('pdf_is_supported', None)
    st.session_state.setdefault('pdf_detect_message', '')
    st.session_state.setdefault('pdf_pages', None)
    st.session_state.setdefault('pdf_preview_enabled', True)
    st.session_state.setdefault('pdf_preview_pages', 2)
    st.session_state.setdefault('pdf_preview_texts', {})
    st.session_state.setdefault('pdf_preview_sig', None)
    st.session_state.setdefault('pdf_result_bytes', None)
    st.session_state.setdefault('pdf_result_name', None)
    st.session_state.setdefault('pdf_summary', None)
    st.session_state.setdefault('pdf_run_in_progress', False)
    st.session_state.setdefault('pdf_run_status', '')
    st.session_state.setdefault('pdf_run_error', '')
    st.session_state.pop('preview_output', None)

def _render_sidebar() -> PreparedRun:
    service = LicensingService.default()
    _o27 = service.validate()
    _oe = service.enabled_features()
    _oc = service.edition()
    st.session_state['license_features'] = _oe
    st.sidebar.header('Configuration')
    st.session_state['ui_warnings'] = []
    st.session_state['ui_errors'] = []
    st.sidebar.markdown('### Edition')
    if _o27.valid and _o27.license_info is not None:
        st.sidebar.success('Pro edition active')
        st.sidebar.caption(f'Customer: {_o27.license_info.customer_name}')
        st.sidebar.caption(f'Expires: {_o27.license_info.expiry_date.isoformat()}')
        _od = sorted((f.value for f in _oe))
        st.sidebar.caption('Features: ' + (', '.join(_od) if _od else '<none>'))
    else:
        if _o27.reason.value == 'expired':
            st.sidebar.warning('License expired (Free mode)')
        elif _o27.reason.value in ('invalid_signature', 'malformed', 'unsupported_edition', 'max_version_exceeded'):
            st.sidebar.warning('Invalid license (Free mode)')
        elif _o27.reason.value == 'crypto_unavailable':
            st.sidebar.warning('Cannot validate Pro license (install "data-privix[pro]" — legacy: "data-anonymizer[pro]")')
        else:
            st.sidebar.info('Free edition')
        st.sidebar.caption(f'License status: {_o27.reason.value}')
    _render_workload_limits_notice(_oc)
    with st.sidebar.expander('License', expanded=False):
        st.markdown('Install a Pro license key to unlock premium features.')
        st.caption('You can also manage licenses via CLI: `data-privix license ...` (legacy: `data-anonymizer ...`).')
        _o20 = str(st.session_state.get('license_status') or '').strip()
        if _o20:
            st.success(_o20)
        _o21 = int(st.session_state.get('license_upload_counter') or 0)
        _o22 = st.file_uploader('Load from file', type=None, key=f'license_upload_{_o21}')
        if _o22 is not None:
            try:
                st.session_state['license_input_text'] = bytes(_o22.getbuffer()).decode('utf-8', errors='replace').strip()
            except Exception:
                st.session_state['license_input_text'] = ''
            st.session_state['license_input_counter'] = int(st.session_state.get('license_input_counter') or 0) + 1
        _o10 = int(st.session_state.get('license_input_counter') or 0)
        _o11 = f'license_input_widget_{_o10}'
        _o15 = st.text_area('License key', key=_o11, value=str(st.session_state.get('license_input_text') or ''), placeholder='LA1.<payload_b64url>.<signature_b64url>', height=120)
        st.session_state['license_input_text'] = _o15
        _o4, _o5, _o6 = st.columns([1, 1, 1])
        _o26 = not bool((_o15 or '').strip())
        if _o4.button('Validate', use_container_width=True, disabled=_o26):
            from log_anonymizer.licensing.validator import validate_license_key
            _o1e = validate_license_key(_o15)
            if _o1e.valid:
                st.session_state['license_status'] = 'License is valid.'
            else:
                st.error(f'License is not valid: {_o1e.reason.value}')
                if _o1e.message:
                    st.caption(_o1e.message)
        if _o5.button('Validate & Save', use_container_width=True, disabled=_o26):
            from log_anonymizer.licensing.validator import validate_license_key
            _o1e = validate_license_key(_o15)
            if not _o1e.valid:
                st.error(f'Cannot save: {_o1e.reason.value}')
                if _o1e.message:
                    st.caption(_o1e.message)
            else:
                service.storage.save(_o15)
                st.session_state['license_status'] = 'Saved.'
                st.rerun()

        def _on_clear_license() -> None:
            service.storage.clear()
            st.session_state['license_status'] = 'Cleared.'
            st.session_state['license_upload_counter'] = int(st.session_state.get('license_upload_counter') or 0) + 1
            st.session_state['license_input_text'] = ''
            st.session_state['license_input_counter'] = int(st.session_state.get('license_input_counter') or 0) + 1
        _o6.button('Clear', use_container_width=True, on_click=_on_clear_license)
        st.markdown('---')
        st.markdown('**Free vs Pro (summary)**')
        st.markdown('- Free: basic anonymization, legacy replace-only rules, sequential processing.\n- Pro: filename anonymization, advanced rule actions, parallel processing, UI preview, profiling, keep partial output on cancel.')
    _o12: InputMode = st.sidebar.radio('Input source', options=['Upload file', 'Use Path'], index=0)
    _o24 = None
    _o13 = ''
    if _o12 == 'Upload file':
        _o24 = st.sidebar.file_uploader('Upload file(s)', type=None, accept_multiple_files=True, help='Supported top-level inputs:\n- Regular files (typically text)\n- PDF (.pdf) (Pro license required)\n- Zip archives (.zip)\n- Tar archives (.tar.gz / .tgz)\n\nNotes:\n- Binary files are never anonymized; they are copied through unchanged (unless excluded).\n- In Free mode, PDFs are omitted. Processing PDFs requires a Pro license.\n- Batch mode (multiple inputs) requires Pro.')
    else:
        _o13 = st.sidebar.text_area('Input path(s)', value='tmp_test/in', help='Provide one path per line. Each path may be a file, directory, .zip, or .tar.gz/.tgz.', height=90)
    _o25 = st.sidebar.file_uploader('Rules JSON', type=['json'], key='rules_upload')
    _o23 = st.sidebar.file_uploader('Exclude file (.exclude)', type=None, key='exclude_upload')
    _o17 = st.sidebar.text_input('Output directory', value='tmp_test/ui_out')
    _o28 = st.sidebar.checkbox('Verbose mode (DEBUG)', value=False)
    _oa = st.sidebar.checkbox('Dry run', value=False)
    _of = FeatureFlag.anonymize_filenames in _oe
    _o0 = st.sidebar.checkbox('Anonymize file and folder names (Pro)', value=False, disabled=not _of, help='Transforms output file/folder names using the rules engine when possible. Also sanitizes the generated output archive name.')
    if not _of:
        _o0 = False
        st.sidebar.caption('Filename anonymization requires Pro.')
    _o7 = FeatureFlag.partial_cancel_preservation in _oe
    _o14 = st.sidebar.checkbox('Keep partial output on cancel (Pro)', value=bool(_o7), disabled=not _o7, help='When enabled, cancelling a run keeps partial output when possible.')
    if not _o7:
        _o14 = False
        st.sidebar.caption('Partial-output preservation requires Pro.')
    st.sidebar.markdown('### Performance')
    _o18 = FeatureFlag.parallel_processing in _oe
    _o19 = st.sidebar.checkbox('Enable parallel file processing', value=False, help='Processes files concurrently to speed up large bundles. Output is functionally identical.', disabled=not _o18)
    if not _o18:
        _o19 = False
        st.sidebar.caption('Parallel processing requires Pro.')
    _o8 = int(os.getenv('DATA_PRIVIX_WORKERS') or os.getenv('DATA_ANONYMIZER_WORKERS') or os.getenv('LOG_ANONYMIZER_WORKERS') or '5')
    _o16 = int(st.sidebar.number_input('Max parallel workers', min_value=1, max_value=64, value=max(1, min(64, _o8)), step=1, disabled=not _o19, help='Only used when parallel processing is enabled (default: 5).'))
    st.sidebar.markdown('### Batch')
    _o1 = _oc == Edition.pro
    _o3 = st.sidebar.checkbox('Enable parallel input processing (batch) (Pro)', value=False, disabled=not _o1, help='Processes multiple top-level inputs concurrently. Separate from per-file parallelism.')
    if not _o1:
        _o3 = False
        st.sidebar.caption('Batch processing requires Pro.')
    _o2 = int(st.sidebar.number_input('Max parallel inputs', min_value=1, max_value=16, value=2, step=1, disabled=not _o3, help='Only used when parallel input processing is enabled (default: 2).'))
    _o1c = FeatureFlag.profiling in _oe
    _o1b = st.sidebar.checkbox('Enable sensitive-data profiling (optional)', value=False, help='Heuristic scan for potential sensitive data + suggested rules. Does not change anonymization unless you apply the suggested rules.', disabled=not _o1c)
    if not _o1c:
        _o1b = False
        st.sidebar.caption('Profiling requires Pro.')
    st.sidebar.markdown('### Integrations')
    _o1f = FeatureFlag.spark_connect in _oe
    st.sidebar.checkbox('Spark engine connect (coming soon)', value=False, disabled=True, help='Not available in this build.')
    if not _o1f:
        st.sidebar.caption('Spark connect requires Pro (and is not yet available).')
    _o9 = ('email', 'ipv4', 'token', 'card')
    _o1d = _o9
    if _o1b:
        _o1d = tuple(st.sidebar.multiselect('Profiling detectors', options=list(_o9), default=list(_o9))) or _o9
    _o1a = _prepare_files(input_mode=_o12, uploaded_inputs=_o24, input_paths_text=_o13, uploaded_rules=_o25, uploaded_exclude=_o23, output_dir_text=_o17, verbose=_o28, dry_run=_oa, anonymize_filenames=_o0, profile_sensitive_data=_o1b, profiling_detectors=_o1d, parallel_enabled=_o19, max_workers=_o16, features=_oe, edition=_oc, keep_partial_on_cancel=_o14, batch_parallel_enabled=_o3, batch_max_workers=_o2)
    if st.session_state.get('ui_errors'):
        st.sidebar.markdown('---')
        for _ob in st.session_state['ui_errors']:
            st.sidebar.error(_ob)
    for _o29 in st.session_state.get('ui_warnings', []):
        st.sidebar.warning(_o29)
    return _o1a

def _prepare_files(*, input_mode: InputMode, uploaded_inputs, input_paths_text: str, uploaded_rules, uploaded_exclude, output_dir_text: str, verbose: bool, dry_run: bool, anonymize_filenames: bool, profile_sensitive_data: bool, profiling_detectors: tuple[str, ...], parallel_enabled: bool, max_workers: int, features: frozenset[FeatureFlag], edition: Edition, keep_partial_on_cancel: bool, batch_parallel_enabled: bool, batch_max_workers: int) -> PreparedRun:
    _o15 = _ensure_tmp_dir()
    _o6: list[Path] = []
    if input_mode == 'Upload file':
        if uploaded_inputs is None:
            _o6 = []
        else:
            try:
                _o7 = list(uploaded_inputs)
            except Exception:
                _o7 = []
            _o6 = _save_uploads_cached(_o15, _o7)
    else:
        _o11 = [_o8.strip() for _o8 in (input_paths_text or '').splitlines()]
        _o11 = [_o8 for _o8 in _o11 if _o8 and _o8 != '.']
        _o6 = [Path(_o8).expanduser() for _o8 in _o11]
    if edition != Edition.pro and len(_o6) > 1:
        st.session_state['ui_errors'].append('Batch processing (multiple inputs) requires a Pro license.')
    for _od in _o6:
        _validate_input_path(_od)
    if edition != Edition.pro and len(_o6) == 1 and (_o6[0].suffix.lower() == '.pdf'):
        st.session_state['ui_errors'].append('PDF redaction requires a Pro license.')
    if edition != Edition.pro:
        for _od in _o6:
            try:
                _oa = _od.name.lower()
            except Exception:
                continue
            try:
                if _oa.endswith('.zip'):
                    import zipfile
                    with zipfile.ZipFile(_od, 'r') as _o18:
                        if any((str(n).lower().endswith('.pdf') for n in _o18.namelist())):
                            st.session_state['ui_warnings'].append(f'Archive `{_od.name}` contains PDF files. PDFs require a Pro license and will be omitted.')
                elif _oa.endswith('.tar.gz') or _oa.endswith('.tgz'):
                    import tarfile
                    with tarfile.open(_od, 'r:gz') as _o14:
                        _ob = (m.name for m in _o14.getmembers() if getattr(m, 'name', None))
                        if any((str(n).lower().endswith('.pdf') for n in _ob)):
                            st.session_state['ui_warnings'].append(f'Archive `{_od.name}` contains PDF files. PDFs require a Pro license and will be omitted.')
            except Exception:
                continue
    for _od in _o6:
        _maybe_add_free_limit_validation(_od, edition=edition)
    if uploaded_rules is None:
        _ensure_rules_editor_initialized()
        _o12 = _write_rules_from_editor(_o15)
    else:
        _o10 = bytes(uploaded_rules.getbuffer())
        _o3 = _validate_rules_json_bytes(_o10)
        if _o3:
            st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o3}')
            _ensure_rules_editor_initialized()
            _o12 = _write_rules_from_editor(_o15)
        else:
            _maybe_load_rules_upload_into_editor(_o10, name=str(uploaded_rules.name))
            _o12 = _write_rules_from_editor(_o15)
    try:
        _o2 = _o12.read_bytes()
    except Exception:
        _o2 = b''
    _o1 = _validate_rules_json_bytes(_o2)
    if _o1:
        st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o1}')
    elif FeatureFlag.advanced_rules not in features:
        try:
            _oe = load_rules(_o12, strict=True)
        except Exception as _o4:
            st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o4}')
        else:
            for _of in _oe:
                if not isinstance(getattr(_of, 'action', None), ReplacementAction):
                    st.session_state['ui_errors'].append('Advanced rule actions require a Pro license.')
                    break
    _o5 = None
    if uploaded_exclude is not None:
        _o10 = bytes(uploaded_exclude.getbuffer())
        _o3 = _validate_exclude_bytes(_o10, filename=str(uploaded_exclude.name))
        if _o3:
            st.session_state['ui_errors'].append(f'Exclude file invalid: {_o3}')
            _o5 = None
        else:
            _maybe_load_exclude_upload_into_editor(_o10, name=str(uploaded_exclude.name))
            _o5 = _write_exclude_from_editor(_o15)
    elif _exclude_editor_has_patterns():
        _o5 = _write_exclude_from_editor(_o15)
    st.sidebar.markdown('---')
    _o17 = _tool_version_label()
    try:
        _o9 = Path(__file__).resolve().parent / 'assets' / 'dataprivix-logo-horizontal_gemini.svg'
        _o13 = _o9.read_text(encoding='utf-8')
        _o0 = base64.b64encode(_o13.encode('utf-8')).decode('ascii')
        _o16 = f'<span style="font-size: 12px; opacity: 0.75; white-space: nowrap;">{html.escape(_o17)}</span>' if _o17 else ''
        st.sidebar.markdown(f'\n            <div style="display:grid; grid-template-columns: 1fr auto; align-items:center; column-gap:10px; margin: 6px 0 0 0;">\n              <img\n                src="data:image/svg+xml;base64,{_o0}"\n                style="width: 100%; height: 56px; object-fit: contain; display:block;"\n              />\n              {_o16}\n            </div>\n            ', unsafe_allow_html=True)
    except Exception:
        pass
    st.sidebar.caption('© 2026 MagicByte Consulting · Proprietary software')
    _oc = Path(output_dir_text).expanduser()
    return PreparedRun(input_mode=input_mode, input_paths=_o6, rules_path=_o12, exclude_path=_o5, output_dir=_oc, verbose=verbose, dry_run=dry_run, anonymize_filenames=bool(anonymize_filenames), profile_sensitive_data=profile_sensitive_data, profiling_detectors=profiling_detectors, parallel_enabled=parallel_enabled, max_workers=int(max_workers), features=features, edition=edition, keep_partial_on_cancel=keep_partial_on_cancel, batch_parallel_enabled=bool(batch_parallel_enabled), batch_max_workers=int(batch_max_workers))

def _render_workload_limits_notice(edition: Edition) -> None:
    if edition == Edition.pro:
        st.sidebar.caption('Pro edition: workload limits removed.')
        return
    st.sidebar.caption('Free edition: workload limits apply (upgrade to Pro for larger bundles).')
    with st.sidebar.expander('Free edition limits', expanded=True):
        st.markdown('- Single file: up to **' + str(int(DEFAULT_FREE_LIMITS.max_single_file_bytes / (1024 * 1024))) + ' MB**\n- Archives (`.zip`, `.tar.gz`): up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_compressed_bytes / (1024 * 1024))) + ' MB** (compressed)\n- Extracted content: up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_extracted_total_bytes / (1024 * 1024))) + ' MB** total\n- Extracted files: up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_extracted_file_count)) + '** files\n\nPro edition supports larger workloads (Free limits removed).')

def _maybe_add_free_limit_validation(input_path: Path | None, *, edition: Edition) -> None:
    if edition == Edition.pro:
        return
    if input_path is None:
        return
    try:
        _o3 = input_path.expanduser()
    except Exception:
        return
    if not _o3.exists() or not _o3.is_file():
        return
    _o1 = resolve_free_input_limits(edition=edition)
    if _o1 is None:
        return
    try:
        _o2 = _o3.name.lower()
        _o4 = _o3.stat().st_size
        if _o2.endswith(('.tar.gz', '.tgz')) or _o3.suffix.lower() == '.zip':
            from log_anonymizer.input_limits import validate_archive_compressed_size
            validate_archive_compressed_size(_o4, limits=_o1)
        else:
            from log_anonymizer.input_limits import validate_single_file_size
            validate_single_file_size(_o4, limits=_o1)
    except InputLimitError as _o0:
        st.session_state['ui_errors'].append(str(_o0))

def _ensure_tmp_dir() -> Path:
    _o0 = st.session_state.get('tmp_dir')
    if _o0 and Path(_o0).exists():
        return Path(_o0)
    _o1 = Path(tempfile.mkdtemp(prefix='data-privix-ui-')).resolve()
    st.session_state['tmp_dir'] = str(_o1)
    return _o1

def _save_upload_cached(tmp_dir: Path, uploaded, *, name_hint: str) -> Path:
    """
    Persist an uploaded file to disk in a stable, content-addressed path.

    The Console runtime re-executes the script frequently; without caching, we might overwrite the same
    on-disk tar.gz while a background worker is reading it (leading to intermittent EOF/ReadError).
    """
    tmp_dir.mkdir(parents=True, exist_ok=True)
    _o3 = bytes(uploaded.getbuffer())
    _o4 = Path(name_hint).name
    _o5 = _sig(_o4, _o3)
    _o0 = st.session_state.get('input_upload_cache')
    if isinstance(_o0, dict):
        _o2 = _o0.get(_o5)
        if isinstance(_o2, str) and _o2:
            _o1 = Path(_o2)
            if _o1.exists():
                return _o1
    _o6 = (tmp_dir / f'input-{_o5[:12]}-{_o4}').resolve()
    _atomic_write_bytes(_o6, _o3)
    if isinstance(_o0, dict):
        _o0[_o5] = str(_o6)
        st.session_state['input_upload_cache'] = _o0
    return _o6

def _save_uploads_cached(tmp_dir: Path, uploaded_list: list[Any]) -> list[Path]:
    _o1: list[Path] = []
    for _o2 in uploaded_list:
        try:
            _o0 = str(getattr(_o2, 'name', '') or 'input')
            _o1.append(_save_upload_cached(tmp_dir, _o2, name_hint=_o0))
        except Exception:
            continue
    return _o1

def _validate_input_path(p: Path) -> None:
    """
    UI-level validation for supported input types (upload + path modes).

    Supported top-level inputs:
    - regular file (typically text; binary will be passed through unchanged)
    - .zip
    - .tar.gz / .tgz
    - directory
    - .pdf (PDF redaction requires a Pro license)
    """
    try:
        _o1 = p.name
        _o0 = _o1.lower()
    except Exception:
        return
    if not p.exists():
        return
    if p.is_dir():
        return
    if _o0.endswith('.zip'):
        return
    if _o0.endswith('.tar.gz') or _o0.endswith('.tgz'):
        return
    if _o0.endswith('.pdf'):
        return
    if _o0.endswith('.gz'):
        st.session_state['ui_errors'].append(f'Unsupported archive format: `{_o1}`. Supported archives are `.zip` and `.tar.gz`/`.tgz`.')
        return
    if _o0.endswith('.tar'):
        st.session_state['ui_errors'].append(f'Unsupported archive format: `{_o1}`. Supported archives are `.zip` and `.tar.gz`/`.tgz`.')
        return
    try:
        if not is_text_file(p):
            st.session_state['ui_warnings'].append(f'Input `{_o1}` looks binary; it will be copied through unchanged (unless excluded).')
    except Exception:
        return

def _atomic_write_bytes(target: Path, raw: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    _o0 = target.with_suffix(target.suffix + '.tmp')
    _o0.write_bytes(raw)
    os.replace(_o0, target)

def _read_bytes_cached(path_str: str) -> bytes:
    """
    Read file bytes with a small in-memory cache to avoid repeated disk reads on Console reruns.
    """
    _o1 = Path(path_str)
    try:
        _o4 = _o1.stat()
    except OSError:
        return b''
    _o0 = st.session_state.get('download_cache')
    if isinstance(_o0, dict):
        _o2 = _o0.get(path_str)
        if isinstance(_o2, dict):
            if _o2.get('size') == int(_o4.st_size) and _o2.get('mtime_ns') == int(_o4.st_mtime_ns):
                _o3 = _o2.get('bytes')
                if isinstance(_o3, (bytes, bytearray)):
                    return bytes(_o3)
    _o3 = _o1.read_bytes()
    if isinstance(_o0, dict):
        _o0[path_str] = {'size': int(_o4.st_size), 'mtime_ns': int(_o4.st_mtime_ns), 'bytes': _o3}
        st.session_state['download_cache'] = _o0
    return _o3

def _start_run(run: PreparedRun) -> None:
    st.session_state['run_error'] = ''
    st.session_state['result_zip_bytes'] = None
    st.session_state['result_zip_name'] = None
    st.session_state['batch_items'] = None
    st.session_state['profiling_report_bytes'] = None
    st.session_state['profiling_report_name'] = None
    st.session_state['suggested_rules_bytes'] = None
    st.session_state['suggested_rules_name'] = None
    st.session_state['log_lines'] = []
    st.session_state['progress_stage'] = None
    st.session_state['progress_stage_current'] = None
    st.session_state['progress_stage_total'] = None
    st.session_state['progress_stage_message'] = ''
    st.session_state['progress_files_done'] = 0
    st.session_state['progress_files_total'] = None
    st.session_state['progress_file_path'] = None
    st.session_state['progress_file_done'] = None
    st.session_state['progress_file_total'] = None
    st.session_state['batch_done'] = 0
    st.session_state['batch_total'] = None
    st.session_state['batch_current_input'] = ''
    st.session_state['cancel_token'] = None
    _o1 = _validate_run(run)
    if _o1:
        st.session_state['run_error'] = _o1
        return
    st.session_state['run_in_progress'] = True
    st.session_state['run_status'] = 'Running…'
    _o0 = CancellationToken()
    st.session_state['cancel_token'] = _o0
    _o3: Queue[str] = Queue()
    _o4: Queue[dict[str, Any]] = Queue()
    _o6: Queue[ProgressEvent] = Queue()
    st.session_state['log_queue'] = _o3
    st.session_state['outcome_queue'] = _o4
    st.session_state['progress_queue'] = _o6
    while True:
        try:
            _o3.get_nowait()
        except Empty:
            break
    while True:
        try:
            _o4.get_nowait()
        except Empty:
            break
    while True:
        try:
            _o6.get_nowait()
        except Empty:
            break
    _o2, _o5 = _attach_streamlit_logger(_o3, verbose=run.verbose)
    st.session_state['log_handler'] = _o2
    st.session_state['log_prev_handlers'] = _o5
    _o7 = threading.Thread(target=_run_pipeline_thread, args=(run, _o0, _o3, _o4, _o6), daemon=True)
    _o7.start()

def _request_cancel() -> None:
    _o0 = st.session_state.get('cancel_token')
    if _o0 is None:
        return
    try:
        _o0.cancel()
    except Exception:
        return
    st.session_state['run_status'] = 'Cancellation requested…'

def _validate_run(run: PreparedRun) -> str | None:
    _o1 = st.session_state.get('ui_errors') or []
    if _o1:
        return str(_o1[0])
    if not run.input_paths:
        return 'Please provide an input (upload or path).'
    if run.edition != Edition.pro and len(run.input_paths) > 1:
        return 'Batch processing (multiple inputs) requires a Pro license.'
    for _o0 in run.input_paths:
        if str(_o0).strip() in ('', '.'):
            return 'Please provide an input (upload or path).'
        if not _o0.exists():
            return f'Input path does not exist: {_o0}'
    if not run.output_dir or str(run.output_dir) == '':
        return 'Please provide an output directory.'
    if run.output_dir.exists() and (not run.output_dir.is_dir()):
        return f'Output directory is not a directory: {run.output_dir}'
    if not run.rules_path.exists():
        return f'Rules file could not be created: {run.rules_path}'
    if run.exclude_path is not None and (not run.exclude_path.exists()):
        return f'Exclude file does not exist: {run.exclude_path}'
    return None

def _clear_pdf_state() -> None:
    st.session_state['pdf_detect_sig'] = None
    st.session_state['pdf_is_supported'] = None
    st.session_state['pdf_detect_message'] = ''
    st.session_state['pdf_pages'] = None
    st.session_state['pdf_preview_texts'] = {}
    st.session_state['pdf_preview_sig'] = None
    st.session_state['pdf_result_bytes'] = None
    st.session_state['pdf_result_name'] = None
    st.session_state['pdf_summary'] = None
    st.session_state['pdf_run_in_progress'] = False
    st.session_state['pdf_run_status'] = ''
    st.session_state['pdf_run_error'] = ''

def _render_pdf_panel(run: PreparedRun) -> None:
    st.subheader('PDF redaction')
    _o5 = run.input_paths[0] if run.input_paths else None
    if _o5 is None:
        st.info('Upload a PDF to enable redaction.')
        return
    if _o5.suffix.lower() != '.pdf':
        st.warning(f'Selected input is not a PDF: `{_o5.name}`')
        return
    if run.edition != Edition.pro:
        st.error('PDF redaction requires a Pro license.')
        st.caption('Install a Pro license key in the sidebar to unlock PDF processing.')
        return
    if not _pdf_support_available():
        st.error('PDF support is not installed in this environment.')
        st.code(".venv/bin/pip install -e '.[ui,pdf]'", language='bash')
        return
    _od, _o7, _o4 = _detect_pdf_support_cached(_o5)
    if _od is True:
        st.success(f'Supported (native text PDF). Pages: {_o7}')
    elif _od is False:
        st.warning('Unsupported (no extractable text). Scanned/image PDFs are not supported in this phase.')
    else:
        st.error(f'Could not open PDF: {_o4}')
        return
    if _o4:
        st.caption(_o4)
    _oc = st.session_state.get('pdf_summary')
    if isinstance(_oc, dict):
        _o0, _o1, _o2 = st.columns([1, 1, 2])
        _o0.metric('Pages affected', len(_oc.get('pages_affected') or []))
        _o1.metric('Redactions', int(_oc.get('redactions_applied') or 0))
        _oe = _oc.get('triggered_rules') or []
        _o2.metric('Triggered rules', len(_oe))
        if _oe:
            st.caption('Rules: ' + ', '.join((str(x) for x in _oe[:20])) + (' …' if len(_oe) > 20 else ''))
    st.markdown('---')
    st.markdown('**Preview (optional)**')
    st.session_state['pdf_preview_enabled'] = st.checkbox('Show preview of matched text (no PDF rendering)', value=bool(st.session_state.get('pdf_preview_enabled', True)), help='Shows extracted page text with simple markers for matches (best-effort).')
    st.session_state['pdf_preview_pages'] = int(st.number_input('Pages to preview', min_value=1, max_value=10, value=int(st.session_state.get('pdf_preview_pages') or 2), step=1))
    if _od is True and bool(st.session_state.get('pdf_preview_enabled')):
        try:
            _o9 = load_rules(run.rules_path, strict=True)
        except Exception as _o3:
            st.error(f'Rules JSON invalid: {_o3}')
            return
        try:
            _oa = run.rules_path.read_bytes()
        except Exception:
            _oa = b''
        _ob = hashlib.sha256(_oa[:65536]).hexdigest()
        _o8 = _pdf_preview_texts_cached(_o5, _o9, rules_sig=_ob, max_pages=int(st.session_state['pdf_preview_pages']))
        if not _o8:
            st.caption('No preview available (no extractable text or no matches on previewed pages).')
            return
        for _o6 in sorted(_o8.keys()):
            with st.expander(f'Page {_o6} preview', expanded=_o6 == 1):
                st.code(_o8[_o6], language='text')

def _run_pdf_redaction(run: PreparedRun) -> None:
    st.session_state['pdf_run_error'] = ''
    st.session_state['pdf_run_status'] = ''
    st.session_state['pdf_result_bytes'] = None
    st.session_state['pdf_result_name'] = None
    st.session_state['pdf_summary'] = None
    st.session_state['pdf_run_in_progress'] = True
    st.session_state['pdf_run_status'] = 'Running PDF redaction…'
    try:
        if run.edition != Edition.pro:
            raise ValueError('PDF redaction requires a Pro license.')
        _o5 = run.input_paths[0] if run.input_paths else None
        if _o5 is None or not _o5.exists():
            raise ValueError('Missing input PDF.')
        if _o5.suffix.lower() != '.pdf':
            raise ValueError('Input is not a PDF.')
        if not _pdf_support_available():
            raise RuntimeError("PDF support is not installed. Install with: pip install -e '.[ui,pdf]'")
        _o9, _o0, _o2 = _detect_pdf_support_cached(_o5)
        if _o9 is not True:
            raise ValueError('PDF is unsupported (no extractable text). No OCR in this phase.')
        _o8 = load_rules(run.rules_path, strict=True)
        from log_anonymizer.platform.pipelines.pdf_file import PdfFilePipeline
        _o3 = run.output_dir.expanduser().resolve()
        _o3.mkdir(parents=True, exist_ok=True)
        _o4 = _o3 / f'{_o5.stem}.redacted.pdf'
        _o6 = PdfFilePipeline()
        _o7 = _o6.process_file(source_path=_o5, dest_path=_o4, rules=_o8)
        st.session_state['pdf_result_bytes'] = _o4.read_bytes()
        st.session_state['pdf_result_name'] = _o4.name
        st.session_state['pdf_summary'] = {'pages_affected': list(_o7.pages_affected), 'redactions_applied': int(_o7.redactions_applied), 'triggered_rules': list(_o7.triggered_rules), 'skipped_reason': _o7.skipped_reason}
        st.session_state['pdf_run_status'] = 'PDF redaction completed.'
    except Exception as _o1:
        st.session_state['pdf_run_error'] = str(_o1)
        st.session_state['pdf_run_status'] = 'Failed.'
    finally:
        st.session_state['pdf_run_in_progress'] = False

def _pdf_support_available() -> bool:
    try:
        from log_anonymizer.connectors.pdf import pdf_support_available
        return bool(pdf_support_available())
    except Exception:
        return False

def _detect_pdf_support_cached(path: Path) -> tuple[bool | None, int | None, str]:
    _o2 = st.session_state.get('input_upload_sig')
    if not _o2:
        try:
            _o3 = path.stat()
            _o2 = f'{path.resolve()}:{_o3.st_size}:{_o3.st_mtime_ns}'
        except OSError:
            _o2 = str(path.resolve())
    if st.session_state.get('pdf_detect_sig') == _o2:
        return (st.session_state.get('pdf_is_supported'), st.session_state.get('pdf_pages'), str(st.session_state.get('pdf_detect_message') or ''))
    _o4, _o1, _o0 = _detect_pdf_support(path)
    st.session_state['pdf_detect_sig'] = _o2
    st.session_state['pdf_is_supported'] = _o4
    st.session_state['pdf_pages'] = _o1
    st.session_state['pdf_detect_message'] = _o0
    st.session_state['pdf_preview_texts'] = {}
    st.session_state['pdf_preview_sig'] = None
    return (_o4, _o1, _o0)

def _detect_pdf_support(path: Path) -> tuple[bool | None, int | None, str]:
    try:
        import fitz
    except Exception as _o1:
        return (None, None, str(_o1))
    try:
        _o0 = fitz.open(str(path))
    except Exception as _o1:
        return (None, None, str(_o1))
    try:
        _o5 = int(getattr(_o0, 'page_count', 0))
        _o2 = False
        for _o3 in range(_o5):
            _o4 = _o0.load_page(_o3)
            _o6 = _o4.get_text('words') or []
            if _o6:
                _o2 = True
                break
        if _o2:
            return (True, _o5, '')
        return (False, _o5, '')
    finally:
        try:
            _o0.close()
        except Exception:
            pass

def _pdf_preview_texts_cached(path: Path, rules: list[Any], *, rules_sig: str, max_pages: int) -> dict[int, str]:
    _o1 = str(st.session_state.get('pdf_detect_sig') or '')
    _o2 = f'{_o1}:{rules_sig}:{max_pages}'
    if st.session_state.get('pdf_preview_sig') == _o2 and isinstance(st.session_state.get('pdf_preview_texts'), dict):
        return dict(st.session_state['pdf_preview_texts'])
    _o0 = _build_pdf_preview_texts(path, rules, max_pages=max_pages)
    st.session_state['pdf_preview_sig'] = _o2
    st.session_state['pdf_preview_texts'] = dict(_o0)
    return _o0

def _build_pdf_preview_texts(path: Path, rules: list[Any], *, max_pages: int) -> dict[int, str]:
    try:
        import fitz
    except Exception:
        return {}
    try:
        _o0 = fitz.open(str(path))
    except Exception:
        return {}
    try:
        _o2: dict[int, str] = {}
        _o5 = int(getattr(_o0, 'page_count', 0))
        for _o4 in range(min(_o5, max_pages)):
            _o3 = _o0.load_page(_o4)
            _o8 = str(_o3.get_text('text') or '')
            _o7 = list(iter_rule_match_spans(_o8, rules, require_output=RuleOutputBehavior.pdf_redaction))
            if not _o7:
                continue
            _o1 = _mark_text_spans(_o8, [(_o6.start, _o6.end) for _o6 in _o7], limit_chars=8000)
            _o2[_o4 + 1] = _o1
        return _o2
    finally:
        try:
            _o0.close()
        except Exception:
            pass

def _mark_text_spans(text: str, spans: list[tuple[int, int]], *, limit_chars: int) -> str:
    _o7 = text[:limit_chars]
    spans = [(_o5, _o1) for _o5, _o1 in spans if 0 <= _o5 < _o1 <= len(_o7)]
    spans.sort(key=lambda x: (x[0], -(x[1] - x[0])))
    _o4: list[str] = []
    _o0 = 0
    _o3 = 0
    for _o6, _o2 in spans:
        if _o6 < _o3:
            continue
        _o4.append(_o7[_o0:_o6])
        _o4.append('[[')
        _o4.append(_o7[_o6:_o2])
        _o4.append(']]')
        _o0 = _o2
        _o3 = _o2
    _o4.append(_o7[_o0:])
    if len(text) > limit_chars:
        _o4.append('\n… (truncated)')
    return ''.join(_o4)

def _run_pipeline_thread(run: PreparedRun, cancel_token: CancellationToken, log_q: Queue[str], outcome_q: Queue[dict[str, Any]], progress_q: Queue[ProgressEvent]) -> None:
    try:
        _of = time.perf_counter()
        _o6 = bool(run.keep_partial_on_cancel)
        if not run.input_paths:
            outcome_q.put({'type': 'error', 'status': 'Failed.', 'error': 'Missing input.'})
            return
        if cancel_token.is_cancelled():
            outcome_q.put({'type': 'done', 'status': 'Cancelled.\n- No output produced.', 'archive_path': None, 'cancelled': True, 'rolled_back': False})
            return
        _o1 = len(run.input_paths) > 1
        if run.dry_run:
            if run.profile_sensitive_data and (not _o1):
                _ob = run_sensitive_data_profiling(input_path=run.input_paths[0], output_dir=run.output_dir, exclude_path=run.exclude_path, detectors=run.profiling_detectors)
                _o3 = int(round(time.perf_counter() - _of))
                _od = f'DRY RUN (profiling only)\n- Profiling report: {_ob.profiling_report_path}\n- Suggested rules: {_ob.suggested_rules_path}\n- Duration: {_o3}s\n- Files: total={_ob.total_files}, excluded={_ob.excluded_files}, profiled={_ob.profiled_files}\n'
                log_q.put(_od)
                outcome_q.put({'type': 'done', 'status': 'Dry run (profiling only) completed.', 'archive_path': None, 'profiling_report_path': str(_ob.profiling_report_path), 'suggested_rules_path': str(_ob.suggested_rules_path)})
                return
            _o3 = int(round(time.perf_counter() - _of))
            if _o1:
                _o9: list[str] = ['DRY RUN (batch)']
                for _o8 in run.input_paths:
                    _o9.append('')
                    _o9.append(_dry_run_one(run, input_path=_o8).rstrip('\n'))
                _od = '\n'.join(_o9).rstrip('\n') + f'\n- Duration: {_o3}s\n'
            else:
                _od = _dry_run_one(run, input_path=run.input_paths[0]).rstrip('\n') + f'\n- Duration: {_o3}s\n'
            log_q.put(_od)
            outcome_q.put({'type': 'done', 'status': 'Dry run completed.', 'archive_path': None})
            return
        _o2 = ProcessorConfig(parallel_enabled=bool(run.parallel_enabled), max_workers=int(run.max_workers), exclude_case_insensitive=False, include_builtin_rules=True, anonymize_filenames=bool(run.anonymize_filenames), profile_sensitive_data=bool(run.profile_sensitive_data), profiling_detectors=run.profiling_detectors, cancellation_token=cancel_token, rollback_on_cancel=not _o6, edition=run.edition)
        _oa = QueueProgressReporter(progress_q)
        if _o1:
            _o0 = process_batch_with_result(inputs=run.input_paths, rules_path=run.rules_path, output_dir=run.output_dir, exclude_path=run.exclude_path, config=_o2, batch_parallel_enabled=bool(run.batch_parallel_enabled), batch_max_workers=int(run.batch_max_workers or 2), include_item_progress=True, progress=_oa)
            _o3 = int(round(time.perf_counter() - _of))
            _o7 = ['Batch completed.', f'- Batch directory: {_o0.batch_dir}', f'- Summary JSON: {_o0.summary_path}', f'- Duration: {_o3}s', f'- Inputs: total={_o0.total}, ok={_o0.succeeded}, failed={_o0.failed}, cancelled={_o0.cancelled}, skipped={_o0.skipped}']
            outcome_q.put({'type': 'done', 'status': '\n'.join(_o7), 'archive_path': None, 'batch_items': [{'index': int(_o5.index), 'input_path': str(_o5.input_path), 'input_name': _o5.input_path.name, 'status': _o5.status, 'output_archive': str(_o5.output_archive) if _o5.output_archive else None, 'error': _o5.error} for _o5 in _o0.items], 'batch_summary_path': str(_o0.summary_path)})
        else:
            _oc = process_with_result(input_path=run.input_paths[0], rules_path=run.rules_path, output_dir=run.output_dir, exclude_path=run.exclude_path, config=_o2, progress=_oa)
            _o3 = int(round(time.perf_counter() - _of))
            if _oc.cancelled and _oc.rolled_back:
                _o10 = 'Cancelled and rolled back.'
            elif _oc.cancelled:
                _o10 = 'Cancelled with partial output kept.'
            else:
                _o10 = 'Completed.'
            _oe = [_o10]
            if _oc.output_zip.exists():
                _oe.append(f'- Output archive: {_oc.output_zip}')
            _oe.append(f'- Duration: {_o3}s')
            if _oc.profiling_report_path:
                _oe.append(f'- Profiling report: {_oc.profiling_report_path}')
            if _oc.suggested_rules_path:
                _oe.append(f'- Suggested rules: {_oc.suggested_rules_path}')
            _oe.extend([f'- Total files: {_oc.total_files}', f'- Excluded: {_oc.excluded_files}', f'- Processed: {_oc.processed_files}', f'- Failed: {_oc.failed_files}'])
            _od = '\n'.join(_oe)
            outcome_q.put({'type': 'done', 'status': _od, 'archive_path': str(_oc.output_zip) if _oc.output_zip.exists() else None, 'profiling_report_path': str(_oc.profiling_report_path) if _oc.profiling_report_path is not None else None, 'suggested_rules_path': str(_oc.suggested_rules_path) if _oc.suggested_rules_path is not None else None, 'cancelled': bool(_oc.cancelled), 'rolled_back': bool(_oc.rolled_back), 'summary': {'total': _oc.total_files, 'excluded': _oc.excluded_files, 'processed': _oc.processed_files, 'failed': _oc.failed_files}})
    except Exception as _o4:
        log_q.put(f'ERROR: {type(_o4).__name__}: {_o4}')
        outcome_q.put({'type': 'error', 'status': 'Failed.', 'error': f'{type(_o4).__name__}: {_o4}'})

def _dry_run_one(run: PreparedRun, *, input_path: Path) -> str:
    _o10 = load_rules(run.rules_path)
    _o7 = resolve_free_input_limits(edition=run.edition)
    with handle_input(input_path, limits=_o7) as _oe:
        _o1 = _oe.working_dir
        _o5 = _oe.files
        if run.edition != Edition.pro:
            _od = [_ob for _ob in _o5 if _ob.suffix.lower() == '.pdf']
            if _od:
                if input_path.suffix.lower() == '.pdf':
                    return 'DRY RUN\n- Error: PDF redaction requires a Pro license.\n'
                _o5 = [_ob for _ob in _o5 if _ob.suffix.lower() != '.pdf']
        _oc = list(default_patterns())
        if run.exclude_path is not None:
            _oc.extend(_load_exclude_patterns(run.exclude_path))
        _o2 = ExcludeFilter.from_patterns(_oc, base_dir=_o1, case_insensitive=False) if _oc else None
        _o6 = [_o4 for _o4 in _o5 if not (_o2 and _o2.should_exclude(_o4))]
    _oa = input_path.name
    _o9 = _oa.lower()
    if _o9.endswith('.tar.gz'):
        _o0 = _oa[:-len('.tar.gz')]
    elif _o9.endswith('.tgz'):
        _o0 = _oa[:-len('.tgz')]
    elif _o9.endswith('.zip'):
        _o0 = input_path.stem
    else:
        _o0 = input_path.stem or _oa
    _o11 = run.output_dir.expanduser().resolve() / f'{_o0}.tar.gz'
    _o3 = f'builtin={len(default_patterns())}'
    if run.exclude_path is not None:
        try:
            _o3 = f'{run.exclude_path} (builtin={len(default_patterns())}, user={len(_load_exclude_patterns(run.exclude_path))})'
        except Exception:
            _o3 = str(run.exclude_path)
    _o8 = ['DRY RUN', f'- Input: {input_path}', f'- Output dir: {run.output_dir}', f'- Output archive: {_o11}', f'- User rules loaded: {len(_o10)} (built-in rules are enabled by default)', f'- Exclude: {_o3}', f'- Files: total={len(_o5)}, excluded={len(_o5) - len(_o6)}, to_process={len(_o6)}']
    _of = [f'  - {_ob}' for _ob in _o6[:20]]
    if len(_o6) > 20:
        _of.append(f'  ... ({len(_o6) - 20} more)')
    return '\n'.join(_o8 + _of)

def _attach_streamlit_logger(q: Queue[str], *, verbose: bool) -> tuple[logging.Handler, list[logging.Handler]]:
    _o3 = logging.getLogger()
    _o2 = list(_o3.handlers)
    for _o0 in _o2:
        _o3.removeHandler(_o0)
    _o3.setLevel(logging.DEBUG if verbose else logging.INFO)
    _o1 = _QueueHandler(q, level=logging.DEBUG if verbose else logging.INFO)
    from log_anonymizer.config.logging_config import TextWithExtrasFormatter
    _o1.setFormatter(TextWithExtrasFormatter())
    _o3.addHandler(_o1)
    return (_o1, _o2)

def _detach_streamlit_logger(handler: logging.Handler, prev: list[logging.Handler]) -> None:
    _o1 = logging.getLogger()
    try:
        _o1.removeHandler(handler)
    except Exception:
        pass
    for _o0 in prev:
        _o1.addHandler(_o0)

def _pump_logs_once() -> None:
    _o2: Queue[str] = st.session_state['log_queue']
    _o1: list[str] = st.session_state['log_lines']
    while True:
        try:
            _o0 = _o2.get_nowait()
        except Empty:
            break
        _o1.append(_o0)
    st.session_state['log_lines'] = _o1
    _pump_progress_once()
    _pump_outcome_once()

def _pump_progress_once() -> None:
    _o4: Queue[ProgressEvent] = st.session_state['progress_queue']
    while True:
        try:
            _o0 = _o4.get_nowait()
        except Empty:
            break
        st.session_state['progress_stage'] = _o0.stage.value
        st.session_state['progress_stage_current'] = _o0.current
        st.session_state['progress_stage_total'] = _o0.total
        if _o0.message:
            st.session_state['progress_stage_message'] = _o0.message
        _o2 = str(_o0.message or '')
        _o1 = _o0.stage == ProgressStage.PROCESSING and _o0.kind in (ProgressKind.STAGE_START, ProgressKind.STAGE_PROGRESS, ProgressKind.STAGE_END) and (_o2.startswith('batch_') or _o2 in ('batch_start', 'batch_done'))
        if _o1:
            if _o0.current is not None:
                st.session_state['batch_done'] = int(_o0.current)
            if _o0.total is not None:
                st.session_state['batch_total'] = int(_o0.total)
            if _o2.startswith('batch_input='):
                st.session_state['batch_current_input'] = _o2[len('batch_input='):].strip()
        else:
            if _o2.startswith('input='):
                _o3 = _o2[len('input='):].split(' ', 1)[0].strip()
                if _o3:
                    st.session_state['batch_current_input'] = _o3
            if _o0.kind == ProgressKind.STAGE_START and _o0.stage == ProgressStage.PROCESSING:
                st.session_state['progress_files_done'] = 0
                st.session_state['progress_files_total'] = _o0.total
            if _o0.kind == ProgressKind.STAGE_PROGRESS and _o0.stage == ProgressStage.PROCESSING:
                if _o0.current is not None:
                    st.session_state['progress_files_done'] = _o0.current
                if _o0.total is not None:
                    st.session_state['progress_files_total'] = _o0.total
        if _o0.kind in (ProgressKind.FILE_START, ProgressKind.FILE_PROGRESS, ProgressKind.FILE_END):
            if _o0.path:
                st.session_state['progress_file_path'] = _o0.path
            st.session_state['progress_file_done'] = _o0.bytes_done
            st.session_state['progress_file_total'] = _o0.bytes_total

def _render_progress_panel() -> None:
    _ob = st.session_state.get('progress_stage') or ''
    _oc = st.session_state.get('progress_stage_message') or ''
    _o3 = st.session_state.get('progress_stage_current')
    _od = st.session_state.get('progress_stage_total')
    _o7 = int(st.session_state.get('progress_files_done') or 0)
    _o8 = st.session_state.get('progress_files_total')
    _o5 = st.session_state.get('progress_file_path')
    _o4 = st.session_state.get('progress_file_done')
    _o6 = st.session_state.get('progress_file_total')
    st.subheader('Progress')
    _o2 = st.session_state.get('batch_total')
    _o1 = int(st.session_state.get('batch_done') or 0)
    _o0 = str(st.session_state.get('batch_current_input') or '').strip()
    if _o2 is not None and int(_o2) > 0:
        _o9 = min(1.0, float(_o1) / float(_o2))
        _oa = f'Inputs: {_o1}/{_o2}'
        if _o0:
            _oa += f' (current: {_o0})'
        st.progress(_o9, text=_oa)
    if _o8 is not None and int(_o8) > 0:
        _o9 = min(1.0, float(_o7) / float(_o8))
        st.progress(_o9, text=f'Files: {_o7}/{_o8}')
    else:
        st.progress(0.0, text='Files: (waiting)')
    if _od is not None and _o3 is not None and (int(_od) > 0):
        _o9 = min(1.0, float(_o3) / float(_od))
        _oa = f'Stage: {_ob} {_o3}/{_od}'
        if _oc:
            _oa += f' ({_oc})'
        st.progress(_o9, text=_oa)
    else:
        _oa = f'Stage: {_ob}'.strip()
        if _oc:
            _oa = (_oa + f' ({_oc})').strip()
        st.caption(_oa or 'Stage: (waiting)')
    if _o5 and _o4 is not None and (_o6 is not None) and (int(_o6) > 0):
        _o9 = min(1.0, float(_o4) / float(_o6))
        st.progress(_o9, text=f'File: {_o5}')
    elif _o5:
        st.caption(f'File: {_o5}')

def _pump_outcome_once() -> None:
    _o3: Queue[dict[str, Any]] = st.session_state['outcome_queue']
    while True:
        try:
            _o2 = _o3.get_nowait()
        except Empty:
            break
        if _o2.get('type') == 'done':
            st.session_state['run_status'] = str(_o2.get('status') or 'Completed.')
            _o1 = _o2.get('batch_items')
            if isinstance(_o1, list) and _o1:
                st.session_state['batch_items'] = list(_o1)
            _o0 = _o2.get('archive_path')
            if isinstance(_o0, str) and _o0:
                _o4 = Path(_o0)
                if _o4.exists():
                    st.session_state['result_zip_bytes'] = _o4.read_bytes()
                    st.session_state['result_zip_name'] = _o4.name
                else:
                    st.session_state['result_zip_bytes'] = None
                    st.session_state['result_zip_name'] = None
            elif st.session_state.get('batch_items') is not None:
                st.session_state['result_zip_bytes'] = None
                st.session_state['result_zip_name'] = None
            _o5 = _o2.get('profiling_report_path')
            if isinstance(_o5, str) and _o5:
                _o4 = Path(_o5)
                if _o4.exists():
                    st.session_state['profiling_report_bytes'] = _o4.read_bytes()
                    st.session_state['profiling_report_name'] = _o4.name
            _o6 = _o2.get('suggested_rules_path')
            if isinstance(_o6, str) and _o6:
                _o4 = Path(_o6)
                if _o4.exists():
                    st.session_state['suggested_rules_bytes'] = _o4.read_bytes()
                    st.session_state['suggested_rules_name'] = _o4.name
            st.session_state['run_in_progress'] = False
            st.session_state['cancel_token'] = None
            _restore_logger_if_needed()
        elif _o2.get('type') == 'error':
            st.session_state['run_status'] = str(_o2.get('status') or 'Failed.')
            st.session_state['run_error'] = str(_o2.get('error') or 'Unknown error')
            st.session_state['run_in_progress'] = False
            st.session_state['cancel_token'] = None
            _restore_logger_if_needed()

def _restore_logger_if_needed() -> None:
    _o0 = st.session_state.get('log_handler')
    _o1 = st.session_state.get('log_prev_handlers')
    if _o0 is not None and _o1 is not None:
        _detach_streamlit_logger(_o0, _o1)
    st.session_state['log_handler'] = None
    st.session_state['log_prev_handlers'] = None

def _render_preview_tab(run: PreparedRun) -> None:
    st.caption('Paste a few log lines to preview anonymization (in-memory; no files written).')
    _o16 = st.container()
    _o17 = st.session_state.get('preview_input') or ''
    _o18 = st.session_state.get('preview_output_value') or ''
    _oa = len(_o17.splitlines()) if _o17 else 0
    _ob = len(_o18.splitlines()) if _o18 else 0
    _o2, _o3, _o4, _o0 = st.columns([1.2, 1.0, 1.0, 5.0])
    _o1 = _o2.button('Anonymize', width='stretch', disabled=bool(st.session_state.get('run_in_progress')), key='preview_anonymize_btn')
    _o5 = _o3.button('Clear', width='stretch', disabled=bool(st.session_state.get('run_in_progress')), key='preview_clear_btn')
    _o10 = _o4.button('Profile', width='stretch', disabled=bool(st.session_state.get('run_in_progress')) or FeatureFlag.profiling not in run.features, key='preview_profile_btn')
    if _o1:
        st.session_state['preview_error'] = ''
        st.session_state['preview_status'] = ''
        try:
            logger.info('ui_preview_clicked', extra={'lines_in': _oa})
            _o14 = preview_anonymization(PreviewAnonymizationRequest(text=_o17, rules_path=run.rules_path, include_builtin_rules=True))
            st.session_state['preview_output_value'] = _o14.anonymized_text
            st.session_state['preview_line_details'] = _o14.line_details
            st.session_state['preview_replacements_by_rule'] = dict(_o14.stats.replacements_by_rule)
            st.session_state['preview_status'] = f'Success. {_o14.lines_in} lines → {_o14.lines_out} lines ({_o14.stats.total_replacements} replacements).'
            _o18 = st.session_state['preview_output_value']
            _ob = len(_o18.splitlines()) if _o18 else 0
        except Exception as _o8:
            logger.exception('ui_preview_failed', extra={'error': str(_o8)})
            st.session_state['preview_error'] = f'{type(_o8).__name__}: {_o8}'
    if _o10:
        if FeatureFlag.profiling not in run.features:
            st.session_state['preview_error'] = 'Profiling requires a Pro license.'
            return
        st.session_state['preview_error'] = ''
        try:
            _o11 = SensitiveDataProfiler(config=ProfilingConfig(detectors=('email', 'ipv4', 'token', 'card')))
            _o13 = _o11.profile_text(_o17, source_name='<preview>')
            st.session_state['preview_profile_report'] = _o13.to_json()
            st.session_state['preview_suggested_rules'] = json.dumps(_o13.suggested_rules, ensure_ascii=False, indent=2) + '\n'
        except Exception as _o8:
            logger.exception('ui_preview_profile_failed', extra={'error': str(_o8)})
            st.session_state['preview_error'] = f'{type(_o8).__name__}: {_o8}'
    if _o5:
        st.session_state['preview_input'] = ''
        st.session_state['preview_output_value'] = ''
        st.session_state['preview_status'] = ''
        st.session_state['preview_error'] = ''
        st.session_state['preview_profile_report'] = ''
        st.session_state['preview_suggested_rules'] = ''
        st.session_state['preview_line_details'] = ()
        st.session_state['preview_replacements_by_rule'] = {}
        st.rerun()
    with _o16:
        if st.session_state.get('preview_status'):
            st.success(st.session_state['preview_status'])
        if st.session_state.get('preview_error'):
            st.error(st.session_state['preview_error'])
    st.text_area('Input (raw logs)', key='preview_input', height=260, placeholder='Paste a few lines here…')
    st.markdown('\n        <style>\n          div.da-preview-wrap {\n            border-radius: 10px;\n            border: 1px solid rgba(120, 120, 140, 0.25);\n            background: rgba(248, 249, 251, 1.0);\n            padding: 10px 12px;\n            max-height: 360px;\n            overflow: auto;\n          }\n          div.da-preview {\n            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;\n            font-size: 13px;\n            line-height: 1.38;\n            margin: 0;\n          }\n          div.da-line {\n            display: flex;\n            gap: 8px;\n            align-items: flex-start;\n          }\n          span.da-mark {\n            display: inline-block;\n            width: 16px;\n            opacity: 0.45;\n            flex: 0 0 16px;\n          }\n          span.da-mark-on {\n            opacity: 1.0;\n            font-weight: 700;\n          }\n          span.da-text {\n            /* Keep explicit line breaks (one log line per line), but allow wrapping for long lines. */\n            white-space: pre-wrap;\n            word-break: break-word;\n            flex: 1 1 auto;\n          }\n          span.da-hl {\n            background: rgba(255, 208, 77, 0.55);\n            border-bottom: 2px solid rgba(176, 106, 0, 0.95);\n            border-radius: 4px;\n            padding: 0 2px;\n          }\n          @media (prefers-color-scheme: dark) {\n            div.da-preview-wrap {\n              background: rgba(255, 255, 255, 0.04);\n              border-color: rgba(255, 255, 255, 0.10);\n            }\n            span.da-hl {\n              background: rgba(0, 169, 255, 0.35);\n              border-bottom: 2px solid rgba(0, 169, 255, 0.95);\n            }\n            span.da-mark-on {\n              color: rgba(0, 169, 255, 0.95);\n            }\n          }\n        </style>\n        ', unsafe_allow_html=True)
    _of = st.tabs(['Output (highlighted)', 'Output (plain text)'])
    with _of[0]:
        st.caption('Legend: highlighted text = anonymized content')
        _o7: tuple[PreviewLineDetail, ...] = st.session_state.get('preview_line_details') or ()
        if _o7:
            st.markdown(_render_highlighted_preview(_o7), unsafe_allow_html=True)
        else:
            st.info('Run a preview to see highlighted output.')
    with _of[1]:
        st.code(_o18 or '', language='text')
    _oc, _od, _oe = st.columns(3)
    _oc.metric('Input lines', _oa)
    _od.metric('Output lines', _ob)
    _oe.metric('User rules', _preview_rules_count(run))
    _o12 = st.session_state.get('preview_replacements_by_rule') or {}
    if _o12:
        with st.expander('Triggered rules (preview)', expanded=False):
            _o15 = [{'rule': _o9, 'replacements': _o19} for _o9, _o19 in sorted(_o12.items(), key=lambda kv: (-kv[1], kv[0]))]
            st.dataframe(pd.DataFrame(_o15), hide_index=True, use_container_width=True)
    if st.session_state.get('preview_profile_report'):
        with st.expander('Sensitive-data profiling report (preview)', expanded=False):
            st.code(st.session_state['preview_profile_report'], language='json')
    if st.session_state.get('preview_suggested_rules'):
        with st.expander('Suggested rules (preview)', expanded=False):
            st.code(st.session_state['preview_suggested_rules'], language='json')
    if _o18:
        _o6 = json.dumps(_o18)
        components.html(f'\n            <div style="display:flex; gap:8px; align-items:center; margin-top: 8px;">\n              <button\n                style="padding:6px 10px; border-radius:6px; border:1px solid #bbb; cursor:pointer;"\n                onclick="navigator.clipboard.writeText({_o6});"\n              >\n                Copy result\n              </button>\n              <span style="opacity:0.7; font-size: 12px;">Copies to clipboard (if allowed by your browser).</span>\n            </div>\n            ', height=44)

def _render_highlighted_preview(details: tuple[PreviewLineDetail, ...]) -> str:
    """
    Render the anonymized output with changed segments highlighted.

    Uses HTML, but escapes all user content to avoid unsafe rendering.
    """

    def _hl_line(text: str, spans) -> str:
        if not spans:
            return html.escape(text)
        _o2: list[str] = []
        _o1 = 0
        for _o3 in spans:
            _o4 = max(0, min(int(_o3.start), len(text)))
            _o0 = max(_o4, min(int(_o3.end), len(text)))
            _o2.append(html.escape(text[_o1:_o4]))
            _o2.append(f'<span class="da-hl" title="Anonymized">{html.escape(text[_o4:_o0])}</span>')
            _o1 = _o0
        _o2.append(html.escape(text[_o1:]))
        return ''.join(_o2)
    _o2: list[str] = []
    for _o1 in details:
        _o4 = 'da-mark da-mark-on' if _o1.changed_spans else 'da-mark'
        _o3 = f'<span class="{_o4}" title="Line changed">▍</span>'
        _o5 = f'<span class="da-text">{_hl_line(_o1.anonymized, _o1.changed_spans)}</span>'
        _o2.append(f'<div class="da-line">{_o3}{_o5}</div>')
    _o0 = '\n'.join(_o2)
    return f'<div class="da-preview-wrap"><div class="da-preview">{_o0}</div></div>'

def _preview_rules_count(run: PreparedRun) -> int:
    try:
        _o0 = load_rules(run.rules_path) if run.rules_path and run.rules_path.exists() else []
    except Exception:
        _o0 = []
    return len(_o0)

def _write_default_rules_file(tmp_dir: Path) -> Path:
    """
    Create a minimal rules.json file so users can run with built-in rules only.
    """
    _o0 = (tmp_dir / 'rules.json').resolve()
    if _o0.exists():
        return _o0
    _o0.write_text('{"version": 1, "rules": []}\n', encoding='utf-8')
    return _o0

def _ensure_rules_editor_initialized() -> None:
    if st.session_state.get('rules_editor_df_v1') is None:
        st.session_state['rules_editor_df_v1'] = pd.DataFrame(columns=['enable', 'description', 'trigger', 'search', 'replace', 'caseSensitive', 'priority'])
    if st.session_state.get('rules_editor_df_v2') is None:
        st.session_state['rules_editor_df_v2'] = pd.DataFrame(columns=['enable', 'description', 'trigger', 'search', 'action', 'caseSensitive', 'priority'])
    st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v1'])
    st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v2'])
    st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v1'])
    st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v2'])
    if st.session_state.get('rules_editor_mode') not in ('table_v1', 'table_v2', 'json'):
        st.session_state['rules_editor_mode'] = 'table_v1'
    if st.session_state.get('rules_editor_mode_radio') not in ('Table (v1)', 'Table (v2)', 'JSON (v1/v2)'):
        st.session_state['rules_editor_mode_radio'] = _label_for_rules_editor_mode(st.session_state['rules_editor_mode'])
    if st.session_state.get('rules_editor_text') is None:
        _o0 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_text'] = _o0.decode('utf-8')
    if st.session_state.get('rules_editor_json_widget') is None:
        st.session_state['rules_editor_json_widget'] = st.session_state['rules_editor_text']

def _label_for_rules_editor_mode(mode: str) -> str:
    if mode == 'table_v2':
        return 'Table (v2)'
    if mode == 'json':
        return 'JSON (v1/v2)'
    return 'Table (v1)'

def _mode_for_rules_editor_label(label: str) -> str:
    if label == 'Table (v2)':
        return 'table_v2'
    if label == 'JSON (v1/v2)':
        return 'json'
    return 'table_v1'

def _sync_rules_editor_json_from_tables() -> None:
    _o0 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
    _o1 = _o0.decode('utf-8')
    st.session_state['rules_editor_text'] = _o1

def _on_add_rule_clicked() -> None:
    _ensure_rules_editor_initialized()
    _o1 = st.session_state.get('rules_editor_mode_radio') or _label_for_rules_editor_mode(st.session_state.get('rules_editor_mode', 'table_v1'))
    _o2 = _mode_for_rules_editor_label(str(_o1))
    if _o2 == 'json':
        return
    if _o2 == 'table_v2':
        _o0 = st.session_state['rules_editor_df_v2']
        _o0 = pd.concat([_o0, pd.DataFrame([{'enable': True, 'priority': 0, 'description': '', 'trigger': '', 'search': '', 'action': '{"type":"redaction"}', 'caseSensitive': ''}])], ignore_index=True)
        st.session_state['rules_editor_df_v2'] = _o0
    else:
        _o0 = st.session_state['rules_editor_df_v1']
        _o0 = pd.concat([_o0, pd.DataFrame([{'enable': True, 'priority': 0, 'description': '', 'trigger': '', 'search': '', 'replace': '', 'caseSensitive': ''}])], ignore_index=True)
        st.session_state['rules_editor_df_v1'] = _o0
    _sync_rules_editor_json_from_tables()

def _on_reset_rules_clicked() -> None:
    _ensure_rules_editor_initialized()
    st.session_state['rules_editor_df_v1'] = pd.DataFrame(columns=['enable', 'description', 'trigger', 'search', 'replace', 'caseSensitive', 'priority'])
    st.session_state['rules_editor_df_v2'] = pd.DataFrame(columns=['enable', 'description', 'trigger', 'search', 'action', 'caseSensitive', 'priority'])
    st.session_state['rules_editor_table_counter'] = int(st.session_state.get('rules_editor_table_counter') or 0) + 1
    st.session_state['rules_editor_mode'] = 'table_v1'
    st.session_state['rules_editor_mode_radio'] = 'Table (v1)'
    _sync_rules_editor_json_from_tables()
    st.session_state['rules_upload_sig'] = None

def _ensure_exclude_editor_initialized() -> None:
    if st.session_state.get('exclude_editor_df') is not None:
        return
    st.session_state['exclude_editor_df'] = pd.DataFrame(columns=['pattern'])

def _sig(name: str, raw: bytes) -> str:
    _o0 = hashlib.sha256()
    _o0.update(name.encode('utf-8', errors='ignore'))
    _o0.update(b'\x00')
    _o0.update(raw[:65536])
    return _o0.hexdigest()

def _rules_df_to_json_bytes(df: 'pd.DataFrame') -> bytes:
    _oa: list[dict[str, Any]] = []
    for _o0, _o8 in df.iterrows():
        _o3 = _o8.get('enable')
        _o6 = _o8.get('priority')
        _o2 = str(_o8.get('description') or '').strip()
        _oc = str(_o8.get('trigger') or '').strip()
        _ob = str(_o8.get('search') or '').strip()
        _o7 = str(_o8.get('replace') or '')
        _o1 = _o8.get('caseSensitive')
        if not _oc and (not _ob) and (_o7 == '') and (not _o2):
            continue
        _o9: dict[str, Any] = {'description': _o2, 'trigger': _oc, 'search': _ob, 'replace': _o7}
        _o5 = _coerce_rules_editor_priority(_o6)
        if _o5:
            _o9['priority'] = _o5
        if _o3 is not None and _o3 is not True and (str(_o3).strip() != ''):
            _o9['enable'] = bool(_o3)
        if _o1 is not None and str(_o1).strip() != '':
            _o9['caseSensitive'] = _o1
        _oa.append(_o9)
    _o4 = {'version': 1, 'rules': _oa}
    return (json.dumps(_o4, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def _rules_dfs_to_json_bytes(df_v1: 'pd.DataFrame', df_v2: 'pd.DataFrame') -> bytes:
    _oc: list[dict[str, Any]] = []
    for _o0, _oa in df_v1.iterrows():
        _o5 = _oa.get('enable')
        _o8 = _oa.get('priority')
        _o4 = str(_oa.get('description') or '').strip()
        _oe = str(_oa.get('trigger') or '').strip()
        _od = str(_oa.get('search') or '').strip()
        _o9 = str(_oa.get('replace') or '')
        _o3 = _oa.get('caseSensitive')
        if not _oe and (not _od) and (_o9 == '') and (not _o4):
            continue
        _ob: dict[str, Any] = {'description': _o4, 'trigger': _oe, 'search': _od, 'replace': _o9}
        _o7 = _coerce_rules_editor_priority(_o8)
        if _o7:
            _ob['priority'] = _o7
        if _o5 is not None and _o5 is not True and (str(_o5).strip() != ''):
            _ob['enable'] = bool(_o5)
        if _o3 is not None and str(_o3).strip() != '':
            _ob['caseSensitive'] = _o3
        _oc.append(_ob)
    for _o0, _oa in df_v2.iterrows():
        _o5 = _oa.get('enable')
        _o8 = _oa.get('priority')
        _o4 = str(_oa.get('description') or '').strip()
        _oe = str(_oa.get('trigger') or '').strip()
        _od = str(_oa.get('search') or '').strip()
        _o2 = str(_oa.get('action') or '').strip()
        _o3 = _oa.get('caseSensitive')
        if not _oe and (not _od) and (not _o2) and (not _o4):
            continue
        _o1: Any
        if not _o2:
            _o1 = None
        else:
            try:
                _o1 = json.loads(_o2)
            except Exception:
                _o1 = _o2
        _ob = {'description': _o4, 'trigger': _oe, 'search': _od, 'action': _o1}
        _o7 = _coerce_rules_editor_priority(_o8)
        if _o7:
            _ob['priority'] = _o7
        if _o5 is not None and _o5 is not True and (str(_o5).strip() != ''):
            _ob['enable'] = bool(_o5)
        if _o3 is not None and str(_o3).strip() != '':
            _ob['caseSensitive'] = _o3
        _oc.append(_ob)
    _of = 2 if any((isinstance(r, dict) and r.get('action') is not None for r in _oc)) else 1
    _o6 = {'version': _of, 'rules': _oc}
    return (json.dumps(_o6, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def _write_rules_from_editor(tmp_dir: Path) -> Path:
    _ensure_rules_editor_initialized()
    _o1 = st.session_state.get('rules_editor_mode', 'table')
    if _o1 == 'json':
        _o4 = str(st.session_state.get('rules_editor_json_widget') or st.session_state.get('rules_editor_text') or '')
        _o2 = _o4.encode('utf-8')
    else:
        _o2 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
    _o0 = _validate_rules_json_bytes(_o2)
    if _o0:
        st.session_state['ui_errors'].append(f'Rules editor invalid: {_o0}')
        _o2 = b'{"version": 1, "rules": []}\n'
    _o3 = (tmp_dir / 'rules.json').resolve()
    _o3.write_bytes(_o2)
    return _o3

def _exclude_df_to_text(df: 'pd.DataFrame') -> str:
    _o2: list[str] = []
    for _o0, _o3 in df.iterrows():
        _o1 = str(_o3.get('pattern') or '').strip()
        if not _o1 or _o1.startswith('#'):
            continue
        _o2.append(_o1)
    return '\n'.join(_o2) + ('\n' if _o2 else '')

def _exclude_editor_has_patterns() -> bool:
    _ensure_exclude_editor_initialized()
    _o1 = st.session_state['exclude_editor_df']
    if _o1 is None or _o1.empty:
        return False
    for _o0, _o3 in _o1.iterrows():
        _o2 = str(_o3.get('pattern') or '').strip()
        if _o2 and (not _o2.startswith('#')):
            return True
    return False

def _write_exclude_from_editor(tmp_dir: Path) -> Path | None:
    _ensure_exclude_editor_initialized()
    _o0 = st.session_state['exclude_editor_df']
    _o4 = _exclude_df_to_text(_o0)
    _o2 = _o4.encode('utf-8')
    _o1 = _validate_exclude_bytes(_o2, filename='.exclude')
    if _o1:
        st.session_state['ui_errors'].append(f'Exclude editor invalid: {_o1}')
        return None
    _o3 = (tmp_dir / '.exclude').resolve()
    _o3.write_bytes(_o2)
    return _o3

def _maybe_load_rules_upload_into_editor(raw: bytes, *, name: str) -> None:
    _o9 = _sig(name, raw)
    if st.session_state.get('rules_upload_sig') == _o9:
        _o0 = st.session_state.get('rules_editor_df_v1')
        _o1 = st.session_state.get('rules_editor_df_v2')
        _oa = st.session_state.get('rules_editor_text')
        if isinstance(_o0, pd.DataFrame) and isinstance(_o1, pd.DataFrame) and (not _o0.empty or not _o1.empty) and isinstance(_oa, str) and _oa.strip():
            return
    st.session_state['rules_upload_sig'] = _o9
    try:
        _o3 = json.loads(raw.decode('utf-8'))
    except Exception:
        return
    _o8 = _o3.get('rules') if isinstance(_o3, dict) else None
    if not isinstance(_o8, list):
        return
    _oc = _o3.get('version', 1) if isinstance(_o3, dict) else 1
    try:
        _ob = int(_oc)
    except Exception:
        _ob = 1
    _o6: list[dict[str, Any]] = []
    _o7: list[dict[str, Any]] = []
    for _o5 in _o8:
        if not isinstance(_o5, dict):
            continue
        _o2 = _o5.get('enable', _o5.get('enabled', True))
        _o4 = _o5.get('priority', 0)
        if _o5.get('action') is not None:
            _o7.append({'enable': _o2, 'priority': _o4, 'description': _o5.get('description', ''), 'trigger': _o5.get('trigger', ''), 'search': _o5.get('search', ''), 'action': json.dumps(_o5.get('action'), ensure_ascii=False), 'caseSensitive': _o5.get('caseSensitive', '')})
        else:
            _o6.append({'enable': _o2, 'priority': _o4, 'description': _o5.get('description', ''), 'trigger': _o5.get('trigger', ''), 'search': _o5.get('search', ''), 'replace': _o5.get('replace', ''), 'caseSensitive': _o5.get('caseSensitive', '')})
    st.session_state['rules_editor_df_v1'] = pd.DataFrame(_o6, columns=['enable', 'description', 'trigger', 'search', 'replace', 'caseSensitive', 'priority'])
    st.session_state['rules_editor_df_v2'] = pd.DataFrame(_o7, columns=['enable', 'description', 'trigger', 'search', 'action', 'caseSensitive', 'priority'])
    st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v1'])
    st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v2'])
    st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v1'])
    st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v2'])
    st.session_state['rules_editor_table_counter'] = int(st.session_state.get('rules_editor_table_counter') or 0) + 1
    try:
        st.session_state['rules_editor_text'] = json.dumps(_o3, ensure_ascii=False, indent=2) + '\n'
    except Exception:
        st.session_state['rules_editor_text'] = raw.decode('utf-8', errors='replace')
    st.session_state['rules_editor_json_widget'] = st.session_state['rules_editor_text']
    if _ob == 2 or _o7:
        st.session_state['rules_editor_mode'] = 'table_v2' if _o7 else 'table_v1'
    else:
        st.session_state['rules_editor_mode'] = 'table_v1'
    st.session_state['rules_editor_mode_radio'] = _label_for_rules_editor_mode(st.session_state['rules_editor_mode'])

def _maybe_load_exclude_upload_into_editor(raw: bytes, *, name: str) -> None:
    _o3 = _sig(name, raw)
    if st.session_state.get('exclude_upload_sig') == _o3:
        if _exclude_editor_has_patterns():
            return
    st.session_state['exclude_upload_sig'] = _o3
    try:
        _o4 = raw.decode('utf-8')
    except Exception:
        return
    _o1: list[dict[str, Any]] = []
    for _o0 in _o4.splitlines():
        _o2 = _o0.strip()
        if not _o2 or _o2.startswith('#'):
            continue
        _o1.append({'pattern': _o2})
    st.session_state['exclude_editor_df'] = pd.DataFrame(_o1, columns=['pattern'])

def _render_rules_editor() -> None:
    _ensure_rules_editor_initialized()
    st.caption('Edit rules that will be applied in addition to built-in rules.')
    _o8 = st.session_state.get('license_features', frozenset())
    _o1 = FeatureFlag.advanced_rules in _o8
    _oa = ['Table (v1)', 'Table (v2)', 'JSON (v1/v2)'] if _o1 else ['Table (v1)', 'JSON (v1/v2)']
    if not _o1 and st.session_state.get('rules_editor_mode') == 'table_v2':
        st.session_state['rules_editor_mode'] = 'table_v1'
        st.session_state['rules_editor_mode_radio'] = 'Table (v1)'
    _o4 = _label_for_rules_editor_mode(st.session_state.get('rules_editor_mode', 'table_v1'))
    if st.session_state.get('rules_editor_mode_radio') not in _oa:
        st.session_state['rules_editor_mode_radio'] = _o4

    def _on_rules_editor_mode_changed() -> None:
        _o0 = st.session_state.get('rules_editor_mode_radio') or 'Table (v1)'
        st.session_state['rules_editor_mode'] = _mode_for_rules_editor_label(str(_o0))
        if st.session_state['rules_editor_mode'] == 'json':
            st.session_state['rules_editor_json_widget'] = str(st.session_state.get('rules_editor_text') or '')
    _o9 = st.radio('Editor mode', options=_oa, key='rules_editor_mode_radio', horizontal=True, on_change=_on_rules_editor_mode_changed)
    st.session_state['rules_editor_mode'] = _mode_for_rules_editor_label(_o9)
    _o2, _o3, _o0 = st.columns([1.2, 1.2, 6])
    _o2.button('Add rule', key='add_rule', disabled=st.session_state['rules_editor_mode'] == 'json', on_click=_on_add_rule_clicked)
    _o3.button('Reset rules', key='reset_rules', on_click=_on_reset_rules_clicked)
    _oc = int(st.session_state.get('rules_editor_table_counter') or 0)
    if st.session_state['rules_editor_mode'] == 'table_v1':
        st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v1'])
        st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v1'])
        _o6 = f'rules_editor_v1_{_oc}'
        _o5 = st.data_editor(st.session_state['rules_editor_df_v1'], key=_o6, num_rows='dynamic', width='stretch', column_config={'enable': st.column_config.Column('enable'), 'priority': st.column_config.NumberColumn('priority', step=1, help='Higher runs first (default: 0).'), 'description': st.column_config.TextColumn('description'), 'trigger': st.column_config.TextColumn('trigger'), 'search': st.column_config.TextColumn('search (regex)'), 'replace': st.column_config.TextColumn('replace'), 'caseSensitive': st.column_config.TextColumn('caseSensitive')})
        _install_data_editor_checkbox_single_click()
        st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_enable(_o5)
        st.session_state['rules_editor_df_v1'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v1'])
        _ob = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_text'] = _ob.decode('utf-8')
    elif st.session_state['rules_editor_mode'] == 'table_v2':
        st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_enable(st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v2'])
        _o6 = f'rules_editor_v2_{_oc}'
        _o5 = st.data_editor(st.session_state['rules_editor_df_v2'], key=_o6, num_rows='dynamic', width='stretch', column_config={'enable': st.column_config.Column('enable'), 'priority': st.column_config.NumberColumn('priority', step=1, help='Higher runs first (default: 0).'), 'description': st.column_config.TextColumn('description'), 'trigger': st.column_config.TextColumn('trigger'), 'search': st.column_config.TextColumn('search (regex)'), 'action': st.column_config.TextColumn('action (JSON)'), 'caseSensitive': st.column_config.TextColumn('caseSensitive')})
        _install_data_editor_checkbox_single_click()
        st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_enable(_o5)
        st.session_state['rules_editor_df_v2'] = _normalize_rules_editor_priority(st.session_state['rules_editor_df_v2'])
        _ob = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_text'] = _ob.decode('utf-8')
    else:

        def _on_rules_json_changed() -> None:
            st.session_state['rules_editor_text'] = str(st.session_state.get('rules_editor_json_widget') or '')
        if st.session_state.get('rules_editor_json_widget') is None:
            st.session_state['rules_editor_json_widget'] = str(st.session_state.get('rules_editor_text') or '')
        st.text_area('rules.json', key='rules_editor_json_widget', height=320, on_change=_on_rules_json_changed)
        _od = str(st.session_state.get('rules_editor_json_widget') or '')
        st.session_state['rules_editor_text'] = _od
        _ob = _od.encode('utf-8')
    _o7 = _validate_rules_json_bytes(_ob)
    if _o7:
        st.error(f'Rules validation error: {_o7}')
    else:
        st.success('Rules look valid.')
    st.subheader('Preview')
    st.code(_ob.decode('utf-8'), language='json')

def _render_exclude_editor() -> None:
    _ensure_exclude_editor_initialized()
    st.caption('Edit exclude patterns (glob style).')
    _o1, _o2, _o0 = st.columns([1.3, 1.3, 6])
    if _o1.button('Add pattern', key='add_pattern'):
        _o4 = st.session_state['exclude_editor_df']
        _o4 = pd.concat([_o4, pd.DataFrame([{'pattern': ''}])], ignore_index=True)
        st.session_state['exclude_editor_df'] = _o4
        st.rerun()
    if _o2.button('Reset exclude', key='reset_exclude'):
        st.session_state['exclude_upload_sig'] = None
        st.session_state['exclude_editor_counter'] = int(st.session_state.get('exclude_editor_counter') or 0) + 1
        _oa = st.session_state.get('exclude_upload')
        if _oa is not None:
            try:
                _o8 = bytes(_oa.getbuffer())
                _maybe_load_exclude_upload_into_editor(_o8, name=str(getattr(_oa, 'name', '.exclude')))
            except Exception:
                st.session_state['exclude_editor_df'] = pd.DataFrame(columns=['pattern'])
        else:
            st.session_state['exclude_editor_df'] = pd.DataFrame(columns=['pattern'])
        st.rerun()
    _o3 = int(st.session_state.get('exclude_editor_counter') or 0)
    _o6 = f'exclude_editor_{_o3}'
    _o5 = st.data_editor(st.session_state['exclude_editor_df'], key=_o6, num_rows='dynamic', width='stretch', column_config={'pattern': st.column_config.TextColumn('pattern')})
    st.session_state['exclude_editor_df'] = _o5
    _o9 = _exclude_df_to_text(_o5)
    _o8 = _o9.encode('utf-8')
    _o7 = _validate_exclude_bytes(_o8, filename='.exclude')
    if _o7:
        st.error(f'Exclude validation error: {_o7}')
    else:
        st.success('Exclude file looks valid.')
    st.subheader('Preview')
    st.code(_o9 or '# (no exclude patterns)\n', language='text')

def _looks_like_json(raw: bytes) -> bool:
    _o0 = raw.lstrip()[:2]
    if not _o0 or _o0[:1] not in (b'{', b'['):
        return False
    try:
        json.loads(raw.decode('utf-8'))
        return True
    except Exception:
        return False

def _validate_rules_json_bytes(raw: bytes) -> str | None:
    return validate_rules_json_bytes(raw)

def _validate_exclude_bytes(raw: bytes, *, filename: str) -> str | None:
    """
    Validate that uploaded exclude file is plausible text.

    Heuristics:
    - Must not look like JSON
    - Must be UTF-8 decodable
    - Must not contain NUL bytes
    - Each non-comment line is treated as a glob pattern
    """
    if b'\x00' in raw:
        return 'file looks binary (contains NUL bytes)'
    if _looks_like_json(raw) or filename.lower().endswith('.json'):
        return 'file looks like JSON; did you upload rules.json by mistake?'
    try:
        _o4 = raw.decode('utf-8')
    except UnicodeDecodeError:
        return 'file is not valid UTF-8 text'
    _o1 = _o4.splitlines()
    _o2 = []
    for _o0 in _o1:
        _o3 = _o0.strip()
        if not _o3 or _o3.startswith('#'):
            continue
        _o2.append(_o3)
        if len(_o3) > 512:
            return 'a pattern line is too long (>512 chars)'
    if not _o2:
        if _o4.strip():
            st.session_state['ui_warnings'].append('Exclude file contains no patterns (only comments/blank lines).')
    return None

def _normalize_rules_editor_enable(df: 'pd.DataFrame') -> 'pd.DataFrame':
    """
    Ensure `enable` exists and behaves as a boolean checkbox in the Console data editor.

    The UI can require double-clicks when a column's dtype flips between reruns.
    Keeping `enable` as a stable boolean column avoids that UX bug.
    """
    if df is None:
        return df
    if 'enable' not in df.columns:
        df = df.copy()
        df['enable'] = pd.Series([True] * len(df), dtype='bool')
    if len(df.index) == 0:
        df = df.copy()
        df['enable'] = pd.Series(dtype='bool')
        return df

    def _as_bool(v: Any) -> bool:
        if v is None:
            return True
        if isinstance(v, bool):
            return v
        if isinstance(v, (int, float)):
            return bool(v)
        if isinstance(v, str):
            _o0 = v.strip().lower()
            if _o0 in ('', 'true', '1', 'yes', 'y', 'on'):
                return True
            if _o0 in ('false', '0', 'no', 'n', 'off'):
                return False
            return True
        return True
    df = df.copy()
    try:
        _o0 = df['enable']
        if hasattr(_o0, 'fillna'):
            _o0 = _o0.fillna(True)
        df['enable'] = pd.Series([bool(_as_bool(_o1)) for _o1 in _o0.tolist()], dtype='bool')
    except Exception:
        df['enable'] = pd.Series([True] * len(df), dtype='bool')
    return df

def _coerce_rules_editor_priority(value: Any) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        if value.is_integer():
            return int(value)
        return 0
    if isinstance(value, str):
        _o0 = value.strip()
        if not _o0:
            return 0
        try:
            return int(_o0)
        except Exception:
            return 0
    return 0

def _normalize_rules_editor_priority(df: 'pd.DataFrame') -> 'pd.DataFrame':
    """
    Ensure `priority` exists and behaves as a stable integer column in the Console data editor.

    The UI can infer a float dtype when cells are empty/NaN, which makes a column feel "janky"
    across reruns. We normalize blanks to 0 and force an integer dtype.
    """
    if df is None:
        return df
    if 'priority' not in df.columns:
        df = df.copy()
        df['priority'] = pd.Series([0] * len(df), dtype='int64')
    if len(df.index) == 0:
        df = df.copy()
        df['priority'] = pd.Series(dtype='int64')
        return df
    df = df.copy()
    try:
        _o2 = df['priority']
        if hasattr(_o2, 'fillna'):
            _o2 = _o2.fillna(0)
        df['priority'] = pd.Series([_coerce_rules_editor_priority(_o3) for _o3 in _o2.tolist()], dtype='int64')
    except Exception:
        df['priority'] = pd.Series([0] * len(df), dtype='int64')
    try:
        _o1 = [_o0 for _o0 in df.columns if _o0 != 'priority'] + ['priority']
        df = df[_o1]
    except Exception:
        pass
    return df

def _install_data_editor_checkbox_single_click() -> None:
    """
    Work around `st.data_editor` checkbox UX where toggles can require a second click
    (focus/commit) to be reflected during reruns.

    This injects a small JS hook that blurs checkbox inputs inside the Data Editor after a click,
    forcing the value to commit immediately while keeping the checkbox inside the table UI.
    """
    try:
        components.html('\n<script>\n(() => {\n  try {\n    const root = window.parent?.document;\n    if (!root) return;\n    if (root.__daDataEditorCheckboxBlurInstalled) return;\n    root.__daDataEditorCheckboxBlurInstalled = true;\n    root.addEventListener(\'click\', (e) => {\n      const t = e.target;\n      if (!t || t.tagName !== \'INPUT\' || t.type !== \'checkbox\') return;\n      const inEditor = t.closest(\'[data-testid="stDataEditor"]\');\n      if (!inEditor) return;\n      // Defer blur so the UI runtime sees the toggle first, then commits.\n      setTimeout(() => { try { t.blur(); } catch (_) {} }, 0);\n    }, true);\n  } catch (_) {}\n})();\n</script>\n            ', height=0)
    except Exception:
        return
if __name__ == '__main__':
    main()
