from __future__ import annotations
import logging
import json
import os
import shutil
import tarfile
import tempfile
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from dataclasses import dataclass
from pathlib import Path
from threading import Event
from typing import Callable, Iterable, Literal
from log_anonymizer.anonymizer import AnonymizationCancelled, anonymize_file
from log_anonymizer.builtin_rules import default_rules, merge_rules
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns, load_patterns
from log_anonymizer.input_limits import FreeEditionInputLimits, resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer.filename_anonymizer import anonymize_output_relative_paths
from log_anonymizer.profiling.profiler import ProfilingConfig, SensitiveDataProfiler
from log_anonymizer.rules_loader import Rule, load_rules
from log_anonymizer.rule_actions import ActionContext
from log_anonymizer.rules_engine import order_rules_for_evaluation
from log_anonymizer.platform import PipelineContext, PipelineRegistry, default_pipeline_registry
from log_anonymizer.licensing.models import Edition
logger = logging.getLogger(__name__)
try:
    from log_anonymizer.progress import ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:
    ProgressReporter = object
    ProgressKind = None
    ProgressStage = None

    def now_event(**kwargs):
        raise RuntimeError('progress module unavailable')

@dataclass(frozen=True)
class ProcessorConfig:
    parallel_enabled: bool = False
    max_workers: int = 5
    exclude_case_insensitive: bool = False
    include_builtin_rules: bool = True
    anonymize_filenames: bool = False
    profile_sensitive_data: bool = False
    profiling_detectors: tuple[str, ...] = ('email', 'ipv4', 'token', 'card')
    profiling_report_path: Path | None = None
    suggest_rules_output_path: Path | None = None
    cancellation_token: 'CancellationToken | None' = None
    rollback_on_cancel: bool = False
    anonymization_salt: str | None = None
    edition: Edition = Edition.free
    input_limits: FreeEditionInputLimits | None = None

@dataclass(frozen=True)
class ProcessorResult:
    output_zip: Path
    total_files: int
    processed_files: int
    failed_files: int
    excluded_files: int
    profiling_report_path: Path | None = None
    suggested_rules_path: Path | None = None
    cancelled: bool = False
    rolled_back: bool = False

class CancellationToken:
    """Thread-safe cancellation flag shared across UI and processing workers."""

    def __init__(self) -> None:
        self._event = Event()

    def cancel(self) -> None:
        self._event.set()

    def is_cancelled(self) -> bool:
        return self._event.is_set()
WorkerOutcome = Literal['processed', 'failed', 'cancelled']

def process(*, input_path: Path, rules_path: Path | None, output_dir: Path, output_zip_path: Path | None=None, exclude_path: Path | None=None, config: ProcessorConfig | None=None, progress: ProgressReporter | None=None) -> Path:
    return process_with_result(input_path=input_path, rules_path=rules_path, output_dir=output_dir, output_zip_path=output_zip_path, exclude_path=exclude_path, config=config, progress=progress).output_zip

def process_with_result(*, input_path: Path, rules_path: Path | None, output_dir: Path, output_zip_path: Path | None=None, exclude_path: Path | None=None, config: ProcessorConfig | None=None, progress: ProgressReporter | None=None) -> ProcessorResult:
    """
    Main processing pipeline.

    Responsibilities:
    1) Load input (file/dir/archive)
    2) Load exclude patterns
    3) Load rules
    4) Filter files
    5) Process each file with anonymizer (parallel)
    6) Write results to a temporary directory
    7) Compress the temporary directory into a tar.gz archive in `output_dir`

    Robustness:
    - Continues on per-file errors (logs and skips failing files)
    - Always cleans up temporary directories created during processing

    Returns:
        ProcessorResult including generated archive file path.
    """
    cfg = config or ProcessorConfig()
    _o0 = ActionContext(salt=cfg.anonymization_salt or '')
    _o8 = False
    _o20 = False
    _o1: list[Path] = []
    _o19 = 0
    _od = 0
    _ob = 0
    _o1b: Path | None = None
    _o22: Path | None = None
    _o11 = output_dir.expanduser().resolve()
    if _o11.exists() and (not _o11.is_dir()):
        raise ValueError(f'--output must be a directory: {_o11}')
    _o11.mkdir(parents=True, exist_ok=True)
    _o10 = default_output_archive_path(_o11, input_path, output_zip_path=output_zip_path, anonymize_filenames=bool(cfg.anonymize_filenames))
    _o10.parent.mkdir(parents=True, exist_ok=True)
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.FINISHED, message='start'))
    _o24 = load_rules(rules_path) if rules_path is not None else []
    _o21 = merge_rules(builtin=default_rules(), user=_o24) if cfg.include_builtin_rules else _o24
    _o9 = order_rules_for_evaluation(_o21)
    _o23 = Path(tempfile.mkdtemp(prefix='log-anonymizer-out-')).resolve()
    try:
        if progress is not None:
            progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.DISCOVERY, message='start'))
        _oe = resolve_free_input_limits(edition=cfg.edition, override_free_limits=cfg.input_limits)
        with handle_input(input_path, progress=progress, limits=_oe) as _o18:
            _o25 = _o18.working_dir
            _o1 = _o18.files
            _o7: list[Path] = []
            if cfg.edition != Edition.pro:
                _o7 = [_o12 for _o12 in _o1 if _o12.suffix.lower() == '.pdf']
                if _o7:
                    if input_path.suffix.lower() == '.pdf':
                        raise ValueError('PDF redaction requires a Pro license.')
                    _o1 = [_o12 for _o12 in _o1 if _o12.suffix.lower() != '.pdf']
                    logger.warning('pdf_files_omitted_requires_pro', extra={'count': len(_o7), 'input_path': str(input_path)})
                    _log_file_paths('file_omitted_pdf_requires_pro', _o7, working_dir=_o25, limit=200, extra={'reason': 'pdf_requires_pro'})
                    if not _o1:
                        raise ValueError('This input contains PDF files only. PDF redaction requires a Pro license.')
            logger.info('pipeline_input_ready', extra={'working_dir': str(_o25), 'files': len(_o1), 'blocked_pdfs': len(_o7)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.DISCOVERY, current=len(_o1), total=len(_o1), message='done'))
            _oa = _load_exclude_filter(exclude_path, base_dir=_o25, case_insensitive=cfg.exclude_case_insensitive)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.FILTERING, current=0, total=len(_o1), message='start'))
            _of, _oc = _filter_included_files(_o1, _oa)
            _ob = len(_oc) + len(_o7)
            _log_file_paths('file_excluded_from_output', _oc, working_dir=_o25, limit=200, extra={'reason': 'exclude_match'})
            _o2: list[Path] = []
            _o15: list[Path] = []
            _o17 = default_pipeline_registry(text_anonymize_file=anonymize_file)
            for _o12 in _of:
                if _o17.pipeline_for(_o12) is not None:
                    _o2.append(_o12)
                else:
                    _o15.append(_o12)
            _log_file_paths('file_skipped_anonymization_non_text', _o15, working_dir=_o25, limit=200, extra={'reason': 'no_pipeline'})
            if _o2 and (not _o9):
                raise ValueError('No valid rules loaded; refusing to process.')
            _o1c: dict[str, Path] | None = None
            if cfg.anonymize_filenames:
                _o1d = [_safe_relative(_o12, _o25) for _o12 in _of]
                _o1f = anonymize_output_relative_paths(_o1d, _o9, action_context=_o0, preserve_extensions=True)
                _o1c = _o1f.mapping
                logger.info('filename_anonymization_enabled', extra={'changed_paths': _o1f.changed_paths, 'collisions': _o1f.collisions})
            logger.info('pipeline_files_filtered', extra={'to_process': len(_o2), 'passthrough': len(_o15), 'excluded': _ob, 'total': len(_o1)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.FILTERING, current=len(_of), total=len(_o1), message=f'included={len(_of)} excluded={_ob}'))
            if cfg.profile_sensitive_data and (not _is_cancelled(cfg)):
                _o1a = SensitiveDataProfiler(config=ProfilingConfig(detectors=cfg.profiling_detectors))
                _o1e = _o1a.profile_files(_o2, base_dir=_o25)
                _o1b = cfg.profiling_report_path or (_o11 / 'profiling_report.json').resolve()
                _o1b.write_text(_o1e.to_json(), encoding='utf-8')
                logger.info('profiling_report_written', extra={'path': str(_o1b)})
                _o22 = cfg.suggest_rules_output_path or (_o11 / 'suggested_rules.json').resolve()
                _o22.write_text(json.dumps(_o1e.suggested_rules, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                logger.info('suggested_rules_written', extra={'path': str(_o22)})
            elif _is_cancelled(cfg):
                _o8 = True
            total_in_output = len(_of)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.PROCESSING, current=0, total=total_in_output, message=f'anonymize={len(_o2)} passthrough={len(_o15)}'))
            done_count = 0

            def _on_file_done(ok: bool) -> None:
                nonlocal done_count
                done_count += 1
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.PROCESSING, current=done_count, total=total_in_output, ok=ok))
            _o5, _o4, _o3 = _process_files_parallel(files=_o2, working_dir=_o25, output_dir=_o23, rules=_o9, pipeline_registry=_o17, parallel_enabled=bool(cfg.parallel_enabled), max_workers=int(cfg.max_workers), progress=progress, on_file_done=_on_file_done, cancel_requested=lambda: _is_cancelled(cfg), action_context=_o0, output_rel_map=_o1c)
            _o8 = _o8 or _o3 > 0 or _is_cancelled(cfg)
            _o16 = 0
            _o14 = 0
            _o13 = 0
            if not _o8:
                _o16, _o14, _o13 = _copy_passthrough_files(files=_o15, working_dir=_o25, output_dir=_o23, parallel_enabled=bool(cfg.parallel_enabled), max_workers=int(cfg.max_workers), progress=progress, on_file_done=_on_file_done, cancel_requested=lambda: _is_cancelled(cfg), output_rel_map=_o1c)
                _o8 = _o8 or _o13 > 0 or _is_cancelled(cfg)
            _o19 = _o5 + _o16
            _od = _o4 + _o14
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.PROCESSING, current=done_count, total=total_in_output, message=f'processed={_o19} failed={_od} cancelled={int(_o8)}'))
            if _o8 and cfg.rollback_on_cancel:
                _o20 = True
                if _o10.exists():
                    _o10.unlink()
            else:
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.ARCHIVE, message='start'))
                try:
                    _o6 = (lambda: _is_cancelled(cfg)) if not _o8 else None
                    _tar_gz_dir(_o23, _o10, progress=progress, cancel_requested=_o6)
                except AnonymizationCancelled:
                    _o8 = True
                    _o20 = True
                    if _o10.exists():
                        _o10.unlink()
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.ARCHIVE, message='done' if not _o20 else 'cancelled'))
    finally:
        shutil.rmtree(_o23, ignore_errors=True)
    logger.info('pipeline_done', extra={'output_dir': str(_o11), 'output_zip': str(_o10), 'processed': _o19, 'failed': _od, 'excluded': _ob, 'total': len(_o1), 'cancelled': _o8, 'rolled_back': _o20})
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.FINISHED, message='done'))
    return ProcessorResult(output_zip=_o10, total_files=len(_o1), processed_files=_o19, failed_files=_od, excluded_files=_ob, profiling_report_path=_o1b, suggested_rules_path=_o22, cancelled=_o8, rolled_back=_o20)

def _is_cancelled(cfg: ProcessorConfig) -> bool:
    _o0 = cfg.cancellation_token
    return bool(_o0 is not None and _o0.is_cancelled())

def _load_exclude_filter(exclude_path: Path | None, *, base_dir: Path, case_insensitive: bool) -> ExcludeFilter | None:
    _o1: list[str] = list(default_patterns())
    if exclude_path is not None:
        _o0 = exclude_path.expanduser().resolve()
        if not _o0.exists():
            raise FileNotFoundError(_o0)
        logger.info('exclude_loaded', extra={'path': str(_o0)})
        _o1.extend(load_patterns(_o0))
    if not _o1:
        return None
    return ExcludeFilter.from_patterns(_o1, base_dir=base_dir, case_insensitive=case_insensitive)

def _is_excluded(path: Path, exclude_filter: ExcludeFilter | None) -> bool:
    if exclude_filter is None:
        return False
    return exclude_filter.should_exclude(path)

def _should_include_in_output(path: Path, exclude_filter: ExcludeFilter | None) -> bool:
    return not _is_excluded(path, exclude_filter)

def _filter_included_files(files: Iterable[Path], exclude_filter: ExcludeFilter | None) -> tuple[list[Path], list[Path]]:
    _o2: list[Path] = []
    _o0: list[Path] = []
    for _o1 in files:
        if _should_include_in_output(_o1, exclude_filter):
            _o2.append(_o1)
        else:
            _o0.append(_o1)
    return (_o2, _o0)

def _copy_passthrough_files(*, files: list[Path], working_dir: Path, output_dir: Path, parallel_enabled: bool, max_workers: int, progress: ProgressReporter | None=None, on_file_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None, output_rel_map: dict[str, Path] | None=None) -> tuple[int, int, int]:
    if not files:
        return (0, 0, 0)

    def _worker(src: Path) -> WorkerOutcome:
        try:
            if cancel_requested is not None and cancel_requested():
                return 'cancelled'
            _o4 = _safe_relative(src, working_dir)
            _o3 = output_rel_map.get(_o4.as_posix(), _o4) if output_rel_map is not None else _o4
            _o1 = output_dir / _o3
            _o1.parent.mkdir(parents=True, exist_ok=True)
            if progress is not None:
                try:
                    _o5 = int(src.stat().st_size)
                except OSError:
                    _o5 = None
                progress.emit(now_event(kind=ProgressKind.FILE_START, stage=ProgressStage.PROCESSING, path=_o4.as_posix(), bytes_done=0, bytes_total=_o5, message='passthrough_start'))
            logger.info('file_passthrough_start', extra={'file_name': src.name, 'path': str(src), 'rel': _o4.as_posix(), 'out_rel': _o3.as_posix(), 'dest': str(_o1)})
            _o0 = _copy_file_atomic(src, _o1, cancel_requested=cancel_requested)
            if not _o0:
                if progress is not None:
                    progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_o4.as_posix(), ok=False, message='passthrough_cancelled'))
                return 'cancelled'
            logger.info('file_passthrough_done', extra={'file_name': src.name, 'path': str(src), 'rel': _o4.as_posix(), 'out_rel': _o3.as_posix(), 'dest': str(_o1)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_o4.as_posix(), ok=True, message='passthrough_done'))
            return 'processed'
        except Exception as _o2:
            logger.exception('file_passthrough_error', extra={'file_name': src.name, 'src': str(src), 'error': str(_o2)})
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_safe_relative(src, working_dir).as_posix(), ok=False, message='passthrough_failed'))
            return 'failed'
    return _run_file_workers(files=files, worker=_worker, parallel_enabled=parallel_enabled, max_workers=max_workers, phase='passthrough', on_item_done=on_file_done, cancel_requested=cancel_requested)

def _log_file_paths(event: str, files: list[Path], *, working_dir: Path, limit: int, extra: dict[str, object] | None=None) -> None:
    """
    Log per-file paths for pipeline decisions (exclusion, skipping anonymization, etc.).

    Uses INFO level but caps output to avoid flooding logs on huge support bundles.
    """
    if not files:
        return
    _o0 = dict(extra or {})
    _o0.update({'count': len(files), 'limit': limit})
    logger.info(f'{event}_summary', extra=_o0)
    _o3 = 0
    for _o1 in files:
        if _o3 >= limit:
            break
        _o2 = _safe_relative(_o1, working_dir)
        logger.info(event, extra={**(extra or {}), 'file_name': _o1.name, 'path': str(_o1), 'rel': _o2.as_posix()})
        _o3 += 1
    if len(files) > limit:
        logger.info(f'{event}_truncated', extra={**(extra or {}), 'shown': limit, 'remaining': len(files) - limit})

def _process_files_parallel(*, files: list[Path], working_dir: Path, output_dir: Path, rules: list[Rule], pipeline_registry: PipelineRegistry, parallel_enabled: bool, max_workers: int, progress: ProgressReporter | None=None, on_file_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None, action_context: ActionContext | None=None, output_rel_map: dict[str, Path] | None=None) -> tuple[int, int, int]:
    if not files:
        return (0, 0, 0)

    def _worker(src: Path) -> WorkerOutcome:
        try:
            if cancel_requested is not None and cancel_requested():
                return 'cancelled'
            _o4 = _safe_relative(src, working_dir)
            _o2 = output_rel_map.get(_o4.as_posix(), _o4) if output_rel_map is not None else _o4
            _o0 = output_dir / _o2
            _o3 = pipeline_registry.pipeline_for(src)
            if _o3 is None:
                raise RuntimeError(f'No pipeline registered for {src}')
            _o3.process_file(source_path=src, dest_path=_o0, rules=rules, context=PipelineContext(rel_path=_o4.as_posix(), progress=progress, cancel_requested=cancel_requested, action_context=action_context))
            return 'processed'
        except AnonymizationCancelled:
            return 'cancelled'
        except Exception as _o1:
            logger.exception('file_error', extra={'src': str(src), 'error': str(_o1)})
            return 'failed'
    return _run_file_workers(files=files, worker=_worker, parallel_enabled=parallel_enabled, max_workers=max_workers, phase='anonymize', on_item_done=on_file_done, cancel_requested=cancel_requested)

def _run_file_workers(*, files: list[Path], worker: Callable[[Path], WorkerOutcome], parallel_enabled: bool, max_workers: int, phase: str, on_item_done: Callable[[bool], None] | None=None, cancel_requested: Callable[[], bool] | None=None) -> tuple[int, int, int]:
    _o8 = 0
    _o4 = 0
    _o0 = 0
    if not parallel_enabled:
        logger.info('parallel_mode_disabled', extra={'phase': phase, 'mode': 'sequential', 'files': len(files)})
        logger.info('processing_start', extra={'phase': phase, 'files': len(files), 'workers': 1})
        for _o6, _o3 in enumerate(files, start=1):
            if cancel_requested is not None and cancel_requested():
                _o0 += len(files) - (_o6 - 1)
                break
            _o7 = worker(_o3)
            if _o7 == 'processed':
                _o8 += 1
            elif _o7 == 'failed':
                _o4 += 1
            else:
                _o0 += 1
            if on_item_done is not None:
                on_item_done(_o7 == 'processed')
            if _o6 == 1 or _o6 % 100 == 0 or _o6 == len(files):
                logger.info('processing_progress', extra={'phase': phase, 'done': _o6, 'total': len(files), 'processed': _o8, 'failed': _o4, 'cancelled': _o0})
        return (_o8, _o4, _o0)
    if max_workers <= 0:
        raise ValueError(f'max_workers must be >= 1 (got {max_workers})')
    logger.info('parallel_mode_enabled', extra={'phase': phase, 'mode': 'parallel', 'max_workers': max_workers, 'files': len(files)})
    logger.info('processing_start', extra={'phase': phase, 'files': len(files), 'workers': max_workers})
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        pending = set()
        files_iter = iter(files)
        started = 0
        _o1 = 0

        def _submit_next() -> bool:
            nonlocal started
            try:
                _o0 = next(files_iter)
            except StopIteration:
                return False
            pending.add(pool.submit(worker, _o0))
            started += 1
            return True
        while len(pending) < max_workers:
            if cancel_requested is not None and cancel_requested():
                break
            if not _submit_next():
                break
        while pending:
            _o2, pending = wait(pending, return_when=FIRST_COMPLETED)
            for _o5 in _o2:
                _o1 += 1
                try:
                    _o7 = _o5.result()
                except Exception:
                    logger.exception('worker_future_failed', extra={'phase': phase})
                    _o7 = 'failed'
                if _o7 == 'processed':
                    _o8 += 1
                elif _o7 == 'failed':
                    _o4 += 1
                else:
                    _o0 += 1
                if on_item_done is not None:
                    on_item_done(_o7 == 'processed')
                if _o1 == 1 or _o1 % 100 == 0 or _o1 == len(files):
                    logger.info('processing_progress', extra={'phase': phase, 'done': _o1, 'total': len(files), 'processed': _o8, 'failed': _o4, 'cancelled': _o0})
            while len(pending) < max_workers:
                if cancel_requested is not None and cancel_requested():
                    break
                if not _submit_next():
                    break
        _o0 += max(0, len(files) - started)
    return (_o8, _o4, _o0)

def _copy_file_atomic(src: Path, dest: Path, *, cancel_requested: Callable[[], bool] | None=None) -> bool:
    _o1, _o2 = tempfile.mkstemp(prefix=f'.{dest.name}.', suffix='.tmp', dir=str(dest.parent))
    os.close(_o1)
    _o0 = Path(_o2)
    try:
        if cancel_requested is not None and cancel_requested():
            return False
        shutil.copy2(src, _o0)
        if cancel_requested is not None and cancel_requested():
            return False
        os.replace(_o0, dest)
        return True
    finally:
        try:
            if _o0.exists():
                _o0.unlink()
        except OSError:
            pass

def _safe_relative(path: Path, root: Path) -> Path:
    """
    Compute a stable relative path to preserve structure.
    Falls back to filename if `path` is not under `root`.
    """
    try:
        return path.resolve().relative_to(root.resolve())
    except ValueError:
        return Path(path.name)

def _is_tar_gz_path(path: Path) -> bool:
    _o0 = path.name.lower()
    return _o0.endswith('.tar.gz') or _o0.endswith('.tgz')

def default_output_archive_path(output_dir: Path, input_path: Path, *, output_zip_path: Path | None=None, anonymize_filenames: bool=False) -> Path:
    """
    Resolve the output archive path (tar.gz) such that the CLI output is a single archive
    inside `output_dir`.
    """
    output_dir = output_dir.resolve()
    if output_zip_path is None:
        _o0 = 'anonymized_output' if anonymize_filenames else _archive_base_name(input_path)
        return (output_dir / f'{_o0}.tar.gz').resolve()
    _o1 = output_zip_path.expanduser().resolve()
    if not _is_tar_gz_path(_o1):
        raise ValueError(f'Output archive must end with .tar.gz or .tgz: {_o1}')
    if output_dir != _o1.parent and output_dir not in _o1.parents:
        raise ValueError(f'Output archive must be inside --output directory: {_o1}')
    return _o1

def _archive_base_name(input_path: Path) -> str:
    _o2 = input_path.expanduser()
    _o1 = _o2.name
    _o0 = _o1.lower()
    if _o0.endswith('.tar.gz'):
        return _o1[:-len('.tar.gz')]
    if _o0.endswith('.tgz'):
        return _o1[:-len('.tgz')]
    if _o0.endswith('.zip'):
        return _o2.stem
    return _o2.stem or _o1

def _tar_gz_dir(root_dir: Path, out_tar_gz: Path, *, progress: ProgressReporter | None=None, cancel_requested: Callable[[], bool] | None=None) -> None:
    _o4, _o5 = tempfile.mkstemp(prefix=f'.{out_tar_gz.name}.', suffix='.tmp', dir=str(out_tar_gz.parent))
    os.close(_o4)
    _o6 = Path(_o5)
    if out_tar_gz.exists():
        out_tar_gz.unlink()
    try:
        with tarfile.open(_o6, mode='w:gz') as _o3:
            _o0 = [_o2 for _o2 in root_dir.rglob('*') if _o2.is_file()]
            _o0.sort(key=lambda p: p.relative_to(root_dir).as_posix())
            _o7 = len(_o0)
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.ARCHIVE, current=0, total=_o7, message='collect'))
            for _o1, _o2 in enumerate(_o0, start=1):
                if cancel_requested is not None and cancel_requested():
                    raise AnonymizationCancelled('cancelled while writing archive')
                if _o2.resolve() == out_tar_gz.resolve():
                    continue
                _o3.add(_o2, arcname=_o2.relative_to(root_dir).as_posix(), recursive=False)
                if progress is not None:
                    if _o1 == 1 or _o1 == _o7 or _o1 % 200 == 0:
                        progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.ARCHIVE, current=_o1, total=_o7, message='writing'))
        os.replace(_o6, out_tar_gz)
    finally:
        try:
            if _o6.exists():
                _o6.unlink()
        except OSError:
            pass
