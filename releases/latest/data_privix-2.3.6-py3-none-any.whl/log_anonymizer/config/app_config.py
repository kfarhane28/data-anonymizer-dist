from __future__ import annotations
import configparser
import os
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class LoggingSettings:
    level: str = 'INFO'
    fmt: str = 'json'

@dataclass(frozen=True)
class AnonymizationSettings:
    salt: str = ''

@dataclass(frozen=True)
class AppConfig:
    logging: LoggingSettings = LoggingSettings()
    anonymization: AnonymizationSettings = AnonymizationSettings()

def resolve_config_path(cli_path: Path | None) -> Path | None:
    """
    Resolve config path with the following precedence:
    1) CLI `--config`
    2) `DATA_PRIVIX_CONFIG` environment variable (legacy: `DATA_ANONYMIZER_CONFIG`, `LOG_ANONYMIZER_CONFIG`)
    3) `./data-privix.ini` or `./log-anonymizer.ini` in the current working directory
    """
    if cli_path is not None:
        return cli_path.expanduser().resolve()
    _o2 = os.getenv('DATA_PRIVIX_CONFIG') or os.getenv('DATA_ANONYMIZER_CONFIG') or os.getenv('LOG_ANONYMIZER_CONFIG')
    if _o2:
        return Path(_o2).expanduser().resolve()
    for _o0 in ('data-privix.ini', 'log-anonymizer.ini'):
        _o1 = Path.cwd() / _o0
        if _o1.exists():
            return _o1.resolve()
    return None

def load_config(path: Path | None) -> AppConfig:
    """
    Load configuration from an INI file. Missing file returns defaults.

    Supported sections/keys:
    - [logging]
      - level: INFO/DEBUG/...
      - format: json|text
    - [anonymization]
      - salt: optional stable secret used by some actions
    """
    if path is None:
        return AppConfig()
    if not path.exists():
        return AppConfig()
    _o2 = configparser.ConfigParser()
    _o2.read(path, encoding='utf-8')
    _o1 = _o2.get('logging', 'level', fallback='INFO').strip() or 'INFO'
    _o0 = _o2.get('logging', 'format', fallback='json').strip() or 'json'
    _o3 = _o2.get('anonymization', 'salt', fallback='').strip()
    return AppConfig(logging=LoggingSettings(level=_o1, fmt=_o0), anonymization=AnonymizationSettings(salt=_o3))
