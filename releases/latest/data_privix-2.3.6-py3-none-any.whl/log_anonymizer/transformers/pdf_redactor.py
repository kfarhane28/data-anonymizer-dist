from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from log_anonymizer.analyzers.pdf_analyzer import PdfAnalysis
from log_anonymizer.transformers.base import Transformer

@dataclass(frozen=True)
class PdfRedactionArtifact:
    """
    Carries the mutated PDF document plus analysis needed for writing summary artifacts.
    """
    document: Any
    analysis: PdfAnalysis

class PdfRedactor(Transformer[Any, PdfAnalysis, PdfRedactionArtifact]):

    def transform(self, document: Any, analysis: PdfAnalysis) -> PdfRedactionArtifact:
        if not analysis.has_extractable_text:
            return PdfRedactionArtifact(document=document, analysis=analysis)
        if not analysis.targets:
            return PdfRedactionArtifact(document=document, analysis=analysis)
        _o0 = _import_fitz()
        _o5: dict[int, list[tuple[float, float, float, float]]] = {}
        for _o4 in analysis.targets:
            _o5.setdefault(_o4.page_index, []).append((_o4.x0, _o4.y0, _o4.x1, _o4.y1))
        for _o2, _o3 in _o5.items():
            _o1 = document.load_page(_o2)
            for _o6, _o8, _o7, _o9 in _o3:
                _o1.add_redact_annot(_o0.Rect(_o6, _o8, _o7, _o9), fill=(0, 0, 0))
            _o1.apply_redactions()
        return PdfRedactionArtifact(document=document, analysis=analysis)

def _import_fitz() -> Any:
    try:
        import fitz
    except Exception as _o0:
        raise RuntimeError("PDF support requires the optional dependency 'pymupdf'. Install with: pip install 'data-privix[pdf]' (legacy: 'data-anonymizer[pdf]')") from _o0
    return fitz
