from __future__ import annotations
import logging
import secrets
from dataclasses import dataclass
from pathlib import Path
from log_anonymizer.engine.anonymizer import AnonymizationEngine
from log_anonymizer.infrastructure.filtering.exclude_filter import ExcludeFilter
from log_anonymizer.infrastructure.filtering.file_collector import collect_files
from log_anonymizer.infrastructure.input_handlers.directory import DirectoryInputHandler
from log_anonymizer.infrastructure.input_handlers.single_file import SingleFileInputHandler
from log_anonymizer.infrastructure.input_handlers.tar_gz_archive import TarGzArchiveInputHandler
from log_anonymizer.infrastructure.input_handlers.zip_archive import ZipArchiveInputHandler
from log_anonymizer.infrastructure.output.tar_gz_output import TarGzOutputManager
from log_anonymizer.infrastructure.rules_loader.json_rules_loader import JsonRulesLoader
from log_anonymizer.utils.io import open_text_best_effort
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class AnonymizeLogsRequest:
    input_path: Path
    output_zip_path: Path
    rules_path: Path
    exclude_path: Path | None = None
    salt: str | None = None

def anonymize_logs(req: AnonymizeLogsRequest) -> None:
    _o5 = req.input_path
    logger.info('starting', extra={'input': str(_o5), 'output': str(req.output_zip_path)})
    _o8 = JsonRulesLoader(req.rules_path).load()
    _o9 = req.salt or secrets.token_hex(16)
    if req.salt is None:
        logger.info('generated_salt', extra={'salt': _o9})
    _o0 = AnonymizationEngine(rules=_o8.rules, hash_config=_o8.hash_config, salt=_o9)
    _o4 = _select_input_handler(_o5)
    _o7 = _o4.prepare(_o5)
    try:
        _o1 = _load_exclude(req.exclude_path, _o7.root_dir, _o5)
        _o3 = collect_files(root_dir=_o7.root_dir, only_relative=_o7.only_relative, exclude=_o1)
        logger.info('collected_files', extra={'count': len(_o3)})
        with TarGzOutputManager(req.output_zip_path) as _o6:
            for _o2 in _o3:
                _anonymize_one(_o0, _o2.absolute_path, _o6.root_dir / _o2.relative_path)
        logger.info('done', extra={'output': str(req.output_zip_path), 'files': len(_o3)})
    finally:
        _o7.cleanup()

def _select_input_handler(input_path: Path):
    if input_path.is_dir():
        return DirectoryInputHandler()
    if input_path.is_file() and _is_tar_gz(input_path):
        return TarGzArchiveInputHandler()
    if input_path.is_file() and input_path.suffix.lower() == '.zip':
        return ZipArchiveInputHandler()
    if input_path.is_file():
        return SingleFileInputHandler()
    raise ValueError(f'Unsupported input path: {input_path}')

def _is_tar_gz(path: Path) -> bool:
    _o0 = path.name.lower()
    return _o0.endswith('.tar.gz') or _o0.endswith('.tgz')

def _load_exclude(exclude_path: Path | None, prepared_root: Path, original_input: Path) -> ExcludeFilter | None:
    if exclude_path is not None:
        return ExcludeFilter.from_file(exclude_path)
    _o1: list[Path] = []
    if original_input.is_dir():
        _o1.append(original_input / '.exclude')
    elif original_input.is_file():
        _o1.append(original_input.parent / '.exclude')
    _o1.append(prepared_root / '.exclude')
    for _o0 in _o1:
        if _o0.exists() and _o0.is_file():
            logger.info('using_exclude_file', extra={'path': str(_o0)})
            return ExcludeFilter.from_file(_o0)
    return None

def _anonymize_one(engine: AnonymizationEngine, src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    logger.info('anonymizing_file', extra={'src': str(src), 'dest': str(dest)})
    try:
        with open_text_best_effort(src) as _o1, dest.open('w', encoding='utf-8', newline='') as _o2:
            for _o3 in _o1:
                _o2.write(engine.anonymize_text(_o3))
    except ValueError as _o0:
        logger.warning('skipping_file', extra={'src': str(src), 'reason': str(_o0)})
