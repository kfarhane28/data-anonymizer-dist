from __future__ import annotations
import os
from dataclasses import dataclass
from log_anonymizer.licensing.features import FREE_FEATURES, PRO_FEATURES, FeatureFlag
from log_anonymizer.licensing.models import Edition, ValidationResult
from log_anonymizer.licensing.storage import LicenseStorage
from log_anonymizer.licensing.validator import validate_license_key

@dataclass(frozen=True)
class LicensingService:
    storage: LicenseStorage

    @classmethod
    def default(cls) -> 'LicensingService':
        return cls(storage=LicenseStorage.default())

    def load_key(self) -> str | None:
        _o0 = os.environ.get('DATA_PRIVIX_LICENSE_KEY') or os.environ.get('DATA_ANONYMIZER_LICENSE_KEY') or os.environ.get('LOG_ANONYMIZER_LICENSE_KEY')
        if _o0 and _o0.strip():
            return _o0.strip()
        return self.storage.load()

    def validate(self) -> ValidationResult:
        return validate_license_key(self.load_key())

    def edition(self) -> Edition:
        _o0 = self.validate()
        if _o0.valid and _o0.license_info is not None and (_o0.license_info.edition == Edition.pro):
            return Edition.pro
        return Edition.free

    def enabled_features(self) -> frozenset[FeatureFlag]:
        _o0 = self.validate()
        if not _o0.valid or _o0.license_info is None:
            return FREE_FEATURES
        if _o0.license_info.enabled_features is None:
            return PRO_FEATURES
        return frozenset(_o0.license_info.enabled_features)
