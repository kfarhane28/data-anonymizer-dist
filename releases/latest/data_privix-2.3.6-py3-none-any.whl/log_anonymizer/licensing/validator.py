from __future__ import annotations
import base64
import json
import os
import re
from datetime import date, datetime, timezone
from typing import Any
from log_anonymizer import __version__
from log_anonymizer.licensing.features import FeatureFlag, PRO_FEATURES
from log_anonymizer.licensing.models import Edition, LicenseInfo, ValidationReason, ValidationResult
from log_anonymizer.licensing.public_key import PUBLIC_KEY_B64
_B64URL_RE = re.compile('^[A-Za-z0-9_-]+$')

def _b64url_decode(s: str) -> bytes:
    s = s.strip()
    if not s or not _B64URL_RE.match(s):
        raise ValueError('not base64url')
    _o0 = '=' * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + _o0)

def _parse_iso_date(value: Any) -> date:
    if not isinstance(value, str) or not value.strip():
        raise ValueError('expiry_date must be an ISO date string')
    _o1 = value.strip()
    try:
        return date.fromisoformat(_o1)
    except ValueError as _o0:
        raise ValueError('expiry_date must be in YYYY-MM-DD format') from _o0

def _parse_version_tuple(v: str) -> tuple[int, int, int]:
    _o0 = re.match('^\\s*(\\d+)\\.(\\d+)\\.(\\d+)', str(v))
    if not _o0:
        raise ValueError('max_version must look like X.Y.Z')
    return (int(_o0.group(1)), int(_o0.group(2)), int(_o0.group(3)))

def _version_gt(a: str, b: str) -> bool:
    return _parse_version_tuple(a) > _parse_version_tuple(b)

def _load_public_key_bytes() -> bytes:
    """
    Embedded *public* key for signature verification (not a secret).

    For test/enterprise deployments, it can be overridden via:
    - $DATA_PRIVIX_PUBLIC_KEY_B64 (base64 of raw Ed25519 public key bytes; legacy: $DATA_ANONYMIZER_PUBLIC_KEY_B64, $LOG_ANONYMIZER_PUBLIC_KEY_B64)
    """
    _o0 = os.environ.get('DATA_PRIVIX_PUBLIC_KEY_B64') or os.environ.get('DATA_ANONYMIZER_PUBLIC_KEY_B64') or os.environ.get('LOG_ANONYMIZER_PUBLIC_KEY_B64')
    if _o0:
        return base64.b64decode(_o0.strip())
    return base64.b64decode(PUBLIC_KEY_B64)

def validate_license_key(key: str | None) -> ValidationResult:
    if not key or not str(key).strip():
        return ValidationResult(valid=False, reason=ValidationReason.missing, message='license key missing')
    _of = str(key).strip()
    _ob = _of.split('.')
    if len(_ob) != 3 or _ob[0] != 'LA1':
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message='license key format invalid')
    try:
        _od = _b64url_decode(_ob[1])
        _o11 = _b64url_decode(_ob[2])
    except Exception as _o4:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=f'invalid encoding: {_o4}')
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ModuleNotFoundError:
        return ValidationResult(valid=False, reason=ValidationReason.crypto_unavailable, message='missing dependency: install "data-privix[pro]" (legacy: "data-anonymizer[pro]", "log-anonymizer[pro]")')
    try:
        _oe = Ed25519PublicKey.from_public_bytes(_load_public_key_bytes())
        _oe.verify(_o11, _od)
    except Exception:
        return ValidationResult(valid=False, reason=ValidationReason.invalid_signature, message='invalid signature')
    try:
        _oc = json.loads(_od.decode('utf-8'))
    except Exception as _o4:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=f'invalid JSON payload: {_o4}')
    if not isinstance(_oc, dict):
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message='payload must be an object')
    try:
        _o1 = str(_oc.get('customer_name') or '').strip()
        _o0 = str(_oc.get('customer_id') or '').strip()
        _o2 = str(_oc.get('edition') or '').strip().lower()
        _o5 = _parse_iso_date(_oc.get('expiry_date'))
        _o8 = _oc.get('max_version')
        _o9 = str(_o8).strip() if isinstance(_o8, str) and _o8.strip() else None
        _o6 = _oc.get('features')
    except Exception as _o4:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=str(_o4))
    if not _o1 or not _o0:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message='customer fields missing')
    if _o2 != Edition.pro.value:
        return ValidationResult(valid=False, reason=ValidationReason.unsupported_edition, message=f"unsupported edition: {_o2 or '<missing>'}")
    _o12 = datetime.now(timezone.utc).date()
    if _o5 < _o12:
        return ValidationResult(valid=False, reason=ValidationReason.expired, message='license expired')
    if _o9 is not None:
        try:
            if _version_gt(__version__, _o9):
                return ValidationResult(valid=False, reason=ValidationReason.max_version_exceeded, message=f'license max_version exceeded (max={_o9}, current={__version__})')
        except Exception as _o4:
            return ValidationResult(valid=False, reason=ValidationReason.malformed, message=str(_o4))
    _o3: tuple[FeatureFlag, ...] | None = None
    if _o6 is not None:
        if not isinstance(_o6, list) or not all((isinstance(x, str) for x in _o6)):
            return ValidationResult(valid=False, reason=ValidationReason.malformed, message='features must be a list of strings')
        _o10: list[FeatureFlag] = []
        for _oa in _o6:
            try:
                _o10.append(FeatureFlag(_oa))
            except Exception:
                continue
        _o3 = tuple((f for f in _o10 if f in PRO_FEATURES))
    _o7 = LicenseInfo(customer_name=_o1, customer_id=_o0, edition=Edition.pro, expiry_date=_o5, max_version=_o9, enabled_features=_o3)
    return ValidationResult(valid=True, reason=ValidationReason.ok, license_info=_o7, message='ok')
