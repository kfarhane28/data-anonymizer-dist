from __future__ import annotations
import hashlib
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any, Callable, Protocol

@dataclass(frozen=True)
class ActionContext:
    """
    Runtime context for rule actions.

    Notes:
    - Salt is optional to preserve backward compatibility and keep CLI/UI behavior unchanged.
    - For strong pseudonymization, configure a stable salt (e.g. via config) and keep it secret.
    """
    salt: str = ''
ReplacementCallable = Callable[[re.Match[str]], str]
Replacement = str | ReplacementCallable

class RuleAction(Protocol):
    type: str

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        ...

@dataclass(frozen=True)
class ReplacementAction:
    type: str = 'replacement'
    value: str = ''

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        return self.value

@dataclass(frozen=True)
class RedactionAction:
    type: str = 'redaction'

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        return ''

@dataclass(frozen=True)
class MaskAction:
    type: str = 'mask'
    mask_char: str = '*'
    keep_first: int = 0
    keep_last: int = 0

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        mask_char = self.mask_char
        keep_first = self.keep_first
        keep_last = self.keep_last

        def _repl(match: re.Match[str]) -> str:
            _o3 = match.group(0)
            if not _o3:
                return _o3
            _o2 = len(_o3)
            _o0 = min(max(keep_first, 0), _o2)
            _o4 = min(max(keep_last, 0), _o2 - _o0)
            _o1 = _o2 - _o0 - _o4
            if _o1 <= 0:
                return _o3
            return _o3[:_o0] + mask_char * _o1 + _o3[_o2 - _o4:]
        return _repl

@dataclass(frozen=True)
class FixedMaskAction:
    """
    Mask with a fixed number of mask characters, independent of the input length.

    This is useful when you want deterministic, short masked examples like:
    - email local part: "c***@example.com" (keepFirst=1, maskLength=3)
    - IPv4 middle octets: "10.***.***.80" (keepFirst=0, keepLast=0, maskLength=3)
    """
    type: str = 'mask_fixed'
    mask_char: str = '*'
    keep_first: int = 0
    keep_last: int = 0
    mask_length: int = 3

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        mask_char = self.mask_char
        keep_first = self.keep_first
        keep_last = self.keep_last
        mask_length = self.mask_length

        def _repl(match: re.Match[str]) -> str:
            _o2 = match.group(0)
            if not _o2:
                return _o2
            if mask_length <= 0:
                return _o2
            _o1 = len(_o2)
            _o0 = min(max(keep_first, 0), _o1)
            _o3 = min(max(keep_last, 0), _o1 - _o0)
            _o4 = _o2[_o1 - _o3:] if _o3 else ''
            return _o2[:_o0] + mask_char * mask_length + _o4
        return _repl

@dataclass(frozen=True)
class SecureHashAction:
    type: str = 'secure_hash'
    algorithm: str = 'sha256'
    salt: str | None = None
    length: int = 32
    prefix: str = '[HASH:'
    suffix: str = ']'

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        algo = self.algorithm.lower().strip()
        salt = context.salt if self.salt is None else self.salt
        length = self.length
        prefix = self.prefix
        suffix = self.suffix

        def _repl(match: re.Match[str]) -> str:
            _o2 = match.group(0)
            _o1 = hashlib.new(algo)
            _o1.update(salt.encode('utf-8', errors='replace'))
            _o1.update(b':')
            _o1.update(_o2.encode('utf-8', errors='replace'))
            _o0 = _o1.hexdigest()
            if length is not None:
                _o0 = _o0[:length]
            return f'{prefix}{_o0}{suffix}'
        return _repl

@dataclass(frozen=True)
class DateShiftAction:
    type: str = 'date_shift'
    formats: tuple[str, ...] = ('%Y-%m-%d',)
    max_shift_days: int = 30
    salt: str | None = None
    group: int = 0

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        formats = self.formats
        max_shift = self.max_shift_days
        salt = context.salt if self.salt is None else self.salt
        group = self.group

        def _shift_days(raw: str) -> int:
            if max_shift <= 0:
                return 0
            _o0 = hashlib.sha256()
            _o0.update(salt.encode('utf-8', errors='replace'))
            _o0.update(b':')
            _o0.update(rule_key.encode('utf-8', errors='replace'))
            _o0.update(b':')
            _o0.update(raw.encode('utf-8', errors='replace'))
            _o2 = int(_o0.hexdigest()[:8], 16)
            _o1 = 2 * max_shift + 1
            return _o2 % _o1 - max_shift

        def _try_parse(raw: str) -> tuple[datetime | date, str] | None:
            for fmt in formats:
                try:
                    _o0 = datetime.strptime(raw, fmt)
                    if any((token in fmt for token in ('%H', '%M', '%S', '%f'))):
                        return (_o0, fmt)
                    return (_o0.date(), fmt)
                except ValueError:
                    continue
            return None

        def _repl(match: re.Match[str]) -> str:
            _o2 = match.group(group)
            _o1 = _try_parse(_o2)
            if _o1 is None:
                return match.group(0)
            _o5, _o0 = _o1
            _o4 = _o5 + timedelta(days=_shift_days(_o2))
            _o3 = _o4.strftime(_o0)
            if group == 0:
                return _o3
            return _replace_group_text(match, group=group, replacement=_o3)
        return _repl

@dataclass(frozen=True)
class Bucket:
    min: float
    max: float
    label: str

    def contains(self, value: float) -> bool:
        return self.min <= value <= self.max

@dataclass(frozen=True)
class BucketAction:
    type: str = 'bucket'
    buckets: tuple[Bucket, ...] = ()
    group: int = 0
    fallback_label: str = '[BUCKET]'

    def as_replacement(self, *, context: ActionContext, rule_key: str) -> Replacement:
        buckets = self.buckets
        group = self.group
        fallback = self.fallback_label

        def _bucket_for(v: float) -> str:
            for _o0 in buckets:
                if _o0.contains(v):
                    return _o0.label
            return fallback

        def _repl(match: re.Match[str]) -> str:
            _o1 = match.group(group)
            try:
                _o2 = float(_o1)
            except ValueError:
                return match.group(0)
            _o0 = _bucket_for(_o2)
            if group == 0:
                return _o0
            return _replace_group_text(match, group=group, replacement=_o0)
        return _repl

def parse_action(raw: Any) -> RuleAction:
    if not isinstance(raw, dict):
        raise ValueError('action must be an object')
    _o0 = raw.get('type')
    if not isinstance(_o0, str) or not _o0.strip():
        raise ValueError('action.type must be a non-empty string')
    _o0 = _o0.strip()
    if _o0 == 'replacement':
        _o1a = raw.get('value', '')
        if _o1a is None:
            _o1a = ''
        if not isinstance(_o1a, str):
            raise ValueError('action.value must be a string')
        return ReplacementAction(value=_o1a)
    if _o0 == 'redaction':
        return RedactionAction()
    if _o0 == 'mask':
        _o13 = raw.get('maskChar', '*')
        if not isinstance(_o13, str) or not _o13:
            raise ValueError('action.maskChar must be a non-empty string')
        if len(_o13) != 1:
            raise ValueError('action.maskChar must be a single character')
        _o10 = raw.get('keepLast', 0)
        _of = raw.get('keepFirst', 0)
        if not isinstance(_o10, int) or _o10 < 0:
            raise ValueError('action.keepLast must be an int >= 0')
        if not isinstance(_of, int) or _of < 0:
            raise ValueError('action.keepFirst must be an int >= 0')
        return MaskAction(mask_char=_o13, keep_first=_of, keep_last=_o10)
    if _o0 == 'mask_fixed':
        _o13 = raw.get('maskChar', '*')
        if not isinstance(_o13, str) or not _o13:
            raise ValueError('action.maskChar must be a non-empty string')
        if len(_o13) != 1:
            raise ValueError('action.maskChar must be a single character')
        _o10 = raw.get('keepLast', 0)
        _of = raw.get('keepFirst', 0)
        if not isinstance(_o10, int) or _o10 < 0:
            raise ValueError('action.keepLast must be an int >= 0')
        if not isinstance(_of, int) or _of < 0:
            raise ValueError('action.keepFirst must be an int >= 0')
        _o14 = raw.get('maskLength', 3)
        if not isinstance(_o14, int) or _o14 < 0 or _o14 > 1024:
            raise ValueError('action.maskLength must be an int between 0 and 1024')
        return FixedMaskAction(mask_char=_o13, keep_first=_of, keep_last=_o10, mask_length=_o14)
    if _o0 == 'secure_hash':
        _o1 = raw.get('algorithm', 'sha256')
        if not isinstance(_o1, str) or not _o1.strip():
            raise ValueError('action.algorithm must be a non-empty string')
        _o1 = _o1.strip().lower()
        if _o1 != 'sha256':
            raise ValueError("action.algorithm currently supports only 'sha256'")
        _o18 = raw.get('salt')
        if _o18 is not None and (not isinstance(_o18, str)):
            raise ValueError('action.salt must be a string')
        _o12 = raw.get('length', 32)
        if not isinstance(_o12, int) or _o12 < 8 or _o12 > 64:
            raise ValueError('action.length must be an int between 8 and 64')
        _o16 = raw.get('prefix', '[HASH:')
        _o19 = raw.get('suffix', ']')
        if not isinstance(_o16, str):
            raise ValueError('action.prefix must be a string')
        if not isinstance(_o19, str):
            raise ValueError('action.suffix must be a string')
        return SecureHashAction(algorithm=_o1, salt=_o18, length=_o12, prefix=_o16, suffix=_o19)
    if _o0 == 'date_shift':
        _oc = raw.get('formats')
        if _oc is None:
            _ob: tuple[str, ...] = ('%Y-%m-%d',)
        else:
            if not isinstance(_oc, list) or not _oc:
                raise ValueError('action.formats must be a non-empty array of strings')
            _ob = tuple((str(f) for f in _oc if str(f)))
            if not _ob:
                raise ValueError('action.formats must contain non-empty strings')
        _o15 = raw.get('maxShiftDays', 30)
        if not isinstance(_o15, int) or _o15 < 0 or _o15 > 36525:
            raise ValueError('action.maxShiftDays must be an int between 0 and 36525')
        _o18 = raw.get('salt')
        if _o18 is not None and (not isinstance(_o18, str)):
            raise ValueError('action.salt must be a string')
        _od = raw.get('group', 0)
        if not isinstance(_od, int) or _od < 0:
            raise ValueError('action.group must be an int >= 0')
        return DateShiftAction(formats=_ob, max_shift_days=_o15, salt=_o18, group=_od)
    if _o0 == 'bucket':
        _o6 = raw.get('buckets')
        if not isinstance(_o6, list) or not _o6:
            raise ValueError('action.buckets must be a non-empty array')
        _o5: list[Bucket] = []
        for _oe, _o2 in enumerate(_o6):
            if not isinstance(_o2, dict):
                raise ValueError(f'action.buckets[{_oe}] must be an object')
            if 'min' not in _o2 or 'max' not in _o2:
                raise ValueError(f"action.buckets[{_oe}] must include 'min' and 'max'")
            try:
                _o4 = float(_o2['min'])
                _o3 = float(_o2['max'])
            except (TypeError, ValueError) as _o9:
                raise ValueError(f'action.buckets[{_oe}].min/max must be numeric') from _o9
            if _o4 > _o3:
                raise ValueError(f'action.buckets[{_oe}] has min > max')
            _o11 = _o2.get('label')
            if not isinstance(_o11, str) or not _o11:
                raise ValueError(f'action.buckets[{_oe}].label must be a non-empty string')
            _o5.append(Bucket(min=_o4, max=_o3, label=_o11))
        _o7 = sorted(_o5, key=lambda x: (x.min, x.max))
        for _o17, _o8 in zip(_o7, _o7[1:], strict=False):
            if _o8.min <= _o17.max:
                raise ValueError('action.buckets must not overlap')
        _od = raw.get('group', 0)
        if not isinstance(_od, int) or _od < 0:
            raise ValueError('action.group must be an int >= 0')
        _oa = raw.get('fallbackLabel', '[BUCKET]')
        if not isinstance(_oa, str) or not _oa:
            raise ValueError('action.fallbackLabel must be a non-empty string')
        return BucketAction(buckets=tuple(_o7), group=_od, fallback_label=_oa)
    raise ValueError(f'Unknown action.type: {_o0!r}')

def _replace_group_text(match: re.Match[str], *, group: int, replacement: str) -> str:
    """
    Replace only a capturing group's text while still using `re.sub` (which replaces group 0).

    This is useful for rules that match e.g. "age=23" and want to replace only the numeric value.
    """
    _o6 = match.group(0)
    _o2, _o1 = match.span(group)
    _o3, _o0 = match.span(0)
    _o5 = _o2 - _o3
    _o4 = _o1 - _o3
    if _o5 < 0 or _o4 < _o5 or _o4 > len(_o6):
        return _o6
    return _o6[:_o5] + replacement + _o6[_o4:]

def ensure_action_compatible_with_legacy_replace(action: RuleAction, legacy_replace: str | None) -> RuleAction:
    """
    Legacy rules use `replace` directly; new rules use `action`.

    If both are provided, prefer `action` (explicit) and ignore `replace`.
    This helper exists to keep all legacy parsing decisions in one place.
    """
    return action

def describe_supported_actions() -> list[str]:
    return ['replacement', 'redaction', 'mask', 'secure_hash', 'date_shift', 'bucket']
