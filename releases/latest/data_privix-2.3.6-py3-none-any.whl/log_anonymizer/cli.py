from __future__ import annotations
import argparse
import signal
import sys
from pathlib import Path
from queue import Queue
from typing import NoReturn
from log_anonymizer.builtin_rules import default_rules, merge_rules
from log_anonymizer.config.app_config import load_config, resolve_config_path
from log_anonymizer.config.logging_config import LogFormat, setup_logging
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns, load_patterns
from log_anonymizer.input_limits import resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer import __version__
from log_anonymizer.licensing.features import FeatureFlag
from log_anonymizer.licensing.models import Edition
from log_anonymizer.licensing.service import LicensingService
from log_anonymizer.profiling.runner import run_sensitive_data_profiling
from log_anonymizer.batch import process_batch_with_result
from log_anonymizer.processor import ProcessorConfig, process
from log_anonymizer.progress import ProgressEvent, ProgressStopToken, QueueProgressReporter
from log_anonymizer.progress_cli import start_cli_progress_thread
from log_anonymizer.rules_loader import Rule, load_rules
from log_anonymizer.rule_actions import ReplacementAction

def _build_parser() -> argparse.ArgumentParser:
    _o1 = argparse.ArgumentParser(description='Anonymize sensitive data in files and archives (logs, text files, extracted datasets). Outputs one .tar.gz archive per input (batch mode requires Pro).', epilog='© 2026 MagicByte Consulting. Proprietary software. See LICENSE and EULA.md.')
    _o1.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    _o1.add_argument('--input', '-i', type=Path, required=True, action='append', nargs='+', dest='inputs', help='Input path (directory, single file, or .zip/.tar.gz archive). Repeat to process multiple inputs in one run (Pro).')
    _o1.add_argument('--output', '-o', type=Path, required=True, help='Output directory. Single input writes one .tar.gz here; multiple inputs create a batch subfolder with one output per input.')
    _o1.add_argument('--rules', '-r', type=Path, default=None, help='Optional rules JSON file. If omitted, the built-in rules are used (unless --no-default-rules).')
    _o1.add_argument('--exclude', '-x', type=Path, default=None, help="Optional .exclude file with glob patterns (appended after built-in excludes; use '!pattern' to re-include).")
    _o1.add_argument('--config', type=Path, default=None, help='Optional config file (INI). Default: ./data-privix.ini or ./log-anonymizer.ini or $DATA_PRIVIX_CONFIG (legacy: $DATA_ANONYMIZER_CONFIG, $LOG_ANONYMIZER_CONFIG)')
    _o1.add_argument('--dry-run', action='store_true', help='Validate and report what would be processed without writing output.')
    _o1.add_argument('--anonymize-filenames', action='store_true', help='Anonymize output file and folder names (Pro). Also sanitizes the generated output archive name.')
    _o1.add_argument('-v', '--verbose', action='store_true', help='Enable DEBUG logging.')
    _o1.add_argument('--exclude-case-insensitive', action='store_true', help='Case-insensitive exclude matching.')
    _o1.add_argument('--no-default-rules', action='store_true', help='Do not include built-in baseline rules.')
    _o1.add_argument('--profile-sensitive-data', action='store_true', help='Enable optional sensitive-data profiling (heuristic) and rule suggestions.')
    _o1.add_argument('--profiling-detectors', default='email,ipv4,token,card', help='Comma-separated detectors to run in profiling mode (default: email,ipv4,token,card).')
    _o1.add_argument('--profiling-report', type=Path, default=None, help='Optional path to write profiling report JSON (default: <output>/profiling_report.json).')
    _o1.add_argument('--suggest-rules-output', type=Path, default=None, help='Optional path to write suggested rules JSON (default: <output>/suggested_rules.json).')
    _o1.add_argument('--log-level', default=None, help='Logging level (overrides config; default: INFO).')
    _o1.add_argument('--log-format', choices=[_o0.value for _o0 in LogFormat], default=None, help='Logging format: json or text (overrides config; default: json).')
    _o1.add_argument('--parallel', action='store_true', help='Enable parallel processing of files (default: disabled, sequential).')
    _o1.add_argument('--max-workers', type=int, default=5, help='Max parallel workers when --parallel is enabled (default: 5).')
    _o1.add_argument('--batch-parallel', action='store_true', help='Enable parallel processing across multiple top-level inputs (default: disabled).')
    _o1.add_argument('--batch-max-workers', type=int, default=2, help='Max parallel workers for batch inputs when --batch-parallel is enabled (default: 2).')
    _o2 = _o1.add_mutually_exclusive_group()
    _o2.add_argument('--progress', action='store_true', help='Force progress display (writes to stderr).')
    _o2.add_argument('--no-progress', action='store_true', help='Disable progress display (useful when redirecting stderr).')
    return _o1

def main(argv: list[str] | None=None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    if hasattr(signal, 'SIGPIPE'):
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    if argv and argv[0] == 'license':
        _license_main(argv[1:])
        return
    _o0 = _build_parser().parse_args(argv)
    _run_main(_o0)

def _license_main(argv: list[str]) -> None:
    _o7 = argparse.ArgumentParser(prog=None, description='Manage and validate the local license key (Free vs Pro edition).')
    _o7.add_argument('--path', type=Path, default=None, help='Optional license key file path (default: $DATA_PRIVIX_LICENSE_PATH or ~/.config/data-privix/license.key; legacy: $DATA_ANONYMIZER_LICENSE_PATH, $LOG_ANONYMIZER_LICENSE_PATH).')
    _ob = _o7.add_subparsers(dest='cmd')
    _ob.add_parser('status', help='Show current edition, enabled features, and validation details.')
    _o6 = _ob.add_parser('validate', help='Validate the current license key and exit non-zero if invalid.')
    _o6.add_argument('--quiet', action='store_true', help='Only set exit code (no output).')
    _o5 = _ob.add_parser('install', help='Install a license key into the local license file.')
    _o2 = _o5.add_mutually_exclusive_group(required=True)
    _o2.add_argument('--key', type=str, help='License key string (LA1.<payload>.<sig>).')
    _o2.add_argument('--file', type=Path, help='File containing the license key string.')
    _ob.add_parser('clear', help='Remove the local license key file.')
    _o4 = _o7.parse_args(argv if argv else ['status'])
    _o9 = LicensingService.default()
    _oa = _o9.storage if _o4.path is None else type(_o9.storage)(Path(_o4.path))
    _o9 = LicensingService(storage=_oa)
    if _o4.cmd == 'clear':
        _oa.clear()
        print(f'cleared: {_oa.path}')
        return
    if _o4.cmd == 'install':
        _o3 = _o4.key
        if _o3 is None:
            _o3 = Path(_o4.file).read_text(encoding='utf-8')
        _oa.save(_o3)
        _o8 = _o9.validate()
        if _o8.valid:
            print(f'installed: {_oa.path}')
        else:
            print(f'installed: {_oa.path} (but license is invalid: {_o8.reason.value})')
            if _o8.message:
                print(_o8.message)
        return
    _o8 = _o9.validate()
    _o0 = _o9.edition().value
    _o1 = sorted((f.value for f in _o9.enabled_features()))
    if _o4.cmd == 'validate':
        if not bool(_o4.quiet):
            print(f'edition={_o0}')
            print(f'valid={_o8.valid}')
            print(f'reason={_o8.reason.value}')
            if _o8.message:
                print(f'message={_o8.message}')
            print(f'path={_oa.path}')
        raise SystemExit(0 if _o8.valid else 1)
    print(f'edition={_o0}')
    print(f'valid={_o8.valid}')
    print(f'reason={_o8.reason.value}')
    if _o8.license_info is not None:
        print(f'customer_name={_o8.license_info.customer_name}')
        print(f'customer_id={_o8.license_info.customer_id}')
        print(f'expiry_date={_o8.license_info.expiry_date.isoformat()}')
        if _o8.license_info.max_version:
            print(f'max_version={_o8.license_info.max_version}')
    if _o8.message:
        print(f'message={_o8.message}')
    print(f'path={_oa.path}')
    print('features=' + (','.join(_o1) if _o1 else '<none>'))

def _run_main(args: argparse.Namespace) -> None:
    _o1d = LicensingService.default()
    _ob = _o1d.enabled_features()
    _o7 = _o1d.edition()
    _o4 = resolve_config_path(args.config)
    _o3 = load_config(_o4)
    _oc = args.log_format or _o3.logging.fmt or LogFormat.JSON.value
    _o14 = LogFormat(_oc)
    if args.verbose:
        _o13 = 'DEBUG'
    else:
        _o13 = args.log_level or _o3.logging.level or 'INFO'
    setup_logging(level=_o13, log_format=_o14)
    _o19 = list(args.inputs or [])
    _of: list[Path] = [_o17 for _od in _o19 for _o17 in _od or []]
    _o16 = args.output
    _o1c = args.rules
    _oa = args.exclude
    if args.parallel and FeatureFlag.parallel_processing not in _ob:
        _die('Parallel processing requires a Pro license.')
    if args.profile_sensitive_data and FeatureFlag.profiling not in _ob:
        _die('Sensitive-data profiling requires a Pro license.')
    if args.anonymize_filenames and FeatureFlag.anonymize_filenames not in _ob:
        _die('Filename anonymization requires a Pro license.')
    if not _of:
        _die('At least one --input is required.')
    for _o17 in _of:
        if not _o17.exists():
            _die(f'Input path does not exist: {_o17}')
        if _o17.is_file() and _o17.suffix.lower() == '.pdf' and (_o7 != Edition.pro):
            _die('PDF redaction requires a Pro license.')
    if _o1c is not None and (not _o1c.exists()):
        _die(f'Rules file does not exist: {_o1c}')
    if _oa is not None and (not _oa.exists()):
        _die(f'Exclude file does not exist: {_oa}')
    if args.no_default_rules and _o1c is None:
        _die('--no-default-rules requires providing --rules (otherwise there are no rules to apply).')
    if args.max_workers is not None and args.max_workers <= 0:
        _die(f'--max-workers must be >= 1 (got {args.max_workers})')
    if args.batch_max_workers is not None and args.batch_max_workers <= 0:
        _die(f'--batch-max-workers must be >= 1 (got {args.batch_max_workers})')
    if _o1c is not None and FeatureFlag.advanced_rules not in _ob:
        _enforce_free_rules(_o1c)
    _of = [_o17.resolve() for _o17 in _of]
    _o16 = _o16.resolve()
    _o1c = _o1c.resolve() if _o1c is not None else None
    _oa = _oa.resolve() if _oa is not None else None
    try:
        if len(_of) > 1 and _o7 != Edition.pro:
            _die('Batch processing (multiple inputs) requires a Pro license.')
        if args.dry_run:
            _o6 = tuple((_o17.strip() for _o17 in str(args.profiling_detectors or '').split(',') if _o17.strip())) or ('email', 'ipv4', 'token', 'card')
            if args.profile_sensitive_data:
                if len(_of) > 1:
                    from datetime import datetime
                    import json as _json
                    import re as _re
                    safe_re = _re.compile('[^A-Za-z0-9._-]+')

                    def _safe(name: str) -> str:
                        _o0 = safe_re.sub('_', (name or 'input').strip()).strip(' .')
                        return _o0 or 'input'
                    _o2 = (_o16 / ('batch-' + datetime.now().strftime('%Y%m%d-%H%M%S'))).resolve()
                    _o2.mkdir(parents=True, exist_ok=True)
                    _o12: list[dict[str, object]] = []
                    _o0 = False
                    for _oe, _o17 in enumerate(_of, start=1):
                        _o11 = (_o2 / f'{_oe:03d}-{_safe(_o17.name)}').resolve()
                        _o11.mkdir(parents=True, exist_ok=True)
                        try:
                            _o1b = run_sensitive_data_profiling(input_path=_o17, output_dir=_o11, exclude_path=_oa, exclude_case_insensitive=bool(args.exclude_case_insensitive), detectors=_o6, profiling_report_path=_o11 / 'profiling_report.json', suggest_rules_output_path=_o11 / 'suggested_rules.json')
                            _o12.append({'index': _oe, 'input_path': str(_o17), 'status': 'success', 'output_dir': str(_o11), 'profiling_report_path': str(_o1b.profiling_report_path), 'suggested_rules_path': str(_o1b.suggested_rules_path), 'total_files': int(_o1b.total_files), 'excluded_files': int(_o1b.excluded_files), 'profiled_files': int(_o1b.profiled_files)})
                        except Exception as _o9:
                            _o0 = True
                            _o12.append({'index': _oe, 'input_path': str(_o17), 'status': 'failed', 'output_dir': str(_o11), 'error': f'{type(_o9).__name__}: {_o9}'})
                    _o1f = (_o2 / 'batch_summary.json').resolve()
                    _o1f.write_text(_json.dumps({'batch_dir': str(_o2), 'items': _o12}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                    print('DRY RUN (profiling only, batch)')
                    print(f'- Batch directory: {_o2}')
                    print(f'- Summary JSON: {_o1f}')
                    if _o0:
                        raise SystemExit(1)
                    return
                _o1b = run_sensitive_data_profiling(input_path=_of[0], output_dir=_o16, exclude_path=_oa, exclude_case_insensitive=bool(args.exclude_case_insensitive), detectors=_o6, profiling_report_path=args.profiling_report, suggest_rules_output_path=args.suggest_rules_output)
                print('DRY RUN (profiling only)')
                print(f'- Input: {_of[0]}')
                print(f'- Output dir: {_o16}')
                print(f'- Profiling report: {_o1b.profiling_report_path}')
                print(f'- Suggested rules: {_o1b.suggested_rules_path}')
                print(f'- Files: total={_o1b.total_files}, excluded={_o1b.excluded_files}, profiled={_o1b.profiled_files}')
                return
            if len(_of) == 1:
                _dry_run(input_path=_of[0], output_dir=_o16, rules_path=_o1c, exclude_path=_oa, exclude_case_insensitive=bool(args.exclude_case_insensitive), include_builtin=not bool(args.no_default_rules), allow_advanced_rules=FeatureFlag.advanced_rules in _ob, anonymize_filenames=bool(args.anonymize_filenames), edition=_o7)
            else:
                for _oe, _o17 in enumerate(_of, start=1):
                    print(f'=== DRY RUN ({_oe}/{len(_of)}) ===')
                    _dry_run(input_path=_o17, output_dir=_o16, rules_path=_o1c, exclude_path=_oa, exclude_case_insensitive=bool(args.exclude_case_insensitive), include_builtin=not bool(args.no_default_rules), allow_advanced_rules=FeatureFlag.advanced_rules in _ob, anonymize_filenames=bool(args.anonymize_filenames), edition=_o7)
            return
        _o6 = tuple((_o17.strip() for _o17 in str(args.profiling_detectors or '').split(',') if _o17.strip())) or ('email', 'ipv4', 'token', 'card')
        _o3 = ProcessorConfig(parallel_enabled=bool(args.parallel), max_workers=int(args.max_workers or 5), exclude_case_insensitive=bool(args.exclude_case_insensitive), include_builtin_rules=not bool(args.no_default_rules), anonymize_filenames=bool(args.anonymize_filenames), profile_sensitive_data=bool(args.profile_sensitive_data), profiling_detectors=_o6, profiling_report_path=args.profiling_report.resolve() if args.profiling_report is not None else None, suggest_rules_output_path=args.suggest_rules_output.resolve() if args.suggest_rules_output is not None else None, rollback_on_cancel=FeatureFlag.partial_cancel_preservation not in _ob, anonymization_salt=_o3.anonymization.salt, edition=_o7)
        _o8 = bool(args.progress) or (not bool(args.no_progress) and sys.stderr.isatty())
        _o18: Queue[ProgressEvent] | None = None
        _o1e: ProgressStopToken | None = None
        _o20 = None
        _o1a = None
        if _o8:
            _o18 = Queue(maxsize=5000)
            _o1e = ProgressStopToken()
            _o1a = QueueProgressReporter(_o18)
            _o20 = start_cli_progress_thread(_o18, _o1e)
        try:
            if len(_of) == 1:
                _o15 = process(input_path=_of[0], rules_path=_o1c, output_dir=_o16, exclude_path=_oa, config=_o3, progress=_o1a)
                print(str(_o15))
                return
            _o1 = process_batch_with_result(inputs=_of, rules_path=_o1c, output_dir=_o16, exclude_path=_oa, config=_o3, batch_parallel_enabled=bool(args.batch_parallel), batch_max_workers=int(args.batch_max_workers or 2), progress=_o1a)
        finally:
            if _o1e is not None:
                _o1e.stop()
            if _o20 is not None:
                _o20.join(timeout=2.0)
        _o0 = False
        print('BATCH RESULT')
        print(f'- Batch directory: {_o1.batch_dir}')
        for _o10 in _o1.items:
            if _o10.status == 'success':
                print(f'- OK: {_o10.input_path} -> {_o10.output_archive}')
            else:
                _o0 = _o0 or _o10.status == 'failed'
                _o5 = f' ({_o10.error})' if _o10.error else ''
                print(f'- {_o10.status.upper()}: {_o10.input_path}{_o5}')
                if _o10.output_archive:
                    print(f'  - Output: {_o10.output_archive}')
        print(f'- Summary JSON: {_o1.summary_path}')
        if _o0:
            raise SystemExit(1)
    except KeyboardInterrupt:
        raise SystemExit(130) from None
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            raise SystemExit(141) from None
    except Exception as _o9:
        print(f'ERROR: {_o9}', file=sys.stderr)
        raise SystemExit(1) from _o9

def _dry_run(*, input_path: Path, output_dir: Path, rules_path: Path | None, exclude_path: Path | None, exclude_case_insensitive: bool, include_builtin: bool, allow_advanced_rules: bool, anonymize_filenames: bool, edition: Edition) -> None:
    """
    Dry-run mode: validate inputs, load rules, apply excludes, and report what would be done.
    """
    if output_dir.exists() and (not output_dir.is_dir()):
        _die(f'--output must be a directory: {output_dir}')
    _oa = load_rules(rules_path, strict=True) if rules_path is not None else []
    if rules_path is not None and (not allow_advanced_rules):
        _enforce_rules_are_replacement_only(_oa)
    _o9 = merge_rules(builtin=default_rules(), user=_oa) if include_builtin else _oa
    if not _o9:
        _die('No valid rules loaded; nothing to do.')
    _o5 = resolve_free_input_limits(edition=edition)
    with handle_input(input_path, limits=_o5) as _o8:
        _o0 = _o8.working_dir
        _o3 = _o8.files
        _o7 = list(default_patterns())
        if exclude_path is not None:
            _o7.extend(load_patterns(exclude_path))
        _o1 = ExcludeFilter.from_patterns(_o7, base_dir=_o0, case_insensitive=exclude_case_insensitive) if _o7 else None
        _o4 = [_o2 for _o2 in _o3 if not (_o1 and _o1.should_exclude(_o2))]
    from log_anonymizer.processor import default_output_archive_path
    _ob = default_output_archive_path(output_dir, input_path, anonymize_filenames=bool(anonymize_filenames))
    print('DRY RUN')
    print(f'- Input: {input_path}')
    print(f'- Output dir: {output_dir}')
    print(f'- Output archive: {_ob}')
    print(f"- Rules: {len(_o9)} (user={len(_oa)}, builtin={('on' if include_builtin else 'off')})")
    print(f'- Files: total={len(_o3)}, excluded={len(_o3) - len(_o4)}, to_process={len(_o4)}')
    for _o6 in _o4[:20]:
        print(f'  - {_o6}')
    if len(_o4) > 20:
        print(f'  ... ({len(_o4) - 20} more)')

def _die(message: str) -> 'NoReturn':
    print(f'ERROR: {message}', file=sys.stderr)
    raise SystemExit(2)

def _enforce_free_rules(rules_path: Path) -> None:
    """
    Free edition supports legacy rules only: fixed string replacements.
    """
    try:
        _o1 = load_rules(rules_path, strict=True)
    except Exception as _o0:
        _die(str(_o0))
    _enforce_rules_are_replacement_only(_o1)

def _enforce_rules_are_replacement_only(user_rules: list[Rule]) -> None:
    for _o0 in user_rules:
        if not isinstance(getattr(_o0, 'action', None), ReplacementAction):
            _die('Advanced rule actions require a Pro license (enable `advanced_rules`).')
