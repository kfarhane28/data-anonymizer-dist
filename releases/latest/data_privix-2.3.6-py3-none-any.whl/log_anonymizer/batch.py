from __future__ import annotations
import json
import logging
import re
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Literal
from log_anonymizer.processor import ProcessorConfig, ProcessorResult, process_with_result
logger = logging.getLogger(__name__)
try:
    from log_anonymizer.progress import ProgressEvent, ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:
    ProgressReporter = object
    ProgressKind = None
    ProgressStage = None
    ProgressEvent = None

    def now_event(**kwargs):
        raise RuntimeError('progress module unavailable')
BatchItemStatus = Literal['success', 'failed', 'cancelled', 'skipped']

@dataclass(frozen=True)
class BatchItemResult:
    index: int
    input_path: Path
    status: BatchItemStatus
    output_dir: Path
    output_archive: Path | None = None
    error: str | None = None
    result: ProcessorResult | None = None

@dataclass(frozen=True)
class BatchResult:
    batch_dir: Path
    items: list[BatchItemResult]
    summary_path: Path

    @property
    def total(self) -> int:
        return len(self.items)

    @property
    def succeeded(self) -> int:
        return sum((1 for it in self.items if it.status == 'success'))

    @property
    def failed(self) -> int:
        return sum((1 for it in self.items if it.status == 'failed'))

    @property
    def cancelled(self) -> int:
        return sum((1 for it in self.items if it.status == 'cancelled'))

    @property
    def skipped(self) -> int:
        return sum((1 for it in self.items if it.status == 'skipped'))
_SAFE_COMPONENT_RE = re.compile('[^A-Za-z0-9._-]+')

def _safe_output_component(name: str) -> str:
    _o0 = (name or '').strip()
    if not _o0:
        return 'input'
    _o0 = _o0.replace('\n', '').replace('\r', '')
    _o1 = _SAFE_COMPONENT_RE.sub('_', _o0).strip(' .')
    return _o1 or 'input'

def _default_batch_dir_name() -> str:
    return 'batch-' + datetime.now().strftime('%Y%m%d-%H%M%S')

def _derive_per_input_config(cfg: ProcessorConfig, *, output_dir: Path) -> ProcessorConfig:
    _o0 = None
    if cfg.profiling_report_path is not None:
        _o0 = (output_dir / cfg.profiling_report_path.name).resolve()
    _o1 = None
    if cfg.suggest_rules_output_path is not None:
        _o1 = (output_dir / cfg.suggest_rules_output_path.name).resolve()
    return ProcessorConfig(parallel_enabled=cfg.parallel_enabled, max_workers=cfg.max_workers, exclude_case_insensitive=cfg.exclude_case_insensitive, include_builtin_rules=cfg.include_builtin_rules, anonymize_filenames=cfg.anonymize_filenames, profile_sensitive_data=cfg.profile_sensitive_data, profiling_detectors=cfg.profiling_detectors, profiling_report_path=_o0, suggest_rules_output_path=_o1, cancellation_token=cfg.cancellation_token, rollback_on_cancel=cfg.rollback_on_cancel, anonymization_salt=cfg.anonymization_salt, edition=cfg.edition, input_limits=cfg.input_limits)

def process_batch_with_result(*, inputs: list[Path], rules_path: Path | None, output_dir: Path, exclude_path: Path | None=None, config: ProcessorConfig | None=None, batch_parallel_enabled: bool=False, batch_max_workers: int=2, batch_dir_name: str | None=None, include_item_progress: bool=False, progress: ProgressReporter | None=None) -> BatchResult:
    """
    Process multiple top-level inputs in a single batch job.

    - Each input is processed independently (errors are captured per input).
    - When batch_parallel_enabled=True, multiple inputs run concurrently.
    - Outputs are isolated per input under a batch directory to avoid collisions.
    """
    if not inputs:
        raise ValueError('Batch inputs list is empty.')
    if batch_max_workers <= 0:
        raise ValueError(f'batch_max_workers must be >= 1 (got {batch_max_workers})')
    cfg = config or ProcessorConfig()
    _oa = output_dir.expanduser().resolve()
    _oa.mkdir(parents=True, exist_ok=True)
    batch_dir = (_oa / (batch_dir_name or _default_batch_dir_name())).resolve()
    batch_dir.mkdir(parents=True, exist_ok=True)
    _o12 = len(inputs)
    _o2 = 0
    _of: list[BatchItemResult | None] = [None for _o0 in inputs]
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_START, stage=ProgressStage.PROCESSING, current=0, total=_o12, message='batch_start'))

    class _TaggedProgress(ProgressReporter):

        def __init__(self, inner: ProgressReporter, *, input_name: str, prefix: str) -> None:
            self._inner = inner
            self._input_name = input_name
            self._prefix = prefix

        def emit(self, event: ProgressEvent) -> None:
            _o0 = f'input={self._input_name}'
            if event.message:
                _o0 += f' {event.message}'
            _o1 = f'{self._prefix}{event.path}' if event.path else None
            self._inner.emit(type(event)(kind=event.kind, stage=event.stage, ts_monotonic=event.ts_monotonic, current=event.current, total=event.total, path=_o1, bytes_done=event.bytes_done, bytes_total=event.bytes_total, ok=event.ok, message=_o0))

    def _run_one(idx: int, input_path: Path) -> BatchItemResult:
        _o4 = _safe_output_component(input_path.name)
        _o1 = (batch_dir / f'{idx:03d}-{_o4}').resolve()
        _o1.mkdir(parents=True, exist_ok=True)
        _o0 = _derive_per_input_config(cfg, output_dir=_o1)
        _o2 = None
        if include_item_progress and progress is not None:
            _o2 = _TaggedProgress(progress, input_name=input_path.name, prefix=f'{idx:03d}-{_o4}/')
        _o3 = process_with_result(input_path=input_path, rules_path=rules_path, output_dir=_o1, exclude_path=exclude_path, config=_o0, progress=_o2)
        if _o3.cancelled:
            _o5: BatchItemStatus = 'cancelled'
        else:
            _o5 = 'success'
        return BatchItemResult(index=idx, input_path=input_path, status=_o5, output_dir=_o1, output_archive=_o3.output_zip, result=_o3)
    if not batch_parallel_enabled or batch_max_workers == 1 or _o12 <= 1:
        for _o7, _ob in enumerate(inputs, start=1):
            if cfg.cancellation_token is not None and cfg.cancellation_token.is_cancelled():
                _of[_o7 - 1] = BatchItemResult(index=_o7, input_path=_ob, status='skipped', output_dir=batch_dir, error='cancelled_before_start')
                continue
            logger.info('batch_item_start', extra={'input': str(_ob), 'idx': _o7, 'total': _o12})
            try:
                _od = _run_one(_o7, _ob)
                _of[_o7 - 1] = _od
                logger.info('batch_item_done', extra={'input': str(_ob), 'idx': _o7, 'total': _o12, 'status': _od.status, 'output_archive': str(_od.output_archive) if _od.output_archive else None})
            except Exception as _o5:
                logger.exception('batch_item_failed', extra={'input': str(_ob), 'idx': _o7, 'total': _o12})
                _of[_o7 - 1] = BatchItemResult(index=_o7, input_path=_ob, status='failed', output_dir=(batch_dir / f'{_o7:03d}-{_safe_output_component(_ob.name)}').resolve(), error=f'{type(_o5).__name__}: {_o5}')
            _o2 += 1
            if progress is not None:
                progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.PROCESSING, current=_o2, total=_o12, message=f'batch_input={_ob.name}'))
    else:
        _oc: dict[Future[BatchItemResult], tuple[int, Path]] = {}
        with ThreadPoolExecutor(max_workers=int(batch_max_workers)) as _o4:
            for _o7, _ob in enumerate(inputs, start=1):
                if cfg.cancellation_token is not None and cfg.cancellation_token.is_cancelled():
                    _of[_o7 - 1] = BatchItemResult(index=_o7, input_path=_ob, status='skipped', output_dir=batch_dir, error='cancelled_before_start')
                    continue
                logger.info('batch_item_submit', extra={'input': str(_ob), 'idx': _o7, 'total': _o12})
                _o6 = _o4.submit(_run_one, _o7, _ob)
                _oc[_o6] = (_o7, _ob)
            while _oc:
                _o3, _o1 = wait(_oc.keys(), return_when=FIRST_COMPLETED)
                for _o6 in _o3:
                    _o7, _ob = _oc.pop(_o6)
                    try:
                        _od = _o6.result()
                        _of[_o7 - 1] = _od
                        logger.info('batch_item_done', extra={'input': str(_ob), 'idx': _o7, 'total': _o12, 'status': _od.status, 'output_archive': str(_od.output_archive) if _od.output_archive else None})
                    except Exception as _o5:
                        logger.exception('batch_item_failed', extra={'input': str(_ob), 'idx': _o7, 'total': _o12})
                        _of[_o7 - 1] = BatchItemResult(index=_o7, input_path=_ob, status='failed', output_dir=(batch_dir / f'{_o7:03d}-{_safe_output_component(_ob.name)}').resolve(), error=f'{type(_o5).__name__}: {_o5}')
                    _o2 += 1
                    if progress is not None:
                        progress.emit(now_event(kind=ProgressKind.STAGE_PROGRESS, stage=ProgressStage.PROCESSING, current=_o2, total=_o12, message=f'batch_input={_ob.name}'))
    _o9: list[BatchItemResult] = []
    for _o7, (_ob, _oe) in enumerate(zip(inputs, _of, strict=True), start=1):
        if _oe is None:
            _o9.append(BatchItemResult(index=_o7, input_path=_ob, status='failed', output_dir=batch_dir, error='missing_result'))
        else:
            _o9.append(_oe)
    _o11 = (batch_dir / 'batch_summary.json').resolve()

    def _result_to_jsonable(r: ProcessorResult) -> dict[str, object]:
        return {'output_zip': str(r.output_zip), 'total_files': int(r.total_files), 'processed_files': int(r.processed_files), 'failed_files': int(r.failed_files), 'excluded_files': int(r.excluded_files), 'profiling_report_path': str(r.profiling_report_path) if r.profiling_report_path else None, 'suggested_rules_path': str(r.suggested_rules_path) if r.suggested_rules_path else None, 'cancelled': bool(r.cancelled), 'rolled_back': bool(r.rolled_back)}
    _o10 = {'batch_dir': str(batch_dir), 'items': [{'index': int(_o8.index), 'input_path': str(_o8.input_path), 'input_name': _o8.input_path.name, 'status': _o8.status, 'output_dir': str(_o8.output_dir), 'output_archive': str(_o8.output_archive) if _o8.output_archive else None, 'error': _o8.error, 'result': _result_to_jsonable(_o8.result) if _o8.result is not None else None} for _o8 in _o9], 'summary': {'total': len(_o9), 'succeeded': sum((1 for _o8 in _o9 if _o8.status == 'success')), 'failed': sum((1 for _o8 in _o9 if _o8.status == 'failed')), 'cancelled': sum((1 for _o8 in _o9 if _o8.status == 'cancelled')), 'skipped': sum((1 for _o8 in _o9 if _o8.status == 'skipped'))}}
    _o11.write_text(json.dumps(_o10, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if progress is not None:
        progress.emit(now_event(kind=ProgressKind.STAGE_END, stage=ProgressStage.PROCESSING, current=len(_o9), total=_o12, message='batch_done'))
    logger.info('batch_done', extra={'batch_dir': str(batch_dir), 'summary_path': str(_o11), 'total': len(_o9), 'succeeded': sum((1 for _o8 in _o9 if _o8.status == 'success')), 'failed': sum((1 for _o8 in _o9 if _o8.status == 'failed')), 'cancelled': sum((1 for _o8 in _o9 if _o8.status == 'cancelled')), 'skipped': sum((1 for _o8 in _o9 if _o8.status == 'skipped'))})
    return BatchResult(batch_dir=batch_dir, items=_o9, summary_path=_o11)
