from __future__ import annotations

import gzip
import logging
import shutil
import tempfile
import tarfile
import time
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from log_anonymizer.input_limits import (
    ArchiveExtractionLimiter,
    FreeEditionInputLimits,
    validate_archive_compressed_size,
    validate_archive_file_count,
    validate_single_file_size,
)

logger = logging.getLogger(__name__)

try:
    from log_anonymizer.progress import ProgressKind, ProgressReporter, ProgressStage, now_event
except Exception:  # pragma: no cover
    ProgressReporter = object  # type: ignore[assignment]
    ProgressKind = None  # type: ignore[assignment]
    ProgressStage = None  # type: ignore[assignment]

    def now_event(**kwargs):  # type: ignore[no-redef]
        raise RuntimeError("progress module unavailable")


@dataclass(frozen=True)
class InputHandlingResult:
    """
    Result of preparing an input for processing.

    Attributes:
        working_dir: Directory that contains the returned files. For a directory input,
            this is the input directory. For a single-file input, this is the file's
            parent directory. For a zip input, this is a temporary extraction directory.
        files: Absolute file paths to process.
    """

    working_dir: Path
    files: list[Path]


@contextmanager
def handle_input(
    input_path: Path,
    *,
    progress: ProgressReporter | None = None,
    limits: FreeEditionInputLimits | None = None,
) -> Iterator[InputHandlingResult]:
    """
    Prepare an input path (directory, file, or archive) for processing.

    Responsibilities:
    - Detect input type automatically.
    - If directory: recursively list all files.
    - If file: treat as a single file.
    - If archive (.zip / .tar.gz / .tgz): safely extract to a temporary directory and recursively list extracted files.

    Returns:
        A context manager yielding an InputHandlingResult. Temporary directories created
        for archive inputs are cleaned up automatically on exit.

    Notes:
        For very large archives, a streaming approach (reading zip members without full
        extraction) can be more efficient, but most anonymization pipelines expect
        file paths. This implementation extracts in a safe, streaming manner (member
        by member) to avoid loading whole files into memory.
    """
    resolved = input_path.expanduser().resolve()
    if not resolved.exists():
        raise FileNotFoundError(resolved)

    tmp_dir: Path | None = None
    try:
        if resolved.is_dir():
            logger.info("input_detected", extra={"type": "directory", "path": str(resolved)})
            files = list(_iter_files(resolved, progress=progress))
            logger.info("input_files_listed", extra={"count": len(files)})
            yield InputHandlingResult(working_dir=resolved, files=files)
            return

        if resolved.is_file() and resolved.suffix.lower() == ".zip":
            logger.info("input_detected", extra={"type": "zip", "path": str(resolved)})
            if limits is not None:
                validate_archive_compressed_size(resolved.stat().st_size, limits=limits)
            tmp_dir = Path(tempfile.mkdtemp(prefix="log-anonymizer-input-")).resolve()
            logger.debug("zip_extract_start", extra={"zip": str(resolved), "tmp_dir": str(tmp_dir)})
            limiter = ArchiveExtractionLimiter(limits) if limits is not None else None
            _extract_zip_streaming(resolved, tmp_dir, progress=progress, limiter=limiter, limits=limits)
            files = list(_iter_files(tmp_dir, progress=progress))
            logger.info("input_files_listed", extra={"count": len(files), "working_dir": str(tmp_dir)})
            yield InputHandlingResult(working_dir=tmp_dir, files=files)
            return

        if resolved.is_file() and _is_tar_gz(resolved):
            logger.info("input_detected", extra={"type": "tar.gz", "path": str(resolved)})
            if limits is not None:
                validate_archive_compressed_size(resolved.stat().st_size, limits=limits)
            tmp_dir = Path(tempfile.mkdtemp(prefix="log-anonymizer-input-")).resolve()
            logger.debug(
                "tar_extract_start",
                extra={"tar": str(resolved), "tmp_dir": str(tmp_dir)},
            )
            limiter = ArchiveExtractionLimiter(limits) if limits is not None else None
            _extract_tar_gz_streaming(resolved, tmp_dir, progress=progress, limiter=limiter)
            files = list(_iter_files(tmp_dir, progress=progress))
            logger.info("input_files_listed", extra={"count": len(files), "working_dir": str(tmp_dir)})
            yield InputHandlingResult(working_dir=tmp_dir, files=files)
            return

        if resolved.is_file():
            logger.info("input_detected", extra={"type": "file", "path": str(resolved)})
            if limits is not None:
                validate_single_file_size(resolved.stat().st_size, limits=limits)
            if progress is not None:
                progress.emit(
                    now_event(
                        kind=ProgressKind.STAGE_PROGRESS,
                        stage=ProgressStage.DISCOVERY,
                        current=1,
                        total=1,
                        message="single_file",
                    )
                )
            yield InputHandlingResult(working_dir=resolved.parent, files=[resolved])
            return

        raise ValueError(f"Unsupported input path: {resolved}")
    finally:
        if tmp_dir is not None:
            logger.debug("cleanup_tmp_dir", extra={"tmp_dir": str(tmp_dir)})
            shutil.rmtree(tmp_dir, ignore_errors=True)


def _iter_files(root_dir: Path, *, progress: ProgressReporter | None = None) -> Iterator[Path]:
    """
    Recursively yield file paths under root_dir.

    Uses an explicit stack to avoid recursion depth issues on deeply nested trees.
    Skips symlinks to avoid potential cycles.
    """
    stack: list[Path] = [root_dir]
    discovered = 0
    last_emit = 0.0
    while stack:
        current = stack.pop()
        try:
            for entry in current.iterdir():
                # Avoid following symlinks in support bundles.
                if entry.is_symlink():
                    logger.debug("skip_symlink", extra={"path": str(entry)})
                    continue
                if entry.is_dir():
                    stack.append(entry)
                elif entry.is_file():
                    logger.debug("discovered_file", extra={"path": str(entry)})
                    discovered += 1
                    if progress is not None:
                        # Throttle: at most ~5 updates/s and avoid per-file overhead.
                        now = time.monotonic()
                        if discovered == 1 or (discovered % 200 == 0) or (now - last_emit) >= 0.2:
                            last_emit = now
                            progress.emit(
                                now_event(
                                    kind=ProgressKind.STAGE_PROGRESS,
                                    stage=ProgressStage.DISCOVERY,
                                    current=discovered,
                                    total=None,
                                    message="listing_files",
                                )
                            )
                    yield entry
        except OSError as exc:
            logger.debug("skip_unreadable_dir", extra={"path": str(current), "reason": str(exc)})


def _extract_zip_streaming(
    zip_path: Path,
    dest_dir: Path,
    *,
    progress: ProgressReporter | None = None,
    limiter: ArchiveExtractionLimiter | None = None,
    limits: FreeEditionInputLimits | None = None,
) -> None:
    """
    Extract `zip_path` into `dest_dir` in a safe, streaming way.

    - Defends against Zip Slip (path traversal)
    - Streams each member to disk (does not load whole members into memory)
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_root = dest_dir.resolve()

    with zipfile.ZipFile(zip_path, "r") as zf:
        members = [info for info in zf.infolist() if not info.is_dir()]
        total = len(members)
        if limits is not None:
            validate_archive_file_count(total, limits=limits)
        extracted = 0
        last_emit = 0.0
        for info in members:
            # Skip directories; they will be created as needed.
            target = (dest_dir / info.filename).resolve()
            if dest_root not in target.parents and target != dest_root:
                raise ValueError(f"Unsafe zip member path: {info.filename}")

            target.parent.mkdir(parents=True, exist_ok=True)
            if limiter is not None:
                limiter.on_new_file()
            with zf.open(info, "r") as src:
                with target.open("wb") as dst:
                    while True:
                        chunk = src.read(1024 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
                        if limiter is not None:
                            limiter.on_bytes(len(chunk))
            extracted += 1
            if progress is not None:
                now = time.monotonic()
                if extracted == 1 or extracted == total or (now - last_emit) >= 0.2:
                    last_emit = now
                    progress.emit(
                        now_event(
                            kind=ProgressKind.STAGE_PROGRESS,
                            stage=ProgressStage.DISCOVERY,
                            current=extracted,
                            total=total,
                            message="extracting_zip",
                        )
                    )


def _is_tar_gz(path: Path) -> bool:
    name = path.name.lower()
    return name.endswith(".tar.gz") or name.endswith(".tgz")


def _extract_tar_gz_streaming(
    tar_gz_path: Path,
    dest_dir: Path,
    *,
    progress: ProgressReporter | None = None,
    limiter: ArchiveExtractionLimiter | None = None,
) -> None:
    """
    Extract `tar_gz_path` into `dest_dir` in a safe, streaming way.

    - Defends against Tar Slip (path traversal)
    - Only extracts regular files (skips symlinks, hardlinks, devices, etc.)
    - Streams each member to disk (does not load whole members into memory)
    """
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_root = dest_dir.resolve()

    try:
        with tarfile.open(
            tar_gz_path,
            mode="r:gz",
            ignore_zeros=True,
            errorlevel=0,
        ) as tf:
            _extract_tar_streaming_from_tarfile(
                tf,
                tar_gz_path=tar_gz_path,
                dest_dir=dest_dir,
                dest_root=dest_root,
                progress=progress,
                limiter=limiter,
            )
            return
    except (EOFError, gzip.BadGzipFile, tarfile.ReadError) as exc:
        raise ValueError(f"Invalid .tar.gz archive (corrupted or truncated): {tar_gz_path}") from exc


def _extract_tar_streaming_from_tarfile(
    tf: tarfile.TarFile,
    *,
    tar_gz_path: Path,
    dest_dir: Path,
    dest_root: Path,
    progress: ProgressReporter | None = None,
    limiter: ArchiveExtractionLimiter | None = None,
) -> bool:
    extracted_any = False
    extracted_files = 0
    last_emit = 0.0

    while True:
        try:
            member = tf.next()
        except EOFError as exc:
            raise EOFError(f"Unexpected EOF while reading tar members: {tar_gz_path}") from exc
        except tarfile.ReadError as exc:
            raise tarfile.ReadError(f"Error while reading tar members: {tar_gz_path}") from exc

        if member is None:
            break
        if member.isdir():
            continue
        if not member.isreg():
            logger.debug(
                "skip_non_regular_tar_member",
                extra={"member": member.name, "type": member.type},
            )
            continue

        name = member.name
        # Basic sanity: reject absolute paths and traversal.
        if name.startswith(("/", "\\")) or ".." in Path(name).parts:
            raise ValueError(f"Unsafe tar member path: {name}")

        target = (dest_dir / name).resolve()
        if dest_root not in target.parents and target != dest_root:
            raise ValueError(f"Unsafe tar member path: {name}")

        target.parent.mkdir(parents=True, exist_ok=True)
        try:
            src = tf.extractfile(member)
        except tarfile.ExtractError as exc:
            raise tarfile.ExtractError(f"Failed extracting member {name} from {tar_gz_path}") from exc
        except EOFError as exc:
            raise EOFError(f"Unexpected EOF extracting member {name} from {tar_gz_path}") from exc
        if src is None:
            continue

        with src:
            with target.open("wb") as dst:
                if limiter is not None:
                    limiter.on_new_file()
                while True:
                    try:
                        chunk = src.read(1024 * 1024)
                    except EOFError as exc:
                        raise EOFError(f"Unexpected EOF reading member {name} from {tar_gz_path}") from exc
                    if not chunk:
                        break
                    dst.write(chunk)
                    if limiter is not None:
                        limiter.on_bytes(len(chunk))
                    extracted_any = True
        extracted_files += 1
        if progress is not None:
            now = time.monotonic()
            if extracted_files == 1 or (now - last_emit) >= 0.2:
                last_emit = now
                progress.emit(
                    now_event(
                        kind=ProgressKind.STAGE_PROGRESS,
                        stage=ProgressStage.DISCOVERY,
                        current=extracted_files,
                        total=None,
                        message="extracting_tar",
                    )
                )

    return extracted_any
