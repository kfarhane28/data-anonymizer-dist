from __future__ import annotations

import os
from dataclasses import dataclass

from log_anonymizer.licensing.features import FREE_FEATURES, PRO_FEATURES, FeatureFlag
from log_anonymizer.licensing.models import Edition, ValidationResult
from log_anonymizer.licensing.storage import LicenseStorage
from log_anonymizer.licensing.validator import validate_license_key


@dataclass(frozen=True)
class LicensingService:
    storage: LicenseStorage

    @classmethod
    def default(cls) -> "LicensingService":
        return cls(storage=LicenseStorage.default())

    def load_key(self) -> str | None:
        # Highest priority: environment variable (useful for containers/CI).
        env = os.environ.get("DATA_ANONYMIZER_LICENSE_KEY") or os.environ.get("LOG_ANONYMIZER_LICENSE_KEY")
        if env and env.strip():
            return env.strip()
        return self.storage.load()

    def validate(self) -> ValidationResult:
        return validate_license_key(self.load_key())

    def edition(self) -> Edition:
        res = self.validate()
        if res.valid and res.license_info is not None and res.license_info.edition == Edition.pro:
            return Edition.pro
        return Edition.free

    def enabled_features(self) -> frozenset[FeatureFlag]:
        res = self.validate()
        if not res.valid or res.license_info is None:
            return FREE_FEATURES

        # Pro license: enable the default Pro feature set, unless the license restricts it.
        if res.license_info.enabled_features is None:
            return PRO_FEATURES
        return frozenset(res.license_info.enabled_features)
