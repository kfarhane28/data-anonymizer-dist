from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _default_license_path() -> Path:
    # Simple, dependency-free default.
    # Users/admins can override with $LOG_ANONYMIZER_LICENSE_PATH.
    base = Path.home() / ".config" / "data-anonymizer"
    return base / "license.key"


@dataclass(frozen=True)
class LicenseStorage:
    path: Path

    @classmethod
    def default(cls) -> "LicenseStorage":
        env = os.environ.get("DATA_ANONYMIZER_LICENSE_PATH") or os.environ.get("LOG_ANONYMIZER_LICENSE_PATH")
        if env:
            return cls(Path(env).expanduser())
        # Backward compatibility: if the legacy path exists, keep using it.
        legacy = Path.home() / ".config" / "log-anonymizer" / "license.key"
        if legacy.exists():
            return cls(legacy)
        return cls(_default_license_path())

    def load(self) -> str | None:
        try:
            raw = self.path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            return None
        if not raw:
            return None
        return raw

    def save(self, key: str) -> None:
        key = (key or "").strip()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(key + "\n", encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except PermissionError:
            pass
        tmp.replace(self.path)

    def clear(self) -> None:
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
