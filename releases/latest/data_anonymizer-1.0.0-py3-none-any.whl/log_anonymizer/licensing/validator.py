from __future__ import annotations

import base64
import json
import os
import re
from datetime import date, datetime, timezone
from typing import Any

from log_anonymizer import __version__
from log_anonymizer.licensing.features import FeatureFlag, PRO_FEATURES
from log_anonymizer.licensing.models import Edition, LicenseInfo, ValidationReason, ValidationResult
from log_anonymizer.licensing.public_key import PUBLIC_KEY_B64


_B64URL_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _b64url_decode(s: str) -> bytes:
    s = s.strip()
    if not s or not _B64URL_RE.match(s):
        raise ValueError("not base64url")
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _parse_iso_date(value: Any) -> date:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("expiry_date must be an ISO date string")
    v = value.strip()
    try:
        return date.fromisoformat(v)
    except ValueError as exc:
        raise ValueError("expiry_date must be in YYYY-MM-DD format") from exc


def _parse_version_tuple(v: str) -> tuple[int, int, int]:
    m = re.match(r"^\s*(\d+)\.(\d+)\.(\d+)", str(v))
    if not m:
        raise ValueError("max_version must look like X.Y.Z")
    return int(m.group(1)), int(m.group(2)), int(m.group(3))


def _version_gt(a: str, b: str) -> bool:
    return _parse_version_tuple(a) > _parse_version_tuple(b)


def _load_public_key_bytes() -> bytes:
    """
    Embedded *public* key for signature verification (not a secret).

    For test/enterprise deployments, it can be overridden via:
    - $LOG_ANONYMIZER_PUBLIC_KEY_B64 (base64 of raw Ed25519 public key bytes)
    """
    override = os.environ.get("DATA_ANONYMIZER_PUBLIC_KEY_B64") or os.environ.get("LOG_ANONYMIZER_PUBLIC_KEY_B64")
    if override:
        return base64.b64decode(override.strip())

    return base64.b64decode(PUBLIC_KEY_B64)


def validate_license_key(key: str | None) -> ValidationResult:
    if not key or not str(key).strip():
        return ValidationResult(valid=False, reason=ValidationReason.missing, message="license key missing")

    raw = str(key).strip()
    parts = raw.split(".")
    if len(parts) != 3 or parts[0] != "LA1":
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message="license key format invalid")

    try:
        payload_bytes = _b64url_decode(parts[1])
        sig_bytes = _b64url_decode(parts[2])
    except Exception as exc:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=f"invalid encoding: {exc}")

    # Verify signature (Ed25519).
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ModuleNotFoundError:
        return ValidationResult(
            valid=False,
            reason=ValidationReason.crypto_unavailable,
            message='missing dependency: install "data-anonymizer[pro]" (legacy: "log-anonymizer[pro]")',
        )

    try:
        pub = Ed25519PublicKey.from_public_bytes(_load_public_key_bytes())
        pub.verify(sig_bytes, payload_bytes)
    except Exception:
        return ValidationResult(valid=False, reason=ValidationReason.invalid_signature, message="invalid signature")

    try:
        payload = json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=f"invalid JSON payload: {exc}")

    if not isinstance(payload, dict):
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message="payload must be an object")

    try:
        customer_name = str(payload.get("customer_name") or "").strip()
        customer_id = str(payload.get("customer_id") or "").strip()
        edition_raw = str(payload.get("edition") or "").strip().lower()
        expiry = _parse_iso_date(payload.get("expiry_date"))
        max_version = payload.get("max_version")
        max_version_str = str(max_version).strip() if isinstance(max_version, str) and max_version.strip() else None
        features_raw = payload.get("features")
    except Exception as exc:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message=str(exc))

    if not customer_name or not customer_id:
        return ValidationResult(valid=False, reason=ValidationReason.malformed, message="customer fields missing")

    if edition_raw != Edition.pro.value:
        return ValidationResult(
            valid=False,
            reason=ValidationReason.unsupported_edition,
            message=f"unsupported edition: {edition_raw or '<missing>'}",
        )

    today = datetime.now(timezone.utc).date()
    if expiry < today:
        return ValidationResult(valid=False, reason=ValidationReason.expired, message="license expired")

    if max_version_str is not None:
        try:
            if _version_gt(__version__, max_version_str):
                return ValidationResult(
                    valid=False,
                    reason=ValidationReason.max_version_exceeded,
                    message=f"license max_version exceeded (max={max_version_str}, current={__version__})",
                )
        except Exception as exc:
            return ValidationResult(valid=False, reason=ValidationReason.malformed, message=str(exc))

    enabled_features: tuple[FeatureFlag, ...] | None = None
    if features_raw is not None:
        if not isinstance(features_raw, list) or not all(isinstance(x, str) for x in features_raw):
            return ValidationResult(
                valid=False, reason=ValidationReason.malformed, message="features must be a list of strings"
            )
        selected: list[FeatureFlag] = []
        for name in features_raw:
            try:
                selected.append(FeatureFlag(name))
            except Exception:
                # Forward compatible: ignore unknown feature names.
                continue
        enabled_features = tuple(f for f in selected if f in PRO_FEATURES)

    info = LicenseInfo(
        customer_name=customer_name,
        customer_id=customer_id,
        edition=Edition.pro,
        expiry_date=expiry,
        max_version=max_version_str,
        enabled_features=enabled_features,
    )
    return ValidationResult(valid=True, reason=ValidationReason.ok, license_info=info, message="ok")
