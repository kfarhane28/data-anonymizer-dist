from __future__ import annotations

# Embedded vendor public key (Ed25519), base64 of raw 32-byte public key.
#
# Replace this value for production releases.
# The private signing key must never be included in the application.
#
# You can also override at runtime via:
#   LOG_ANONYMIZER_PUBLIC_KEY_B64=<base64 public key>
PUBLIC_KEY_B64 = "GjRsBFGmhuq1OFhMs8BFItRYRIhVNIzvdXzya6l3M4g="
