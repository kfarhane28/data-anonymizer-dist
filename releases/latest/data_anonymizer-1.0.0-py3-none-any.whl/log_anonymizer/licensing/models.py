from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from log_anonymizer.licensing.features import FeatureFlag


class Edition(str, Enum):
    free = "free"
    pro = "pro"


class ValidationReason(str, Enum):
    ok = "ok"
    missing = "missing"
    malformed = "malformed"
    invalid_signature = "invalid_signature"
    expired = "expired"
    unsupported_edition = "unsupported_edition"
    max_version_exceeded = "max_version_exceeded"
    crypto_unavailable = "crypto_unavailable"


@dataclass(frozen=True)
class LicenseInfo:
    customer_name: str
    customer_id: str
    edition: Edition
    expiry_date: date
    max_version: str | None = None
    enabled_features: tuple[FeatureFlag, ...] | None = None


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    reason: ValidationReason
    license_info: LicenseInfo | None = None
    message: str = ""
