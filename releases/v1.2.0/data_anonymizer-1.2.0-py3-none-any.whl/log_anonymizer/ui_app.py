from __future__ import annotations
import html
import json
import hashlib
import logging
import os
import base64
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Literal
import streamlit as st
import streamlit.components.v1 as components
import pandas as pd
from log_anonymizer import __version__
from log_anonymizer.exclude_filter import ExcludeFilter, default_patterns
from log_anonymizer.input_limits import DEFAULT_FREE_LIMITS, InputLimitError, resolve_free_input_limits
from log_anonymizer.input_handler import handle_input
from log_anonymizer.exclude_filter import load_patterns as _load_exclude_patterns
from log_anonymizer.application.preview_anonymization import PreviewAnonymizationRequest, PreviewLineDetail, preview_anonymization
from log_anonymizer.profiling.profiler import ProfilingConfig, SensitiveDataProfiler
from log_anonymizer.profiling.runner import run_sensitive_data_profiling
from log_anonymizer.processor import CancellationToken, ProcessorConfig, process_with_result
from log_anonymizer.progress import ProgressEvent, ProgressKind, ProgressStage, QueueProgressReporter
from log_anonymizer.rules_loader import load_rules
from log_anonymizer.rules_validation import validate_rules_json_bytes
from log_anonymizer.rule_actions import ReplacementAction
from log_anonymizer.licensing.features import FeatureFlag
from log_anonymizer.licensing.models import Edition
from log_anonymizer.licensing.service import LicensingService
InputMode = Literal['Upload file', 'Upload archive', 'Use path']
logger = logging.getLogger(__name__)

def _tool_version_label() -> str:
    _o0 = (__version__ or '').strip()
    if not _o0:
        return ''
    return _o0 if _o0.startswith('v') else f'v{_o0}'

@dataclass(frozen=True)
class PreparedRun:
    input_path: Path | None
    rules_path: Path
    exclude_path: Path | None
    output_dir: Path
    verbose: bool
    dry_run: bool
    profile_sensitive_data: bool
    profiling_detectors: tuple[str, ...]
    parallel_enabled: bool
    max_workers: int
    features: frozenset[FeatureFlag]
    edition: Edition
    keep_partial_on_cancel: bool

class _QueueHandler(logging.Handler):

    def __init__(self, q: Queue[str], level: int) -> None:
        super().__init__(level=level)
        self._q = q

    def emit(self, record: logging.LogRecord) -> None:
        try:
            _o0 = self.format(record)
            self._q.put_nowait(_o0)
        except Exception:
            pass

def _render_header() -> None:
    _o2 = Path(__file__).resolve().parent / 'assets' / 'logo.svg'
    _o3 = _o2.read_text(encoding='utf-8')
    _o0 = base64.b64encode(_o3.encode('utf-8')).decode('ascii')
    _o1 = f'\n    <div style="display:flex; align-items:center; gap:12px; margin: 4px 0 8px 0;">\n      <img src="data:image/svg+xml;base64,{_o0}" width="36" height="36" />\n      <div style="font-size: 34px; font-weight: 700; line-height: 1.0;">Data Anonymizer</div>\n    </div>\n    '
    st.markdown(_o1, unsafe_allow_html=True)
    st.markdown('\n        <style>\n          /* Avoid button label wrapping (e.g., "Clear log" splitting on 2 lines). */\n          div.stButton > button { white-space: nowrap; }\n        </style>\n        ', unsafe_allow_html=True)

def main() -> None:
    st.set_page_config(page_title='Data Anonymizer', layout='wide')
    _init_state()
    _pump_logs_once()
    _render_header()
    _oe = _render_sidebar()
    _o3, _oc = st.columns([5.5, 1.0], gap='large')
    with _o3:
        _o14 = st.columns([1.1, 1.3, 1.6, 8])
        _of = _o14[0].button('Run', type='primary')
        _o2 = _o14[1].button('Cancel', disabled=not st.session_state.get('run_in_progress', False))
        _o4 = _o14[2].button('Clear log', disabled=st.session_state.get('run_in_progress', False))
        if _of:
            _start_run(_oe)
        if _o2:
            _request_cancel()
        if _o4:
            st.session_state['log_lines'] = []
            st.session_state['run_error'] = ''
            st.session_state['run_status'] = ''
            st.session_state['result_zip_bytes'] = None
            st.session_state['result_zip_name'] = None
            st.rerun()
        if st.session_state.get('run_status'):
            st.info(st.session_state['run_status'])
        if st.session_state.get('run_error'):
            st.error(st.session_state['run_error'])
        if st.session_state.get('run_in_progress'):
            _render_progress_panel()
        _o6 = st.session_state.get('license_features', frozenset())
        _o12 = ['Logs', 'Rules', 'Exclude']
        _o10 = FeatureFlag.preview_mode in _o6
        if _o10:
            _o12.append('Anonymization Preview')
        _o13 = st.tabs(_o12)
        _o9, _od, _o5 = (_o13[0], _o13[1], _o13[2])
        _oa = _o13[3] if _o10 else None
        with _o9:
            _o8 = st.container(border=True, height=760)
            with _o8:
                st.code('\n'.join(st.session_state['log_lines'][-1200:]), language='text')
            if st.session_state.get('profiling_report_bytes') is not None or st.session_state.get('suggested_rules_bytes') is not None:
                st.markdown('---')
                st.subheader('Profiling outputs')
                if st.session_state.get('profiling_report_bytes') is not None:
                    _o0, _o1 = st.columns([10, 1])
                    with _o0:
                        st.markdown('**Profiling report**')
                    with _o1:
                        st.download_button('⬇', data=st.session_state['profiling_report_bytes'], file_name=st.session_state.get('profiling_report_name', 'profiling_report.json'), mime='application/json', help='Download profiling report', use_container_width=True)
                    try:
                        _ob = st.session_state['profiling_report_bytes'].decode('utf-8', errors='replace')
                    except Exception:
                        _ob = ''
                    with st.expander('View report', expanded=True):
                        st.code(_ob or '(unreadable report)', language='json')
                if st.session_state.get('suggested_rules_bytes') is not None:
                    _o0, _o1 = st.columns([10, 1])
                    with _o0:
                        st.markdown('**Suggested rules**')
                    with _o1:
                        st.download_button('⬇', data=st.session_state['suggested_rules_bytes'], file_name=st.session_state.get('suggested_rules_name', 'suggested_rules.json'), mime='application/json', help='Download suggested rules', use_container_width=True)
                    try:
                        _o11 = st.session_state['suggested_rules_bytes'].decode('utf-8', errors='replace')
                    except Exception:
                        _o11 = ''
                    with st.expander('View suggested rules', expanded=True):
                        st.code(_o11 or '(unreadable suggested rules)', language='json')
            if st.session_state.get('run_in_progress'):
                st.caption('Updating logs…')
                time.sleep(0.25)
                st.rerun()
        with _od:
            _render_rules_editor()
        with _o5:
            _render_exclude_editor()
        if _oa is not None:
            with _oa:
                _render_preview_tab(_oe)
    with _oc:
        st.subheader('Output')
        st.write(f'Output directory: `{_oe.output_dir}`')
        if _oe.input_path is not None:
            st.write(f'Output archive: `{_default_output_archive_path(_oe.output_dir, _oe.input_path)}`')
        else:
            st.write('Output archive: (missing input)')
        _o7 = any((st.session_state.get(k) is not None for k in ('result_zip_bytes', 'profiling_report_bytes', 'suggested_rules_bytes')))
        if _o7:
            st.success('Done.')
        if st.session_state.get('result_zip_bytes') is not None:
            st.download_button('Download archive', data=st.session_state['result_zip_bytes'], file_name=st.session_state.get('result_zip_name', 'anonymized.tar.gz'), mime='application/gzip', width='stretch')
        st.subheader('Run')
        st.write(f'Verbose: `{_oe.verbose}`')
        st.write(f'Dry run: `{_oe.dry_run}`')
        st.write(f'Sensitive-data profiling: `{bool(_oe.profile_sensitive_data)}`')
        st.write(f'Exclude provided: `{bool(_oe.exclude_path)}`')
        st.write(f"Rules file: `{(_oe.rules_path.name if _oe.rules_path else 'default (built-in only)')}`")

def _init_state() -> None:
    st.session_state.setdefault('log_queue', Queue())
    st.session_state.setdefault('outcome_queue', Queue())
    st.session_state.setdefault('progress_queue', Queue())
    st.session_state.setdefault('log_lines', [])
    st.session_state.setdefault('run_in_progress', False)
    st.session_state.setdefault('run_status', '')
    st.session_state.setdefault('run_error', '')
    st.session_state.setdefault('result_zip_bytes', None)
    st.session_state.setdefault('result_zip_name', None)
    st.session_state.setdefault('profiling_report_bytes', None)
    st.session_state.setdefault('profiling_report_name', None)
    st.session_state.setdefault('suggested_rules_bytes', None)
    st.session_state.setdefault('suggested_rules_name', None)
    st.session_state.setdefault('tmp_dir', None)
    st.session_state.setdefault('log_handler', None)
    st.session_state.setdefault('log_prev_handlers', None)
    st.session_state.setdefault('ui_warnings', [])
    st.session_state.setdefault('ui_errors', [])
    st.session_state.setdefault('rules_editor_df_v1', None)
    st.session_state.setdefault('rules_editor_df_v2', None)
    st.session_state.setdefault('rules_editor_mode', 'table_v1')
    st.session_state.setdefault('rules_editor_mode_radio', None)
    st.session_state.setdefault('rules_editor_text', None)
    st.session_state.setdefault('rules_editor_json_widget', None)
    st.session_state.setdefault('exclude_editor_df', None)
    st.session_state.setdefault('rules_upload_sig', None)
    st.session_state.setdefault('exclude_upload_sig', None)
    st.session_state.setdefault('input_upload_sig', None)
    st.session_state.setdefault('input_upload_path', None)
    st.session_state.setdefault('preview_input', '')
    st.session_state.setdefault('preview_output_value', '')
    st.session_state.setdefault('preview_status', '')
    st.session_state.setdefault('preview_error', '')
    st.session_state.setdefault('preview_profile_report', '')
    st.session_state.setdefault('preview_suggested_rules', '')
    st.session_state.setdefault('preview_line_details', ())
    st.session_state.setdefault('preview_replacements_by_rule', {})
    st.session_state.setdefault('progress_stage', None)
    st.session_state.setdefault('progress_stage_current', None)
    st.session_state.setdefault('progress_stage_total', None)
    st.session_state.setdefault('progress_stage_message', '')
    st.session_state.setdefault('progress_files_done', 0)
    st.session_state.setdefault('progress_files_total', None)
    st.session_state.setdefault('progress_file_path', None)
    st.session_state.setdefault('progress_file_done', None)
    st.session_state.setdefault('progress_file_total', None)
    st.session_state.setdefault('cancel_token', None)
    st.session_state.setdefault('license_features', frozenset())
    st.session_state.setdefault('license_status', '')
    st.session_state.setdefault('license_upload_counter', 0)
    st.session_state.setdefault('license_input_text', '')
    st.session_state.setdefault('license_input_counter', 0)
    st.session_state.pop('preview_output', None)

def _render_sidebar() -> PreparedRun:
    service = LicensingService.default()
    _o22 = service.validate()
    _oa = service.enabled_features()
    _o8 = service.edition()
    st.session_state['license_features'] = _oa
    st.sidebar.header('Configuration')
    st.session_state['ui_warnings'] = []
    st.session_state['ui_errors'] = []
    st.sidebar.markdown('### Edition')
    if _o22.valid and _o22.license_info is not None:
        st.sidebar.success('Pro edition active')
        st.sidebar.caption(f'Customer: {_o22.license_info.customer_name}')
        st.sidebar.caption(f'Expires: {_o22.license_info.expiry_date.isoformat()}')
        _o9 = sorted((f.value for f in _oa))
        st.sidebar.caption('Features: ' + (', '.join(_o9) if _o9 else '<none>'))
    else:
        if _o22.reason.value == 'expired':
            st.sidebar.warning('License expired (Free mode)')
        elif _o22.reason.value in ('invalid_signature', 'malformed', 'unsupported_edition', 'max_version_exceeded'):
            st.sidebar.warning('Invalid license (Free mode)')
        elif _o22.reason.value == 'crypto_unavailable':
            st.sidebar.warning('Cannot validate Pro license (install "data-anonymizer[pro]")')
        else:
            st.sidebar.info('Free edition')
        st.sidebar.caption(f'License status: {_o22.reason.value}')
    _render_workload_limits_notice(_o8)
    with st.sidebar.expander('License', expanded=False):
        st.markdown('Install a Pro license key to unlock premium features.')
        st.caption('You can also manage licenses via CLI: `data-anonymizer license ...`')
        _o1b = str(st.session_state.get('license_status') or '').strip()
        if _o1b:
            st.success(_o1b)
        _o1c = int(st.session_state.get('license_upload_counter') or 0)
        _o1d = st.file_uploader('Load from file', type=None, key=f'license_upload_{_o1c}')
        if _o1d is not None:
            try:
                st.session_state['license_input_text'] = bytes(_o1d.getbuffer()).decode('utf-8', errors='replace').strip()
            except Exception:
                st.session_state['license_input_text'] = ''
            st.session_state['license_input_counter'] = int(st.session_state.get('license_input_counter') or 0) + 1
        _ob = int(st.session_state.get('license_input_counter') or 0)
        _oc = f'license_input_widget_{_ob}'
        _o10 = st.text_area('License key', key=_oc, value=str(st.session_state.get('license_input_text') or ''), placeholder='LA1.<payload_b64url>.<signature_b64url>', height=120)
        st.session_state['license_input_text'] = _o10
        _o0, _o1, _o2 = st.columns([1, 1, 1])
        _o21 = not bool((_o10 or '').strip())
        if _o0.button('Validate', use_container_width=True, disabled=_o21):
            from log_anonymizer.licensing.validator import validate_license_key
            _o19 = validate_license_key(_o10)
            if _o19.valid:
                st.session_state['license_status'] = 'License is valid.'
            else:
                st.error(f'License is not valid: {_o19.reason.value}')
                if _o19.message:
                    st.caption(_o19.message)
        if _o1.button('Validate & Save', use_container_width=True, disabled=_o21):
            from log_anonymizer.licensing.validator import validate_license_key
            _o19 = validate_license_key(_o10)
            if not _o19.valid:
                st.error(f'Cannot save: {_o19.reason.value}')
                if _o19.message:
                    st.caption(_o19.message)
            else:
                service.storage.save(_o10)
                st.session_state['license_status'] = 'Saved.'
                st.rerun()

        def _on_clear_license() -> None:
            service.storage.clear()
            st.session_state['license_status'] = 'Cleared.'
            st.session_state['license_upload_counter'] = int(st.session_state.get('license_upload_counter') or 0) + 1
            st.session_state['license_input_text'] = ''
            st.session_state['license_input_counter'] = int(st.session_state.get('license_input_counter') or 0) + 1
        _o2.button('Clear', use_container_width=True, on_click=_on_clear_license)
        st.markdown('---')
        st.markdown('**Free vs Pro (summary)**')
        st.markdown('- Free: basic anonymization, legacy replace-only rules, sequential processing.\n- Pro: advanced rule actions, parallel processing, UI preview, profiling, keep partial output on cancel.')
    _od: InputMode = st.sidebar.radio('Input source', options=['Upload file', 'Upload archive', 'Use path'], index=0)
    _o1f = None
    _oe = ''
    if _od == 'Upload file':
        _o1f = st.sidebar.file_uploader('Upload a log file', type=None)
    elif _od == 'Upload archive':
        _o1f = st.sidebar.file_uploader('Upload an archive (.zip / .tar.gz)', type=['zip', 'tgz', 'gz'])
    else:
        _oe = st.sidebar.text_input('Input path', value='tmp_test/in')
    _o20 = st.sidebar.file_uploader('Rules JSON', type=['json'], key='rules_upload')
    _o1e = st.sidebar.file_uploader('Exclude file (.exclude)', type=None, key='exclude_upload')
    _o12 = st.sidebar.text_input('Output directory', value='tmp_test/ui_out')
    _o23 = st.sidebar.checkbox('Verbose mode (DEBUG)', value=False)
    _o6 = st.sidebar.checkbox('Dry run', value=False)
    _o3 = FeatureFlag.partial_cancel_preservation in _oa
    _of = st.sidebar.checkbox('Keep partial output on cancel (Pro)', value=bool(_o3), disabled=not _o3, help='When enabled, cancelling a run keeps partial output when possible.')
    if not _o3:
        _of = False
        st.sidebar.caption('Partial-output preservation requires Pro.')
    st.sidebar.markdown('### Performance')
    _o13 = FeatureFlag.parallel_processing in _oa
    _o14 = st.sidebar.checkbox('Enable parallel file processing', value=False, help='Processes files concurrently to speed up large bundles. Output is functionally identical.', disabled=not _o13)
    if not _o13:
        _o14 = False
        st.sidebar.caption('Parallel processing requires Pro.')
    _o4 = int(os.getenv('DATA_ANONYMIZER_WORKERS') or os.getenv('LOG_ANONYMIZER_WORKERS') or '5')
    _o11 = int(st.sidebar.number_input('Max parallel workers', min_value=1, max_value=64, value=max(1, min(64, _o4)), step=1, disabled=not _o14, help='Only used when parallel processing is enabled (default: 5).'))
    _o17 = FeatureFlag.profiling in _oa
    _o16 = st.sidebar.checkbox('Enable sensitive-data profiling (optional)', value=False, help='Heuristic scan for potential sensitive data + suggested rules. Does not change anonymization unless you apply the suggested rules.', disabled=not _o17)
    if not _o17:
        _o16 = False
        st.sidebar.caption('Profiling requires Pro.')
    st.sidebar.markdown('### Integrations')
    _o1a = FeatureFlag.spark_connect in _oa
    st.sidebar.checkbox('Spark engine connect (coming soon)', value=False, disabled=True, help='Not available in this build.')
    if not _o1a:
        st.sidebar.caption('Spark connect requires Pro (and is not yet available).')
    _o5 = ('email', 'ipv4', 'token', 'card')
    _o18 = _o5
    if _o16:
        _o18 = tuple(st.sidebar.multiselect('Profiling detectors', options=list(_o5), default=list(_o5))) or _o5
    _o15 = _prepare_files(input_mode=_od, uploaded_input=_o1f, input_path_text=_oe, uploaded_rules=_o20, uploaded_exclude=_o1e, output_dir_text=_o12, verbose=_o23, dry_run=_o6, profile_sensitive_data=_o16, profiling_detectors=_o18, parallel_enabled=_o14, max_workers=_o11, features=_oa, edition=_o8, keep_partial_on_cancel=_of)
    if st.session_state.get('ui_errors'):
        st.sidebar.markdown('---')
        for _o7 in st.session_state['ui_errors']:
            st.sidebar.error(_o7)
    for _o24 in st.session_state.get('ui_warnings', []):
        st.sidebar.warning(_o24)
    return _o15

def _prepare_files(*, input_mode: InputMode, uploaded_input, input_path_text: str, uploaded_rules, uploaded_exclude, output_dir_text: str, verbose: bool, dry_run: bool, profile_sensitive_data: bool, profiling_detectors: tuple[str, ...], parallel_enabled: bool, max_workers: int, features: frozenset[FeatureFlag], edition: Edition, keep_partial_on_cancel: bool) -> PreparedRun:
    _od = _ensure_tmp_dir()
    if input_mode in ('Upload file', 'Upload archive'):
        if uploaded_input is None:
            _o5 = None
        else:
            if input_mode == 'Upload archive':
                _o6 = str(getattr(uploaded_input, 'name', '') or 'input.tar.gz')
            else:
                _o6 = str(getattr(uploaded_input, 'name', '') or 'input')
            _o5 = _save_upload_cached(_od, uploaded_input, name_hint=_o6)
    else:
        _oa = (input_path_text or '').strip()
        _o5 = Path(_oa).expanduser() if _oa else None
    _maybe_add_free_limit_validation(_o5, edition=edition)
    if uploaded_rules is None:
        _ensure_rules_editor_initialized()
        _ob = _write_rules_from_editor(_od)
    else:
        _oa = bytes(uploaded_rules.getbuffer())
        _o2 = _validate_rules_json_bytes(_oa)
        if _o2:
            st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o2}')
            _ensure_rules_editor_initialized()
            _ob = _write_rules_from_editor(_od)
        else:
            _maybe_load_rules_upload_into_editor(_oa, name=str(uploaded_rules.name))
            _ob = _write_rules_from_editor(_od)
    try:
        _o1 = _ob.read_bytes()
    except Exception:
        _o1 = b''
    _o0 = _validate_rules_json_bytes(_o1)
    if _o0:
        st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o0}')
    elif FeatureFlag.advanced_rules not in features:
        try:
            _o8 = load_rules(_ob, strict=True)
        except Exception as exc:
            st.session_state['ui_errors'].append(f'Rules JSON invalid: {_o3}')
        else:
            for _o9 in _o8:
                if not isinstance(getattr(_o9, 'action', None), ReplacementAction):
                    st.session_state['ui_errors'].append('Advanced rule actions require a Pro license.')
                    break
    _o4 = None
    if uploaded_exclude is not None:
        _oa = bytes(uploaded_exclude.getbuffer())
        _o2 = _validate_exclude_bytes(_oa, filename=str(uploaded_exclude.name))
        if _o2:
            st.session_state['ui_errors'].append(f'Exclude file invalid: {_o2}')
            _o4 = None
        else:
            _maybe_load_exclude_upload_into_editor(_oa, name=str(uploaded_exclude.name))
            _o4 = _write_exclude_from_editor(_od)
    elif _exclude_editor_has_patterns():
        _o4 = _write_exclude_from_editor(_od)
    st.sidebar.markdown('---')
    _oe = _tool_version_label()
    _oc = f' · {_oe}' if _oe else ''
    st.sidebar.caption(f'© 2026 MagicByte Consulting · Proprietary software{_oc}')
    _o7 = Path(output_dir_text).expanduser()
    return PreparedRun(input_path=_o5, rules_path=_ob, exclude_path=_o4, output_dir=_o7, verbose=verbose, dry_run=dry_run, profile_sensitive_data=profile_sensitive_data, profiling_detectors=profiling_detectors, parallel_enabled=parallel_enabled, max_workers=int(max_workers), features=features, edition=edition, keep_partial_on_cancel=keep_partial_on_cancel)

def _render_workload_limits_notice(edition: Edition) -> None:
    if edition == Edition.pro:
        st.sidebar.caption('Pro edition: workload limits removed.')
        return
    st.sidebar.caption('Free edition: workload limits apply (upgrade to Pro for larger bundles).')
    with st.sidebar.expander('Free edition limits', expanded=True):
        st.markdown('- Single file: up to **' + str(int(DEFAULT_FREE_LIMITS.max_single_file_bytes / (1024 * 1024))) + ' MB**\n- Archives (`.zip`, `.tar.gz`): up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_compressed_bytes / (1024 * 1024))) + ' MB** (compressed)\n- Extracted content: up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_extracted_total_bytes / (1024 * 1024))) + ' MB** total\n- Extracted files: up to **' + str(int(DEFAULT_FREE_LIMITS.max_archive_extracted_file_count)) + '** files\n\nPro edition supports larger workloads (Free limits removed).')

def _maybe_add_free_limit_validation(input_path: Path | None, *, edition: Edition) -> None:
    if edition == Edition.pro:
        return
    if input_path is None:
        return
    try:
        _o3 = input_path.expanduser()
    except Exception:
        return
    if not _o3.exists() or not _o3.is_file():
        return
    _o1 = resolve_free_input_limits(edition=edition)
    if _o1 is None:
        return
    try:
        _o2 = _o3.name.lower()
        _o4 = _o3.stat().st_size
        if _o2.endswith(('.tar.gz', '.tgz')) or _o3.suffix.lower() == '.zip':
            from log_anonymizer.input_limits import validate_archive_compressed_size
            validate_archive_compressed_size(_o4, limits=_o1)
        else:
            from log_anonymizer.input_limits import validate_single_file_size
            validate_single_file_size(_o4, limits=_o1)
    except InputLimitError as exc:
        st.session_state['ui_errors'].append(str(_o0))

def _ensure_tmp_dir() -> Path:
    _o0 = st.session_state.get('tmp_dir')
    if _o0 and Path(_o0).exists():
        return Path(_o0)
    _o1 = Path(tempfile.mkdtemp(prefix='log-anonymizer-ui-')).resolve()
    st.session_state['tmp_dir'] = str(_o1)
    return _o1

def _save_upload_cached(tmp_dir: Path, uploaded, *, name_hint: str) -> Path:
    """
    Persist an uploaded file to disk in a stable, content-addressed path.

    Streamlit re-runs the script frequently; without caching, we might overwrite the same
    on-disk tar.gz while a background worker is reading it (leading to intermittent EOF/ReadError).
    """
    tmp_dir.mkdir(parents=True, exist_ok=True)
    _o3 = bytes(uploaded.getbuffer())
    _o4 = Path(name_hint).name
    _o5 = _sig(_o4, _o3)
    _o2 = st.session_state.get('input_upload_sig')
    _o1 = st.session_state.get('input_upload_path')
    if _o2 == _o5 and isinstance(_o1, str) and _o1:
        _o0 = Path(_o1)
        if _o0.exists():
            return _o0
    _o6 = (tmp_dir / f'input-{_o5[:12]}-{_o4}').resolve()
    _atomic_write_bytes(_o6, _o3)
    st.session_state['input_upload_sig'] = _o5
    st.session_state['input_upload_path'] = str(_o6)
    return _o6

def _atomic_write_bytes(target: Path, raw: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    _o0 = target.with_suffix(target.suffix + '.tmp')
    _o0.write_bytes(raw)
    os.replace(_o0, target)

def _default_output_archive_path(output_dir: Path, input_path: Path) -> Path:
    _o3 = output_dir.expanduser().resolve()
    _o2 = input_path.name
    _o1 = _o2.lower()
    if _o1.endswith('.tar.gz'):
        _o0 = _o2[:-len('.tar.gz')]
    elif _o1.endswith('.tgz'):
        _o0 = _o2[:-len('.tgz')]
    elif _o1.endswith('.zip'):
        _o0 = input_path.stem
    else:
        _o0 = input_path.stem or _o2
    return _o3 / f'{_o0}.tar.gz'

def _start_run(run: PreparedRun) -> None:
    st.session_state['run_error'] = ''
    st.session_state['result_zip_bytes'] = None
    st.session_state['result_zip_name'] = None
    st.session_state['profiling_report_bytes'] = None
    st.session_state['profiling_report_name'] = None
    st.session_state['suggested_rules_bytes'] = None
    st.session_state['suggested_rules_name'] = None
    st.session_state['log_lines'] = []
    st.session_state['progress_stage'] = None
    st.session_state['progress_stage_current'] = None
    st.session_state['progress_stage_total'] = None
    st.session_state['progress_stage_message'] = ''
    st.session_state['progress_files_done'] = 0
    st.session_state['progress_files_total'] = None
    st.session_state['progress_file_path'] = None
    st.session_state['progress_file_done'] = None
    st.session_state['progress_file_total'] = None
    st.session_state['cancel_token'] = None
    _o1 = _validate_run(run)
    if _o1:
        st.session_state['run_error'] = _o1
        return
    st.session_state['run_in_progress'] = True
    st.session_state['run_status'] = 'Running…'
    _o0 = CancellationToken()
    st.session_state['cancel_token'] = _o0
    _o3: Queue[str] = Queue()
    _o4: Queue[dict[str, Any]] = Queue()
    _o6: Queue[ProgressEvent] = Queue()
    st.session_state['log_queue'] = _o3
    st.session_state['outcome_queue'] = _o4
    st.session_state['progress_queue'] = _o6
    while True:
        try:
            _o3.get_nowait()
        except Empty:
            break
    while True:
        try:
            _o4.get_nowait()
        except Empty:
            break
    while True:
        try:
            _o6.get_nowait()
        except Empty:
            break
    _o2, _o5 = _attach_streamlit_logger(_o3, verbose=run.verbose)
    st.session_state['log_handler'] = _o2
    st.session_state['log_prev_handlers'] = _o5
    _o7 = threading.Thread(target=_run_pipeline_thread, args=(run, _o0, _o3, _o4, _o6), daemon=True)
    _o7.start()

def _request_cancel() -> None:
    _o0 = st.session_state.get('cancel_token')
    if _o0 is None:
        return
    try:
        _o0.cancel()
    except Exception:
        return
    st.session_state['run_status'] = 'Cancellation requested…'

def _validate_run(run: PreparedRun) -> str | None:
    _o0 = st.session_state.get('ui_errors') or []
    if _o0:
        return str(_o0[0])
    if run.input_path is None:
        return 'Please provide an input (upload or path).'
    if str(run.input_path).strip() in ('', '.'):
        return 'Please provide an input (upload or path).'
    if not run.input_path.exists():
        return f'Input path does not exist: {run.input_path}'
    if not run.output_dir or str(run.output_dir) == '':
        return 'Please provide an output directory.'
    if not run.input_path.exists():
        return f'Input path does not exist: {run.input_path}'
    if run.output_dir.exists() and (not run.output_dir.is_dir()):
        return f'Output directory is not a directory: {run.output_dir}'
    if not run.rules_path.exists():
        return f'Rules file could not be created: {run.rules_path}'
    if run.exclude_path is not None and (not run.exclude_path.exists()):
        return f'Exclude file does not exist: {run.exclude_path}'
    return None

def _run_pipeline_thread(run: PreparedRun, cancel_token: CancellationToken, log_q: Queue[str], outcome_q: Queue[dict[str, Any]], progress_q: Queue[ProgressEvent]) -> None:
    try:
        _o9 = time.perf_counter()
        _o3 = bool(run.keep_partial_on_cancel)
        if run.input_path is None:
            outcome_q.put({'type': 'error', 'status': 'Failed.', 'error': 'Missing input.'})
            return
        if cancel_token.is_cancelled():
            outcome_q.put({'type': 'done', 'status': 'Cancelled.\n- No output produced.', 'archive_path': None, 'cancelled': True, 'rolled_back': False})
            return
        if run.dry_run:
            if run.profile_sensitive_data and run.input_path is not None:
                _o5 = run_sensitive_data_profiling(input_path=run.input_path, output_dir=run.output_dir, exclude_path=run.exclude_path, detectors=run.profiling_detectors)
                _o1 = int(round(time.perf_counter() - _o9))
                _o7 = f'DRY RUN (profiling only)\n- Profiling report: {_o5.profiling_report_path}\n- Suggested rules: {_o5.suggested_rules_path}\n- Duration: {_o1}s\n- Files: total={_o5.total_files}, excluded={_o5.excluded_files}, profiled={_o5.profiled_files}\n'
                log_q.put(_o7)
                outcome_q.put({'type': 'done', 'status': 'Dry run (profiling only) completed.', 'archive_path': None, 'profiling_report_path': str(_o5.profiling_report_path), 'suggested_rules_path': str(_o5.suggested_rules_path)})
                return
            _o1 = int(round(time.perf_counter() - _o9))
            _o7 = _dry_run(run)
            _o7 = _o7.rstrip('\n') + f'\n- Duration: {_o1}s\n'
            log_q.put(_o7)
            outcome_q.put({'type': 'done', 'status': 'Dry run completed.', 'archive_path': None})
            return
        _o0 = ProcessorConfig(parallel_enabled=bool(run.parallel_enabled), max_workers=int(run.max_workers), exclude_case_insensitive=False, include_builtin_rules=True, profile_sensitive_data=bool(run.profile_sensitive_data), profiling_detectors=run.profiling_detectors, cancellation_token=cancel_token, rollback_on_cancel=not _o3, edition=run.edition)
        _o4 = QueueProgressReporter(progress_q)
        _o6 = process_with_result(input_path=run.input_path, rules_path=run.rules_path, output_dir=run.output_dir, exclude_path=run.exclude_path, config=_o0, progress=_o4)
        _o1 = int(round(time.perf_counter() - _o9))
        if _o6.cancelled and _o6.rolled_back:
            _oa = 'Cancelled and rolled back.'
        elif _o6.cancelled:
            _oa = 'Cancelled with partial output kept.'
        else:
            _oa = 'Completed.'
        _o8 = [_oa]
        if _o6.output_zip.exists():
            _o8.append(f'- Output archive: {_o6.output_zip}')
        _o8.append(f'- Duration: {_o1}s')
        if _o6.profiling_report_path:
            _o8.append(f'- Profiling report: {_o6.profiling_report_path}')
        if _o6.suggested_rules_path:
            _o8.append(f'- Suggested rules: {_o6.suggested_rules_path}')
        _o8.extend([f'- Total files: {_o6.total_files}', f'- Excluded: {_o6.excluded_files}', f'- Processed: {_o6.processed_files}', f'- Failed: {_o6.failed_files}'])
        _o7 = '\n'.join(_o8)
        outcome_q.put({'type': 'done', 'status': _o7, 'archive_path': str(_o6.output_zip) if _o6.output_zip.exists() else None, 'profiling_report_path': str(_o6.profiling_report_path) if _o6.profiling_report_path is not None else None, 'suggested_rules_path': str(_o6.suggested_rules_path) if _o6.suggested_rules_path is not None else None, 'cancelled': bool(_o6.cancelled), 'rolled_back': bool(_o6.rolled_back), 'summary': {'total': _o6.total_files, 'excluded': _o6.excluded_files, 'processed': _o6.processed_files, 'failed': _o6.failed_files}})
    except Exception as exc:
        log_q.put(f'ERROR: {type(_o2).__name__}: {_o2}')
        outcome_q.put({'type': 'error', 'status': 'Failed.', 'error': f'{type(_o2).__name__}: {_o2}'})

def _dry_run(run: PreparedRun) -> str:
    if run.input_path is None:
        return 'DRY RUN\n- Input: (missing)\n'
    _of = load_rules(run.rules_path)
    _o7 = resolve_free_input_limits(edition=run.edition)
    with handle_input(run.input_path, limits=_o7) as _od:
        _o1 = _od.working_dir
        _o5 = _od.files
        _oc = list(default_patterns())
        if run.exclude_path is not None:
            _oc.extend(_load_exclude_patterns(run.exclude_path))
        _o2 = ExcludeFilter.from_patterns(_oc, base_dir=_o1, case_insensitive=False) if _oc else None
        _o6 = [_o4 for _o4 in _o5 if not (_o2 and _o2.should_exclude(_o4))]
    _oa = run.input_path.name
    _o9 = _oa.lower()
    if _o9.endswith('.tar.gz'):
        _o0 = _oa[:-len('.tar.gz')]
    elif _o9.endswith('.tgz'):
        _o0 = _oa[:-len('.tgz')]
    elif _o9.endswith('.zip'):
        _o0 = run.input_path.stem
    else:
        _o0 = run.input_path.stem or _oa
    _o10 = run.output_dir.expanduser().resolve() / f'{_o0}.tar.gz'
    _o3 = f'builtin={len(default_patterns())}'
    if run.exclude_path is not None:
        try:
            _o3 = f'{run.exclude_path} (builtin={len(default_patterns())}, user={len(_load_exclude_patterns(run.exclude_path))})'
        except Exception:
            _o3 = str(run.exclude_path)
    _o8 = ['DRY RUN', f'- Input: {run.input_path}', f'- Output dir: {run.output_dir}', f'- Output archive: {_o10}', f'- User rules loaded: {len(_of)} (built-in rules are enabled by default)', f'- Exclude: {_o3}', f'- Files: total={len(_o5)}, excluded={len(_o5) - len(_o6)}, to_process={len(_o6)}']
    _oe = [f'  - {_ob}' for _ob in _o6[:20]]
    if len(_o6) > 20:
        _oe.append(f'  ... ({len(_o6) - 20} more)')
    return '\n'.join(_o8 + _oe)

def _attach_streamlit_logger(q: Queue[str], *, verbose: bool) -> tuple[logging.Handler, list[logging.Handler]]:
    _o3 = logging.getLogger()
    _o2 = list(_o3.handlers)
    for _o0 in _o2:
        _o3.removeHandler(_o0)
    _o3.setLevel(logging.DEBUG if verbose else logging.INFO)
    _o1 = _QueueHandler(q, level=logging.DEBUG if verbose else logging.INFO)
    from log_anonymizer.config.logging_config import TextWithExtrasFormatter
    _o1.setFormatter(TextWithExtrasFormatter())
    _o3.addHandler(_o1)
    return (_o1, _o2)

def _detach_streamlit_logger(handler: logging.Handler, prev: list[logging.Handler]) -> None:
    _o1 = logging.getLogger()
    try:
        _o1.removeHandler(handler)
    except Exception:
        pass
    for _o0 in prev:
        _o1.addHandler(_o0)

def _pump_logs_once() -> None:
    _o2: Queue[str] = st.session_state['log_queue']
    _o1: list[str] = st.session_state['log_lines']
    while True:
        try:
            _o0 = _o2.get_nowait()
        except Empty:
            break
        _o1.append(_o0)
    st.session_state['log_lines'] = _o1
    _pump_progress_once()
    _pump_outcome_once()

def _pump_progress_once() -> None:
    _o1: Queue[ProgressEvent] = st.session_state['progress_queue']
    while True:
        try:
            _o0 = _o1.get_nowait()
        except Empty:
            break
        st.session_state['progress_stage'] = _o0.stage.value
        st.session_state['progress_stage_current'] = _o0.current
        st.session_state['progress_stage_total'] = _o0.total
        if _o0.message:
            st.session_state['progress_stage_message'] = _o0.message
        if _o0.kind == ProgressKind.STAGE_START and _o0.stage == ProgressStage.PROCESSING:
            st.session_state['progress_files_done'] = 0
            st.session_state['progress_files_total'] = _o0.total
        if _o0.kind == ProgressKind.STAGE_PROGRESS and _o0.stage == ProgressStage.PROCESSING:
            if _o0.current is not None:
                st.session_state['progress_files_done'] = _o0.current
            if _o0.total is not None:
                st.session_state['progress_files_total'] = _o0.total
        if _o0.kind in (ProgressKind.FILE_START, ProgressKind.FILE_PROGRESS, ProgressKind.FILE_END):
            if _o0.path:
                st.session_state['progress_file_path'] = _o0.path
            st.session_state['progress_file_done'] = _o0.bytes_done
            st.session_state['progress_file_total'] = _o0.bytes_total

def _render_progress_panel() -> None:
    _o8 = st.session_state.get('progress_stage') or ''
    _o9 = st.session_state.get('progress_stage_message') or ''
    _o0 = st.session_state.get('progress_stage_current')
    _oa = st.session_state.get('progress_stage_total')
    _o4 = int(st.session_state.get('progress_files_done') or 0)
    _o5 = st.session_state.get('progress_files_total')
    _o2 = st.session_state.get('progress_file_path')
    _o1 = st.session_state.get('progress_file_done')
    _o3 = st.session_state.get('progress_file_total')
    st.subheader('Progress')
    if _o5 is not None and int(_o5) > 0:
        _o6 = min(1.0, float(_o4) / float(_o5))
        st.progress(_o6, text=f'Files: {_o4}/{_o5}')
    else:
        st.progress(0.0, text='Files: (waiting)')
    if _oa is not None and _o0 is not None and (int(_oa) > 0):
        _o6 = min(1.0, float(_o0) / float(_oa))
        _o7 = f'Stage: {_o8} {_o0}/{_oa}'
        if _o9:
            _o7 += f' ({_o9})'
        st.progress(_o6, text=_o7)
    else:
        _o7 = f'Stage: {_o8}'.strip()
        if _o9:
            _o7 = (_o7 + f' ({_o9})').strip()
        st.caption(_o7 or 'Stage: (waiting)')
    if _o2 and _o1 is not None and (_o3 is not None) and (int(_o3) > 0):
        _o6 = min(1.0, float(_o1) / float(_o3))
        st.progress(_o6, text=f'File: {_o2}')
    elif _o2:
        st.caption(f'File: {_o2}')

def _pump_outcome_once() -> None:
    _o2: Queue[dict[str, Any]] = st.session_state['outcome_queue']
    while True:
        try:
            _o1 = _o2.get_nowait()
        except Empty:
            break
        if _o1.get('type') == 'done':
            st.session_state['run_status'] = str(_o1.get('status') or 'Completed.')
            _o0 = _o1.get('archive_path')
            if isinstance(_o0, str) and _o0:
                _o3 = Path(_o0)
                if _o3.exists():
                    st.session_state['result_zip_bytes'] = _o3.read_bytes()
                    st.session_state['result_zip_name'] = _o3.name
                else:
                    st.session_state['result_zip_bytes'] = None
                    st.session_state['result_zip_name'] = None
            _o4 = _o1.get('profiling_report_path')
            if isinstance(_o4, str) and _o4:
                _o3 = Path(_o4)
                if _o3.exists():
                    st.session_state['profiling_report_bytes'] = _o3.read_bytes()
                    st.session_state['profiling_report_name'] = _o3.name
            _o5 = _o1.get('suggested_rules_path')
            if isinstance(_o5, str) and _o5:
                _o3 = Path(_o5)
                if _o3.exists():
                    st.session_state['suggested_rules_bytes'] = _o3.read_bytes()
                    st.session_state['suggested_rules_name'] = _o3.name
            st.session_state['run_in_progress'] = False
            st.session_state['cancel_token'] = None
            _restore_logger_if_needed()
        elif _o1.get('type') == 'error':
            st.session_state['run_status'] = str(_o1.get('status') or 'Failed.')
            st.session_state['run_error'] = str(_o1.get('error') or 'Unknown error')
            st.session_state['run_in_progress'] = False
            st.session_state['cancel_token'] = None
            _restore_logger_if_needed()

def _restore_logger_if_needed() -> None:
    _o0 = st.session_state.get('log_handler')
    _o1 = st.session_state.get('log_prev_handlers')
    if _o0 is not None and _o1 is not None:
        _detach_streamlit_logger(_o0, _o1)
    st.session_state['log_handler'] = None
    st.session_state['log_prev_handlers'] = None

def _render_preview_tab(run: PreparedRun) -> None:
    st.caption('Paste a few log lines to preview anonymization (in-memory; no files written).')
    _o16 = st.container()
    _o17 = st.session_state.get('preview_input') or ''
    _o18 = st.session_state.get('preview_output_value') or ''
    _oa = len(_o17.splitlines()) if _o17 else 0
    _ob = len(_o18.splitlines()) if _o18 else 0
    _o2, _o3, _o4, _o0 = st.columns([1.2, 1.0, 1.0, 5.0])
    _o1 = _o2.button('Anonymize', width='stretch', disabled=bool(st.session_state.get('run_in_progress')), key='preview_anonymize_btn')
    _o5 = _o3.button('Clear', width='stretch', disabled=bool(st.session_state.get('run_in_progress')), key='preview_clear_btn')
    _o10 = _o4.button('Profile', width='stretch', disabled=bool(st.session_state.get('run_in_progress')) or FeatureFlag.profiling not in run.features, key='preview_profile_btn')
    if _o1:
        st.session_state['preview_error'] = ''
        st.session_state['preview_status'] = ''
        try:
            logger.info('ui_preview_clicked', extra={'lines_in': _oa})
            _o14 = preview_anonymization(PreviewAnonymizationRequest(text=_o17, rules_path=run.rules_path, include_builtin_rules=True))
            st.session_state['preview_output_value'] = _o14.anonymized_text
            st.session_state['preview_line_details'] = _o14.line_details
            st.session_state['preview_replacements_by_rule'] = dict(_o14.stats.replacements_by_rule)
            st.session_state['preview_status'] = f'Success. {_o14.lines_in} lines → {_o14.lines_out} lines ({_o14.stats.total_replacements} replacements).'
            _o18 = st.session_state['preview_output_value']
            _ob = len(_o18.splitlines()) if _o18 else 0
        except Exception as exc:
            logger.exception('ui_preview_failed', extra={'error': str(_o8)})
            st.session_state['preview_error'] = f'{type(_o8).__name__}: {_o8}'
    if _o10:
        if FeatureFlag.profiling not in run.features:
            st.session_state['preview_error'] = 'Profiling requires a Pro license.'
            return
        st.session_state['preview_error'] = ''
        try:
            _o11 = SensitiveDataProfiler(config=ProfilingConfig(detectors=('email', 'ipv4', 'token', 'card')))
            _o13 = _o11.profile_text(_o17, source_name='<preview>')
            st.session_state['preview_profile_report'] = _o13.to_json()
            st.session_state['preview_suggested_rules'] = json.dumps(_o13.suggested_rules, ensure_ascii=False, indent=2) + '\n'
        except Exception as exc:
            logger.exception('ui_preview_profile_failed', extra={'error': str(_o8)})
            st.session_state['preview_error'] = f'{type(_o8).__name__}: {_o8}'
    if _o5:
        st.session_state['preview_input'] = ''
        st.session_state['preview_output_value'] = ''
        st.session_state['preview_status'] = ''
        st.session_state['preview_error'] = ''
        st.session_state['preview_profile_report'] = ''
        st.session_state['preview_suggested_rules'] = ''
        st.session_state['preview_line_details'] = ()
        st.session_state['preview_replacements_by_rule'] = {}
        st.rerun()
    with _o16:
        if st.session_state.get('preview_status'):
            st.success(st.session_state['preview_status'])
        if st.session_state.get('preview_error'):
            st.error(st.session_state['preview_error'])
    st.text_area('Input (raw logs)', key='preview_input', height=260, placeholder='Paste a few lines here…')
    st.markdown('\n        <style>\n          div.da-preview-wrap {\n            border-radius: 10px;\n            border: 1px solid rgba(120, 120, 140, 0.25);\n            background: rgba(248, 249, 251, 1.0);\n            padding: 10px 12px;\n            max-height: 360px;\n            overflow: auto;\n          }\n          div.da-preview {\n            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;\n            font-size: 13px;\n            line-height: 1.38;\n            margin: 0;\n          }\n          div.da-line {\n            display: flex;\n            gap: 8px;\n            align-items: flex-start;\n          }\n          span.da-mark {\n            display: inline-block;\n            width: 16px;\n            opacity: 0.45;\n            flex: 0 0 16px;\n          }\n          span.da-mark-on {\n            opacity: 1.0;\n            font-weight: 700;\n          }\n          span.da-text {\n            /* Keep explicit line breaks (one log line per line), but allow wrapping for long lines. */\n            white-space: pre-wrap;\n            word-break: break-word;\n            flex: 1 1 auto;\n          }\n          span.da-hl {\n            background: rgba(255, 208, 77, 0.55);\n            border-bottom: 2px solid rgba(176, 106, 0, 0.95);\n            border-radius: 4px;\n            padding: 0 2px;\n          }\n          @media (prefers-color-scheme: dark) {\n            div.da-preview-wrap {\n              background: rgba(255, 255, 255, 0.04);\n              border-color: rgba(255, 255, 255, 0.10);\n            }\n            span.da-hl {\n              background: rgba(0, 169, 255, 0.35);\n              border-bottom: 2px solid rgba(0, 169, 255, 0.95);\n            }\n            span.da-mark-on {\n              color: rgba(0, 169, 255, 0.95);\n            }\n          }\n        </style>\n        ', unsafe_allow_html=True)
    _of = st.tabs(['Output (highlighted)', 'Output (plain text)'])
    with _of[0]:
        st.caption('Legend: highlighted text = anonymized content')
        _o7: tuple[PreviewLineDetail, ...] = st.session_state.get('preview_line_details') or ()
        if _o7:
            st.markdown(_render_highlighted_preview(_o7), unsafe_allow_html=True)
        else:
            st.info('Run a preview to see highlighted output.')
    with _of[1]:
        st.code(_o18 or '', language='text')
    _oc, _od, _oe = st.columns(3)
    _oc.metric('Input lines', _oa)
    _od.metric('Output lines', _ob)
    _oe.metric('User rules', _preview_rules_count(run))
    _o12 = st.session_state.get('preview_replacements_by_rule') or {}
    if _o12:
        with st.expander('Triggered rules (preview)', expanded=False):
            _o15 = [{'rule': _o9, 'replacements': _o19} for _o9, _o19 in sorted(_o12.items(), key=lambda kv: (-kv[1], kv[0]))]
            st.dataframe(pd.DataFrame(_o15), hide_index=True, use_container_width=True)
    if st.session_state.get('preview_profile_report'):
        with st.expander('Sensitive-data profiling report (preview)', expanded=False):
            st.code(st.session_state['preview_profile_report'], language='json')
    if st.session_state.get('preview_suggested_rules'):
        with st.expander('Suggested rules (preview)', expanded=False):
            st.code(st.session_state['preview_suggested_rules'], language='json')
    if _o18:
        _o6 = json.dumps(_o18)
        components.html(f'\n            <div style="display:flex; gap:8px; align-items:center; margin-top: 8px;">\n              <button\n                style="padding:6px 10px; border-radius:6px; border:1px solid #bbb; cursor:pointer;"\n                onclick="navigator.clipboard.writeText({_o6});"\n              >\n                Copy result\n              </button>\n              <span style="opacity:0.7; font-size: 12px;">Copies to clipboard (if allowed by your browser).</span>\n            </div>\n            ', height=44)

def _render_highlighted_preview(details: tuple[PreviewLineDetail, ...]) -> str:
    """
    Render the anonymized output with changed segments highlighted.

    Uses HTML, but escapes all user content to avoid unsafe rendering.
    """

    def _hl_line(text: str, spans) -> str:
        if not spans:
            return html.escape(text)
        _o2: list[str] = []
        _o1 = 0
        for _o3 in spans:
            _o4 = max(0, min(int(_o3.start), len(text)))
            _o0 = max(_o4, min(int(_o3.end), len(text)))
            _o2.append(html.escape(text[_o1:_o4]))
            _o2.append(f'<span class="da-hl" title="Anonymized">{html.escape(text[_o4:_o0])}</span>')
            _o1 = _o0
        _o2.append(html.escape(text[_o1:]))
        return ''.join(_o2)
    _o2: list[str] = []
    for _o1 in details:
        _o4 = 'da-mark da-mark-on' if _o1.changed_spans else 'da-mark'
        _o3 = f'<span class="{_o4}" title="Line changed">▍</span>'
        _o5 = f'<span class="da-text">{_hl_line(_o1.anonymized, _o1.changed_spans)}</span>'
        _o2.append(f'<div class="da-line">{_o3}{_o5}</div>')
    _o0 = '\n'.join(_o2)
    return f'<div class="da-preview-wrap"><div class="da-preview">{_o0}</div></div>'

def _preview_rules_count(run: PreparedRun) -> int:
    try:
        _o0 = load_rules(run.rules_path) if run.rules_path and run.rules_path.exists() else []
    except Exception:
        _o0 = []
    return len(_o0)

def _write_default_rules_file(tmp_dir: Path) -> Path:
    """
    Create a minimal rules.json file so users can run with built-in rules only.
    """
    _o0 = (tmp_dir / 'rules.json').resolve()
    if _o0.exists():
        return _o0
    _o0.write_text('{"version": 1, "rules": []}\n', encoding='utf-8')
    return _o0

def _ensure_rules_editor_initialized() -> None:
    if st.session_state.get('rules_editor_df_v1') is None:
        st.session_state['rules_editor_df_v1'] = pd.DataFrame(columns=['description', 'trigger', 'search', 'replace', 'caseSensitive'])
    if st.session_state.get('rules_editor_df_v2') is None:
        st.session_state['rules_editor_df_v2'] = pd.DataFrame(columns=['description', 'trigger', 'search', 'action', 'caseSensitive'])
    if st.session_state.get('rules_editor_mode') not in ('table_v1', 'table_v2', 'json'):
        st.session_state['rules_editor_mode'] = 'table_v1'
    if st.session_state.get('rules_editor_mode_radio') not in ('Table (v1)', 'Table (v2)', 'JSON (v1/v2)'):
        st.session_state['rules_editor_mode_radio'] = _label_for_rules_editor_mode(st.session_state['rules_editor_mode'])
    if st.session_state.get('rules_editor_text') is None:
        _o0 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_text'] = _o0.decode('utf-8')
    if st.session_state.get('rules_editor_json_widget') is None:
        st.session_state['rules_editor_json_widget'] = st.session_state['rules_editor_text']

def _label_for_rules_editor_mode(mode: str) -> str:
    if mode == 'table_v2':
        return 'Table (v2)'
    if mode == 'json':
        return 'JSON (v1/v2)'
    return 'Table (v1)'

def _mode_for_rules_editor_label(label: str) -> str:
    if label == 'Table (v2)':
        return 'table_v2'
    if label == 'JSON (v1/v2)':
        return 'json'
    return 'table_v1'

def _sync_rules_editor_json_from_tables() -> None:
    _o0 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
    _o1 = _o0.decode('utf-8')
    st.session_state['rules_editor_text'] = _o1

def _on_add_rule_clicked() -> None:
    _ensure_rules_editor_initialized()
    _o1 = st.session_state.get('rules_editor_mode_radio') or _label_for_rules_editor_mode(st.session_state.get('rules_editor_mode', 'table_v1'))
    _o2 = _mode_for_rules_editor_label(str(_o1))
    if _o2 == 'json':
        return
    if _o2 == 'table_v2':
        _o0 = st.session_state['rules_editor_df_v2']
        _o0 = pd.concat([_o0, pd.DataFrame([{'description': '', 'trigger': '', 'search': '', 'action': '{"type":"redaction"}', 'caseSensitive': ''}])], ignore_index=True)
        st.session_state['rules_editor_df_v2'] = _o0
    else:
        _o0 = st.session_state['rules_editor_df_v1']
        _o0 = pd.concat([_o0, pd.DataFrame([{'description': '', 'trigger': '', 'search': '', 'replace': '', 'caseSensitive': ''}])], ignore_index=True)
        st.session_state['rules_editor_df_v1'] = _o0
    _sync_rules_editor_json_from_tables()

def _on_reset_rules_clicked() -> None:
    _ensure_rules_editor_initialized()
    st.session_state['rules_editor_df_v1'] = pd.DataFrame(columns=['description', 'trigger', 'search', 'replace', 'caseSensitive'])
    st.session_state['rules_editor_df_v2'] = pd.DataFrame(columns=['description', 'trigger', 'search', 'action', 'caseSensitive'])
    st.session_state['rules_editor_mode'] = 'table_v1'
    st.session_state['rules_editor_mode_radio'] = 'Table (v1)'
    _sync_rules_editor_json_from_tables()
    st.session_state['rules_upload_sig'] = None

def _ensure_exclude_editor_initialized() -> None:
    if st.session_state.get('exclude_editor_df') is not None:
        return
    st.session_state['exclude_editor_df'] = pd.DataFrame(columns=['pattern'])

def _sig(name: str, raw: bytes) -> str:
    _o0 = hashlib.sha256()
    _o0.update(name.encode('utf-8', errors='ignore'))
    _o0.update(b'\x00')
    _o0.update(raw[:65536])
    return _o0.hexdigest()

def _rules_df_to_json_bytes(df: 'pd.DataFrame') -> bytes:
    _o7: list[dict[str, Any]] = []
    for _o0, _o5 in df.iterrows():
        _o2 = str(_o5.get('description') or '').strip()
        _o9 = str(_o5.get('trigger') or '').strip()
        _o8 = str(_o5.get('search') or '').strip()
        _o4 = str(_o5.get('replace') or '')
        _o1 = _o5.get('caseSensitive')
        if not _o9 and (not _o8) and (_o4 == '') and (not _o2):
            continue
        _o6: dict[str, Any] = {'description': _o2, 'trigger': _o9, 'search': _o8, 'replace': _o4}
        if _o1 is not None and str(_o1).strip() != '':
            _o6['caseSensitive'] = _o1
        _o7.append(_o6)
    _o3 = {'version': 1, 'rules': _o7}
    return (json.dumps(_o3, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def _rules_dfs_to_json_bytes(df_v1: 'pd.DataFrame', df_v2: 'pd.DataFrame') -> bytes:
    _o9: list[dict[str, Any]] = []
    for _o0, _o7 in df_v1.iterrows():
        _o4 = str(_o7.get('description') or '').strip()
        _ob = str(_o7.get('trigger') or '').strip()
        _oa = str(_o7.get('search') or '').strip()
        _o6 = str(_o7.get('replace') or '')
        _o3 = _o7.get('caseSensitive')
        if not _ob and (not _oa) and (_o6 == '') and (not _o4):
            continue
        _o8: dict[str, Any] = {'description': _o4, 'trigger': _ob, 'search': _oa, 'replace': _o6}
        if _o3 is not None and str(_o3).strip() != '':
            _o8['caseSensitive'] = _o3
        _o9.append(_o8)
    for _o0, _o7 in df_v2.iterrows():
        _o4 = str(_o7.get('description') or '').strip()
        _ob = str(_o7.get('trigger') or '').strip()
        _oa = str(_o7.get('search') or '').strip()
        _o2 = str(_o7.get('action') or '').strip()
        _o3 = _o7.get('caseSensitive')
        if not _ob and (not _oa) and (not _o2) and (not _o4):
            continue
        _o1: Any
        if not _o2:
            _o1 = None
        else:
            try:
                _o1 = json.loads(_o2)
            except Exception:
                _o1 = _o2
        _o8 = {'description': _o4, 'trigger': _ob, 'search': _oa, 'action': _o1}
        if _o3 is not None and str(_o3).strip() != '':
            _o8['caseSensitive'] = _o3
        _o9.append(_o8)
    _oc = 2 if any((isinstance(r, dict) and r.get('action') is not None for r in _o9)) else 1
    _o5 = {'version': _oc, 'rules': _o9}
    return (json.dumps(_o5, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

def _write_rules_from_editor(tmp_dir: Path) -> Path:
    _ensure_rules_editor_initialized()
    _o1 = st.session_state.get('rules_editor_mode', 'table')
    if _o1 == 'json':
        _o4 = str(st.session_state.get('rules_editor_json_widget') or st.session_state.get('rules_editor_text') or '')
        _o2 = _o4.encode('utf-8')
    else:
        _o2 = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], st.session_state['rules_editor_df_v2'])
    _o0 = _validate_rules_json_bytes(_o2)
    if _o0:
        st.session_state['ui_errors'].append(f'Rules editor invalid: {_o0}')
        _o2 = b'{"version": 1, "rules": []}\n'
    _o3 = (tmp_dir / 'rules.json').resolve()
    _o3.write_bytes(_o2)
    return _o3

def _exclude_df_to_text(df: 'pd.DataFrame') -> str:
    _o2: list[str] = []
    for _o0, _o3 in df.iterrows():
        _o1 = str(_o3.get('pattern') or '').strip()
        if not _o1 or _o1.startswith('#'):
            continue
        _o2.append(_o1)
    return '\n'.join(_o2) + ('\n' if _o2 else '')

def _exclude_editor_has_patterns() -> bool:
    _ensure_exclude_editor_initialized()
    _o1 = st.session_state['exclude_editor_df']
    if _o1 is None or _o1.empty:
        return False
    for _o0, _o3 in _o1.iterrows():
        _o2 = str(_o3.get('pattern') or '').strip()
        if _o2 and (not _o2.startswith('#')):
            return True
    return False

def _write_exclude_from_editor(tmp_dir: Path) -> Path | None:
    _ensure_exclude_editor_initialized()
    _o0 = st.session_state['exclude_editor_df']
    _o4 = _exclude_df_to_text(_o0)
    _o2 = _o4.encode('utf-8')
    _o1 = _validate_exclude_bytes(_o2, filename='.exclude')
    if _o1:
        st.session_state['ui_errors'].append(f'Exclude editor invalid: {_o1}')
        return None
    _o3 = (tmp_dir / '.exclude').resolve()
    _o3.write_bytes(_o2)
    return _o3

def _maybe_load_rules_upload_into_editor(raw: bytes, *, name: str) -> None:
    _o7 = _sig(name, raw)
    if st.session_state.get('rules_upload_sig') == _o7:
        _o0 = st.session_state.get('rules_editor_df_v1')
        _o1 = st.session_state.get('rules_editor_df_v2')
        _o8 = st.session_state.get('rules_editor_text')
        if isinstance(_o0, pd.DataFrame) and isinstance(_o1, pd.DataFrame) and (not _o0.empty or not _o1.empty) and isinstance(_o8, str) and _o8.strip():
            return
    st.session_state['rules_upload_sig'] = _o7
    try:
        _o2 = json.loads(raw.decode('utf-8'))
    except Exception:
        return
    _o6 = _o2.get('rules') if isinstance(_o2, dict) else None
    if not isinstance(_o6, list):
        return
    _oa = _o2.get('version', 1) if isinstance(_o2, dict) else 1
    try:
        _o9 = int(_oa)
    except Exception:
        _o9 = 1
    _o4: list[dict[str, Any]] = []
    _o5: list[dict[str, Any]] = []
    for _o3 in _o6:
        if not isinstance(_o3, dict):
            continue
        if _o3.get('action') is not None:
            _o5.append({'description': _o3.get('description', ''), 'trigger': _o3.get('trigger', ''), 'search': _o3.get('search', ''), 'action': json.dumps(_o3.get('action'), ensure_ascii=False), 'caseSensitive': _o3.get('caseSensitive', '')})
        else:
            _o4.append({'description': _o3.get('description', ''), 'trigger': _o3.get('trigger', ''), 'search': _o3.get('search', ''), 'replace': _o3.get('replace', ''), 'caseSensitive': _o3.get('caseSensitive', '')})
    st.session_state['rules_editor_df_v1'] = pd.DataFrame(_o4, columns=['description', 'trigger', 'search', 'replace', 'caseSensitive'])
    st.session_state['rules_editor_df_v2'] = pd.DataFrame(_o5, columns=['description', 'trigger', 'search', 'action', 'caseSensitive'])
    try:
        st.session_state['rules_editor_text'] = json.dumps(_o2, ensure_ascii=False, indent=2) + '\n'
    except Exception:
        st.session_state['rules_editor_text'] = raw.decode('utf-8', errors='replace')
    st.session_state['rules_editor_json_widget'] = st.session_state['rules_editor_text']
    if _o9 == 2 or _o5:
        st.session_state['rules_editor_mode'] = 'table_v2' if _o5 else 'table_v1'
    else:
        st.session_state['rules_editor_mode'] = 'table_v1'
    st.session_state['rules_editor_mode_radio'] = _label_for_rules_editor_mode(st.session_state['rules_editor_mode'])

def _maybe_load_exclude_upload_into_editor(raw: bytes, *, name: str) -> None:
    _o3 = _sig(name, raw)
    if st.session_state.get('exclude_upload_sig') == _o3:
        return
    st.session_state['exclude_upload_sig'] = _o3
    try:
        _o4 = raw.decode('utf-8')
    except Exception:
        return
    _o1: list[dict[str, Any]] = []
    for _o0 in _o4.splitlines():
        _o2 = _o0.strip()
        if not _o2 or _o2.startswith('#'):
            continue
        _o1.append({'pattern': _o2})
    st.session_state['exclude_editor_df'] = pd.DataFrame(_o1, columns=['pattern'])

def _render_rules_editor() -> None:
    _ensure_rules_editor_initialized()
    st.caption('Edit rules that will be applied in addition to built-in rules.')
    _o7 = st.session_state.get('license_features', frozenset())
    _o1 = FeatureFlag.advanced_rules in _o7
    _o9 = ['Table (v1)', 'Table (v2)', 'JSON (v1/v2)'] if _o1 else ['Table (v1)', 'JSON (v1/v2)']
    if not _o1 and st.session_state.get('rules_editor_mode') == 'table_v2':
        st.session_state['rules_editor_mode'] = 'table_v1'
        st.session_state['rules_editor_mode_radio'] = 'Table (v1)'
    _o4 = _label_for_rules_editor_mode(st.session_state.get('rules_editor_mode', 'table_v1'))
    if st.session_state.get('rules_editor_mode_radio') not in _o9:
        st.session_state['rules_editor_mode_radio'] = _o4

    def _on_rules_editor_mode_changed() -> None:
        _o0 = st.session_state.get('rules_editor_mode_radio') or 'Table (v1)'
        st.session_state['rules_editor_mode'] = _mode_for_rules_editor_label(str(_o0))
        if st.session_state['rules_editor_mode'] == 'json':
            st.session_state['rules_editor_json_widget'] = str(st.session_state.get('rules_editor_text') or '')
    _o8 = st.radio('Editor mode', options=_o9, key='rules_editor_mode_radio', horizontal=True, on_change=_on_rules_editor_mode_changed)
    st.session_state['rules_editor_mode'] = _mode_for_rules_editor_label(_o8)
    _o2, _o3, _o0 = st.columns([1.2, 1.2, 6])
    _o2.button('Add rule', key='add_rule', disabled=st.session_state['rules_editor_mode'] == 'json', on_click=_on_add_rule_clicked)
    _o3.button('Reset rules', key='reset_rules', on_click=_on_reset_rules_clicked)
    if st.session_state['rules_editor_mode'] == 'table_v1':
        _o5 = st.data_editor(st.session_state['rules_editor_df_v1'], key='rules_editor_v1', num_rows='dynamic', width='stretch', column_config={'description': st.column_config.TextColumn('description'), 'trigger': st.column_config.TextColumn('trigger'), 'search': st.column_config.TextColumn('search (regex)'), 'replace': st.column_config.TextColumn('replace'), 'caseSensitive': st.column_config.TextColumn('caseSensitive')})
        st.session_state['rules_editor_df_v1'] = _o5
        _oa = _rules_dfs_to_json_bytes(_o5, st.session_state['rules_editor_df_v2'])
        st.session_state['rules_editor_text'] = _oa.decode('utf-8')
    elif st.session_state['rules_editor_mode'] == 'table_v2':
        _o5 = st.data_editor(st.session_state['rules_editor_df_v2'], key='rules_editor_v2', num_rows='dynamic', width='stretch', column_config={'description': st.column_config.TextColumn('description'), 'trigger': st.column_config.TextColumn('trigger'), 'search': st.column_config.TextColumn('search (regex)'), 'action': st.column_config.TextColumn('action (JSON)'), 'caseSensitive': st.column_config.TextColumn('caseSensitive')})
        st.session_state['rules_editor_df_v2'] = _o5
        _oa = _rules_dfs_to_json_bytes(st.session_state['rules_editor_df_v1'], _o5)
        st.session_state['rules_editor_text'] = _oa.decode('utf-8')
    else:

        def _on_rules_json_changed() -> None:
            st.session_state['rules_editor_text'] = str(st.session_state.get('rules_editor_json_widget') or '')
        if st.session_state.get('rules_editor_json_widget') is None:
            st.session_state['rules_editor_json_widget'] = str(st.session_state.get('rules_editor_text') or '')
        st.text_area('rules.json', key='rules_editor_json_widget', height=320, on_change=_on_rules_json_changed)
        _ob = str(st.session_state.get('rules_editor_json_widget') or '')
        st.session_state['rules_editor_text'] = _ob
        _oa = _ob.encode('utf-8')
    _o6 = _validate_rules_json_bytes(_oa)
    if _o6:
        st.error(f'Rules validation error: {_o6}')
    else:
        st.success('Rules look valid.')
    st.subheader('Preview')
    st.code(_oa.decode('utf-8'), language='json')

def _render_exclude_editor() -> None:
    _ensure_exclude_editor_initialized()
    st.caption('Edit exclude patterns (glob style).')
    _o1, _o2, _o0 = st.columns([1.3, 1.3, 6])
    if _o1.button('Add pattern', key='add_pattern'):
        _o3 = st.session_state['exclude_editor_df']
        _o3 = pd.concat([_o3, pd.DataFrame([{'pattern': ''}])], ignore_index=True)
        st.session_state['exclude_editor_df'] = _o3
        st.rerun()
    if _o2.button('Reset exclude', key='reset_exclude'):
        st.session_state['exclude_editor_df'] = pd.DataFrame(columns=['pattern'])
        st.rerun()
    _o4 = st.data_editor(st.session_state['exclude_editor_df'], key='exclude_editor', num_rows='dynamic', width='stretch', column_config={'pattern': st.column_config.TextColumn('pattern')})
    st.session_state['exclude_editor_df'] = _o4
    _o7 = _exclude_df_to_text(_o4)
    _o6 = _o7.encode('utf-8')
    _o5 = _validate_exclude_bytes(_o6, filename='.exclude')
    if _o5:
        st.error(f'Exclude validation error: {_o5}')
    else:
        st.success('Exclude file looks valid.')
    st.subheader('Preview')
    st.code(_o7 or '# (no exclude patterns)\n', language='text')

def _looks_like_json(raw: bytes) -> bool:
    _o0 = raw.lstrip()[:2]
    if not _o0 or _o0[:1] not in (b'{', b'['):
        return False
    try:
        json.loads(raw.decode('utf-8'))
        return True
    except Exception:
        return False

def _validate_rules_json_bytes(raw: bytes) -> str | None:
    return validate_rules_json_bytes(raw)

def _validate_exclude_bytes(raw: bytes, *, filename: str) -> str | None:
    """
    Validate that uploaded exclude file is plausible text.

    Heuristics:
    - Must not look like JSON
    - Must be UTF-8 decodable
    - Must not contain NUL bytes
    - Each non-comment line is treated as a glob pattern
    """
    if b'\x00' in raw:
        return 'file looks binary (contains NUL bytes)'
    if _looks_like_json(raw) or filename.lower().endswith('.json'):
        return 'file looks like JSON; did you upload rules.json by mistake?'
    try:
        _o4 = raw.decode('utf-8')
    except UnicodeDecodeError:
        return 'file is not valid UTF-8 text'
    _o1 = _o4.splitlines()
    _o2 = []
    for _o0 in _o1:
        _o3 = _o0.strip()
        if not _o3 or _o3.startswith('#'):
            continue
        _o2.append(_o3)
        if len(_o3) > 512:
            return 'a pattern line is too long (>512 chars)'
    if not _o2:
        st.session_state['ui_warnings'].append('Exclude file contains no patterns (only comments/blank lines).')
    return None
if __name__ == '__main__':
    main()
