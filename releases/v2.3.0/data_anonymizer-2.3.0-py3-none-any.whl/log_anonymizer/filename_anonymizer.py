from __future__ import annotations
import hashlib
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from log_anonymizer.rules_loader import Rule
from log_anonymizer.rule_actions import ActionContext
logger = logging.getLogger(__name__)
_INVALID_FILENAME_CHARS_RE = re.compile('[<>:"/\\\\|?*\\x00-\\x1F]')

@dataclass(frozen=True)
class FilenameAnonymizationResult:
    """
    Result of anonymizing relative paths for output-only rewriting.

    - `mapping` is keyed by the original relative path (POSIX string) and maps to a new relative `Path`.
    - `changed_paths` counts how many paths changed (any segment renamed, including collision suffix).
    - `collisions` counts how many output-name collisions were detected and resolved deterministically.
    """
    mapping: dict[str, Path]
    changed_paths: int
    collisions: int

def anonymize_output_relative_paths(rel_paths: Iterable[Path], rules: Iterable[Rule], *, action_context: ActionContext | None=None, preserve_extensions: bool=True, collision_hash_len: int=8, max_segment_length: int=180) -> FilenameAnonymizationResult:
    """
    Build a deterministic mapping from input relative paths to output relative paths.

    Strategy:
    - Apply the existing rules engine to each *path segment* (directory names and file names).
    - Preserve file extensions by applying rules to the "base name" and re-attaching suffixes.
    - Sanitize output segments to avoid invalid names (Windows-safe).
    - Resolve collisions by appending a deterministic suffix derived from a stable hash of the original path.

    Notes:
    - This is output-only; callers should apply it when writing anonymized output.
    - Logging is intentionally summarized; per-path mapping is DEBUG-only.
    """
    _o13 = list(rules)
    _o7 = action_context or ActionContext()
    _oa: dict[str, Path] = {}
    _o3 = 0
    _o6 = 0
    _o16: dict[tuple[str, ...], set[str]] = {}
    _o14: dict[tuple[tuple[str, ...], str, bool], str] = {}
    _o10 = list(rel_paths)
    _o10.sort(key=lambda p: p.as_posix())
    for _of in _o10:
        _o11 = _of.as_posix()
        _ob: list[str] = []
        _o5 = False
        for _o8, _oe in enumerate(_of.parts):
            _o9 = _o8 == len(_of.parts) - 1
            _od = tuple(_ob)
            _o0 = (_od, _oe, _o9)
            _o1 = _o14.get(_o0)
            if _o1 is None:
                _o2, _o4 = _anonymize_segment(_oe, _o13, _o7, preserve_extensions=preserve_extensions if _o9 else False, max_length=max_segment_length)
                _o5 = _o5 or _o4
                _o15 = _o16.setdefault(_od, set())
                _o12 = _o2
                if _o12 in _o15:
                    _o6 += 1
                    _o12 = _with_collision_suffix(_o2, original_rel=_o11, salt=_o7.salt or '', is_file=_o9, preserve_extensions=preserve_extensions if _o9 else False, hash_len=collision_hash_len, max_length=max_segment_length)
                    _o5 = True
                _o15.add(_o12)
                _o14[_o0] = _o12
                _o1 = _o12
            _ob.append(_o1)
        _oc = Path(*_ob)
        if _o5:
            _o3 += 1
            logger.debug('filename_anonymized', extra={'rel_in': _o11, 'rel_out': _oc.as_posix()})
        _oa[_o11] = _oc
    logger.info('filename_anonymization_summary', extra={'paths': len(_o10), 'changed': _o3, 'collisions': _o6})
    return FilenameAnonymizationResult(mapping=_oa, changed_paths=_o3, collisions=_o6)

def _apply_rules_to_string(s: str, rules_list: list[Rule], ctx: ActionContext, *, trigger_view: str | None=None) -> tuple[str, int]:
    _o3 = s
    _o6 = 0
    _o7 = _o3 if trigger_view is None else trigger_view
    for _o5 in rules_list:
        if not _o5.triggered_by(_o7):
            continue
        _o1 = _o5.description or _o5.trigger or _o5.regex.pattern
        _o0 = _o5.action
        if _o0 is None:
            raise RuntimeError(f'Rule action missing for {_o1!r}')
        _o4 = _o0.as_replacement(context=ctx, rule_key=_o1)
        _o3, _o2 = _o5.regex.subn(_o4, _o3)
        _o6 += int(_o2)
        _o7 = _o3 if trigger_view is None else _o7
    return (_o3, _o6)

def _split_base_and_suffixes(name: str) -> tuple[str, str]:
    """
    Split a filename into base and suffix part (all suffixes preserved).
    Examples:
      - "a.log" -> ("a", ".log")
      - "archive.tar.gz" -> ("archive", ".tar.gz")
      - ".env" -> (".env", "")
      - ".env.production" -> (".env", ".production")
    """
    _o0 = Path(name)
    _o1 = ''.join(_o0.suffixes)
    if not _o1:
        return (name, '')
    return (name[:-len(_o1)], _o1)

def _sanitize_segment(seg: str, *, max_length: int) -> str:
    seg = seg.replace('/', '_').replace('\\', '_')
    seg = _INVALID_FILENAME_CHARS_RE.sub('_', seg)
    seg = seg.rstrip(' .')
    if seg in ('', '.', '..'):
        return ''
    if len(seg) > max_length:
        seg = seg[:max_length]
        seg = seg.rstrip(' .')
    return seg

def _short_hash(s: str, *, salt: str, length: int) -> str:
    _o0 = hashlib.sha256()
    if salt:
        _o0.update(salt.encode('utf-8', errors='ignore'))
        _o0.update(b'\x00')
    _o0.update(s.encode('utf-8', errors='ignore'))
    return _o0.hexdigest()[:max(4, int(length))]

def _anonymize_segment(raw: str, rules_list: list[Rule], ctx: ActionContext, *, preserve_extensions: bool, max_length: int) -> tuple[str, bool]:
    if preserve_extensions:
        _o2, _ob = _split_base_and_suffixes(raw)
    else:
        _o2, _ob = (raw, '')
    _o1 = _o2
    _oc = 0
    _od = _o2 + _ob if preserve_extensions else _o2
    for _o9 in rules_list:
        if not _o9.triggered_by(_od):
            continue
        _o4 = _o9.description or _o9.trigger or _o9.regex.pattern
        _o0 = _o9.action
        if _o0 is None:
            raise RuntimeError(f'Rule action missing for {_o4!r}')
        _o8 = _o0.as_replacement(context=ctx, rule_key=_o4)
        _o1, _o5 = _o9.regex.subn(_o8, _o1)
        _oc += int(_o5)
        _od = _o1 + _ob if preserve_extensions else _o1
    _o3 = _o1 != _o2 or _oc > 0
    _oa = _sanitize_segment(_o1, max_length=max_length)
    if not _oa:
        _oa = f"anon_{_short_hash(raw, salt=ctx.salt or '', length=12)}"
        _o3 = True
    _o6 = _oa + _ob
    _o7 = _sanitize_segment(_o6, max_length=max_length)
    if _o7 and _o7 != _o6:
        _o6 = _o7
        _o3 = True
    return (_o6, _o3)

def _with_collision_suffix(candidate: str, *, original_rel: str, salt: str, is_file: bool, preserve_extensions: bool, hash_len: int, max_length: int) -> str:
    _o4 = '__' + _short_hash(original_rel, salt=salt, length=hash_len)
    if is_file and preserve_extensions:
        _o0, _o1 = _split_base_and_suffixes(candidate)
        _o2 = max(1, max_length - len(_o1) - len(_o4))
        _o0 = _o0[:_o2].rstrip(' .')
        _o3 = f'{_o0}{_o4}{_o1}'
    else:
        _o2 = max(1, max_length - len(_o4))
        _o0 = candidate[:_o2].rstrip(' .')
        _o3 = f'{_o0}{_o4}'
    _o3 = _sanitize_segment(_o3, max_length=max_length) or f'anon_{_short_hash(original_rel, salt=salt, length=12)}'
    return _o3
