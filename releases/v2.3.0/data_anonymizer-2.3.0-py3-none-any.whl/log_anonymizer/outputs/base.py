from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, TypeVar
TArtifact = TypeVar('TArtifact')

class OutputWriter(ABC, Generic[TArtifact]):
    """
    Persists a transformed artifact to the filesystem.

    Writers should strive to be atomic where possible (e.g., temp file + replace).
    """

    @abstractmethod
    def write(self, artifact: TArtifact, dest_path: Path) -> None:
        ...
