from __future__ import annotations
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from log_anonymizer.analyzers.pdf_analyzer import PdfAnalysis
from log_anonymizer.outputs.base import OutputWriter
from log_anonymizer.transformers.pdf_redactor import PdfRedactionArtifact

@dataclass(frozen=True)
class PdfWriteResult:
    pdf_path: Path
    summary_path: Path
    analysis: PdfAnalysis

class PdfWriter(OutputWriter[PdfRedactionArtifact]):

    def write(self, artifact: PdfRedactionArtifact, dest_path: Path) -> None:
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        _o0 = artifact.analysis
        if not _o0.has_extractable_text:
            pass
        _o2, _o3 = tempfile.mkstemp(prefix=f'.{dest_path.name}.', suffix='.tmp', dir=str(dest_path.parent))
        os.close(_o2)
        _o4 = Path(_o3)
        try:
            _save_pdf(artifact.document, _o4)
            os.replace(_o4, dest_path)
        finally:
            try:
                if _o4.exists():
                    _o4.unlink()
            except OSError:
                pass
        _o1 = _summary_path_for(dest_path)
        _write_summary(_o1, _o0)

def _save_pdf(document: Any, path: Path) -> None:
    document.save(str(path), garbage=4, deflate=True)

def _summary_path_for(pdf_path: Path) -> Path:
    return pdf_path.with_suffix(pdf_path.suffix + '.redaction_summary.json')

def _write_summary(path: Path, analysis: PdfAnalysis) -> None:
    _o0 = {'format': 'pdf', 'has_extractable_text': analysis.has_extractable_text, 'pages_affected': list(analysis.pages_affected), 'redactions_applied': analysis.redactions_applied, 'triggered_rules': list(analysis.triggered_rules)}
    path.write_text(json.dumps(_o0, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
