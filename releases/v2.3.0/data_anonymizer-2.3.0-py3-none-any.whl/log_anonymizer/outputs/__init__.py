from __future__ import annotations

from log_anonymizer.outputs.base import OutputWriter

__all__ = ["OutputWriter"]
