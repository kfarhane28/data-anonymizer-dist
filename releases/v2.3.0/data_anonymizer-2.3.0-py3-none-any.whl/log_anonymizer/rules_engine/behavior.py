from __future__ import annotations
from enum import Enum

class RuleOutputBehavior(str, Enum):
    text_replacement = 'text_replacement'
    pdf_redaction = 'pdf_redaction'
_ALIASES: dict[str, RuleOutputBehavior] = {'text': RuleOutputBehavior.text_replacement, 'replace': RuleOutputBehavior.text_replacement, 'replacement': RuleOutputBehavior.text_replacement, 'text_replacement': RuleOutputBehavior.text_replacement, 'pdf': RuleOutputBehavior.pdf_redaction, 'redact': RuleOutputBehavior.pdf_redaction, 'redaction': RuleOutputBehavior.pdf_redaction, 'pdf_redaction': RuleOutputBehavior.pdf_redaction}

def parse_output_behavior(value: str) -> RuleOutputBehavior:
    _o0 = value.strip().lower()
    if _o0 in _ALIASES:
        return _ALIASES[_o0]
    raise ValueError(f'Unsupported output behavior: {value!r}')
