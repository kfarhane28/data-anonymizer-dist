from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING, Iterable, Iterator
from log_anonymizer.rules_engine.behavior import RuleOutputBehavior
from log_anonymizer.rules_engine.ordering import order_rules_for_evaluation
if TYPE_CHECKING:
    from log_anonymizer.rules_loader import Rule

def rule_key(rule: Rule) -> str:
    return rule.description or rule.trigger or rule.regex.pattern

@dataclass(frozen=True)
class RuleMatchSpan:
    rule_key: str
    start: int
    end: int

def iter_rule_match_spans(text: str, rules: Iterable['Rule'], *, require_output: RuleOutputBehavior | None=None) -> Iterator[RuleMatchSpan]:
    """
    Shared rule evaluation for matching only (no mutation).

    Used for:
    - PDF redaction workflows (need match spans)
    - future connectors (structured outputs, DB columns, etc.)
    """
    for _o2 in order_rules_for_evaluation(rules):
        if require_output is not None and require_output not in getattr(_o2, 'outputs', frozenset()):
            continue
        if not _o2.triggered_by(text):
            continue
        _o0 = rule_key(_o2)
        for _o1 in _o2.regex.finditer(text):
            if _o1.start() == _o1.end():
                continue
            yield RuleMatchSpan(rule_key=_o0, start=_o1.start(), end=_o1.end())
