from __future__ import annotations
from typing import TYPE_CHECKING, Iterable
if TYPE_CHECKING:
    from log_anonymizer.rules_loader import Rule

def order_rules_for_evaluation(rules: Iterable['Rule']) -> list['Rule']:
    """
    Normalize evaluation order for anonymization rules.

    Precedence:
      1) enabled rules only
      2) higher `priority` first (descending)
      3) tie-break by `original_index` (ascending)
      4) final deterministic tie-break by incoming order

    Backward compatibility:
      - If `priority` is missing everywhere, defaults to 0 and file/incoming order is preserved.
      - If `original_index` is missing/invalid, incoming order is used.
    """
    _o5 = list(rules)
    _o1: list[tuple[int, int, int, 'Rule']] = []
    for _o0, _o4 in enumerate(_o5):
        if not getattr(_o4, 'enabled', True):
            continue
        _o3 = getattr(_o4, 'priority', 0)
        if isinstance(_o3, bool) or not isinstance(_o3, int):
            _o3 = 0
        _o2 = getattr(_o4, 'original_index', _o0)
        if not isinstance(_o2, int):
            _o2 = _o0
        _o1.append((-int(_o3), int(_o2), int(_o0), _o4))
    _o1.sort(key=lambda t: (_o6[0], _o6[1], _o6[2]))
    return [_o6[3] for _o6 in _o1]
