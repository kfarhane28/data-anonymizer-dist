from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from log_anonymizer.anonymizer import anonymize_file as _default_anonymize_file
from log_anonymizer.platform.pipeline import FilePipeline

@dataclass(frozen=True)
class PipelineRegistry:
    pipelines: tuple[FilePipeline, ...]

    def pipeline_for(self, source_path: Path) -> FilePipeline | None:
        for _o0 in self.pipelines:
            if _o0.can_handle(source_path):
                return _o0
        return None

def default_pipeline_registry(*, text_anonymize_file: Callable[..., object]=_default_anonymize_file) -> PipelineRegistry:
    """
    Default pipelines shipped with the product.

    PDF support is optional and only enabled when its extra dependency is installed.
    """
    from log_anonymizer.platform.pipelines.text_file import TextFilePipeline
    _o0: list[FilePipeline] = [TextFilePipeline(anonymize_file=text_anonymize_file)]
    try:
        from log_anonymizer.connectors.pdf import pdf_support_available
        from log_anonymizer.platform.pipelines.pdf_file import PdfFilePipeline
        if pdf_support_available():
            _o0.insert(0, PdfFilePipeline())
    except Exception:
        pass
    return PipelineRegistry(tuple(_o0))
