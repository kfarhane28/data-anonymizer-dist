from __future__ import annotations

from log_anonymizer.platform.pipelines.text_file import TextFilePipeline

__all__ = ["TextFilePipeline"]
