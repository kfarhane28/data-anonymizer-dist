from __future__ import annotations
import os
import shutil
import tempfile
from pathlib import Path
from typing import Iterable
from log_anonymizer.analyzers.pdf_analyzer import PdfAnalyzer
from log_anonymizer.anonymizer import AnonymizationCancelled
from log_anonymizer.connectors.pdf import PdfConnector
from log_anonymizer.outputs.pdf_writer import PdfWriter
from log_anonymizer.platform.pipeline import FilePipeline, PipelineContext, PipelineResult
from log_anonymizer.progress import ProgressKind, ProgressStage, now_event
from log_anonymizer.rules_loader import Rule
from log_anonymizer.transformers.pdf_redactor import PdfRedactor

class PdfFilePipeline(FilePipeline):

    def __init__(self) -> None:
        self._connector = PdfConnector()
        self._analyzer = PdfAnalyzer()
        self._transformer = PdfRedactor()
        self._writer = PdfWriter()

    def can_handle(self, source_path: Path) -> bool:
        return self._connector.can_open(source_path)

    def process_file(self, *, source_path: Path, dest_path: Path, rules: Iterable[Rule], context: PipelineContext | None=None) -> PipelineResult:
        _o2 = context or PipelineContext()
        _o6 = _o2.rel_path or source_path.name
        _o5 = _o2.progress
        _o7: int | None = None
        if _o5 is not None:
            try:
                _o7 = int(source_path.stat().st_size)
            except OSError:
                _o7 = None
            _o5.emit(now_event(kind=ProgressKind.FILE_START, stage=ProgressStage.PROCESSING, path=_o6, bytes_done=0, bytes_total=_o7, message='pdf_start'))
        _o4 = False
        try:
            if _o2.cancel_requested is not None and _o2.cancel_requested():
                raise AnonymizationCancelled('cancelled')
            try:
                with self._connector.open(source_path) as _o3:
                    _o0 = self._analyzer.analyze(_o3, rules)
                    if _o2.cancel_requested is not None and _o2.cancel_requested():
                        raise AnonymizationCancelled('cancelled')
                    _o1 = self._transformer.transform(_o3, _o0)
                    if _o2.cancel_requested is not None and _o2.cancel_requested():
                        raise AnonymizationCancelled('cancelled')
                    self._writer.write(_o1, dest_path)
                    _o4 = True
                    return PipelineResult(source_path=source_path, output_path=dest_path, triggered_rules=_o0.triggered_rules, redactions_applied=_o0.redactions_applied, pages_affected=_o0.pages_affected, skipped_reason=None if _o0.has_extractable_text else 'no_extractable_text')
            except AnonymizationCancelled:
                raise
            except Exception:
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                _copy_file_atomic(source_path, dest_path, cancel_requested=_o2.cancel_requested)
                _o4 = True
                return PipelineResult(source_path=source_path, output_path=dest_path, triggered_rules=(), redactions_applied=0, pages_affected=(), skipped_reason='pdf_open_failed')
        finally:
            if _o5 is not None:
                _o5.emit(now_event(kind=ProgressKind.FILE_END, stage=ProgressStage.PROCESSING, path=_o6, bytes_done=_o7, bytes_total=_o7, ok=_o4, message='pdf_done' if _o4 else 'pdf_failed'))

def _copy_file_atomic(src: Path, dest: Path, *, cancel_requested) -> None:
    _o1, _o2 = tempfile.mkstemp(prefix=f'.{dest.name}.', suffix='.tmp', dir=str(dest.parent))
    os.close(_o1)
    _o0 = Path(_o2)
    try:
        if cancel_requested is not None and cancel_requested():
            raise AnonymizationCancelled('cancelled')
        shutil.copy2(src, _o0)
        if cancel_requested is not None and cancel_requested():
            raise AnonymizationCancelled('cancelled')
        os.replace(_o0, dest)
    finally:
        try:
            if _o0.exists():
                _o0.unlink()
        except OSError:
            pass
