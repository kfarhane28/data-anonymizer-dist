from __future__ import annotations
from pathlib import Path
from typing import Iterable
from typing import Callable
from log_anonymizer.anonymizer import anonymize_file as _default_anonymize_file
from log_anonymizer.platform.pipeline import FilePipeline, PipelineContext, PipelineResult
from log_anonymizer.rules_loader import Rule
from log_anonymizer.utils.io import is_text_file

class TextFilePipeline(FilePipeline):

    def __init__(self, *, anonymize_file: Callable[..., object]=_default_anonymize_file) -> None:
        self._anonymize_file = anonymize_file

    def can_handle(self, source_path: Path) -> bool:
        return is_text_file(source_path)

    def process_file(self, *, source_path: Path, dest_path: Path, rules: Iterable[Rule], context: PipelineContext | None=None) -> PipelineResult:
        _o0 = context or PipelineContext()
        try:
            _o1 = self._anonymize_file(source_path, dest_path, rules, progress=_o0.progress, rel_path=_o0.rel_path, cancel_requested=_o0.cancel_requested, action_context=_o0.action_context)
        except TypeError:
            _o1 = self._anonymize_file(source_path, dest_path, rules)
        return PipelineResult(source_path=getattr(_o1, 'input_path', source_path), output_path=getattr(_o1, 'output_path', dest_path), triggered_rules=tuple(getattr(_o1, 'triggered_rules', ())), replacements_applied=int(getattr(_o1, 'total_replacements', 0)))
