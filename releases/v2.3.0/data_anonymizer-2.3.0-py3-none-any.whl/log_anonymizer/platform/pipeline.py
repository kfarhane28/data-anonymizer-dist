from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable
from log_anonymizer.rules_loader import Rule

@dataclass(frozen=True)
class PipelineContext:
    """
    Cross-cutting context passed to pipelines without hard-coding UI/CLI concerns.
    """
    rel_path: str | None = None
    progress: object | None = None
    cancel_requested: Callable[[], bool] | None = None
    action_context: object | None = None

@dataclass(frozen=True)
class PipelineResult:
    """
    Cross-format summary for a single processed input file.

    For text files, redactions_applied will be 0 and replacements_applied will be >0.
    For PDFs, replacements_applied will be 0 and redactions_applied will be >0.
    """
    source_path: Path
    output_path: Path
    triggered_rules: tuple[str, ...]
    replacements_applied: int = 0
    redactions_applied: int = 0
    pages_affected: tuple[int, ...] = ()
    skipped_reason: str | None = None

class FilePipeline(ABC):
    """
    Format-specific processing for a single input file -> single output file.
    """

    @abstractmethod
    def can_handle(self, source_path: Path) -> bool:
        ...

    @abstractmethod
    def process_file(self, *, source_path: Path, dest_path: Path, rules: Iterable[Rule], context: PipelineContext | None=None) -> PipelineResult:
        ...
