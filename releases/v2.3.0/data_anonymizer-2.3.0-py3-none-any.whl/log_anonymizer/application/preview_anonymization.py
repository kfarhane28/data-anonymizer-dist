from __future__ import annotations
import logging
from dataclasses import dataclass
from pathlib import Path
from log_anonymizer.anonymizer import AnonymizeTextStats, anonymize_text_block
from log_anonymizer.builtin_rules import default_rules, merge_rules
from log_anonymizer.application.preview_highlighting import ChangedSpan, compute_changed_spans
from log_anonymizer.rules_engine import order_rules_for_evaluation
from log_anonymizer.rules_loader import Rule, load_rules
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class PreviewAnonymizationRequest:
    text: str
    rules_path: Path | None = None
    include_builtin_rules: bool = True

@dataclass(frozen=True)
class PreviewAnonymizationResult:
    anonymized_text: str
    lines_in: int
    lines_out: int
    rules_count: int
    stats: AnonymizeTextStats
    line_details: tuple['PreviewLineDetail', ...]

@dataclass(frozen=True)
class PreviewLineDetail:
    original: str
    anonymized: str
    changed_spans: tuple[ChangedSpan, ...]

def preview_anonymization(req: PreviewAnonymizationRequest) -> PreviewAnonymizationResult:
    """
    In-memory anonymization preview for the UI.

    Reuses the same rule loading/merging behavior as the CLI pipeline and the same
    line-by-line anonymization logic as file processing.
    """
    _oc = req.text or ''
    _o6 = _count_lines(_oc)
    _od: list[Rule] = load_rules(req.rules_path) if req.rules_path is not None else []
    _oa = merge_rules(builtin=default_rules(), user=_od) if req.include_builtin_rules else list(_od)
    _o2 = order_rules_for_evaluation(_oa)
    if not _o2:
        raise ValueError('No rules available for preview (provide --rules or enable built-in rules).')
    logger.info('preview_start', extra={'lines_in': _o6, 'rules': len(_o2), 'builtin': bool(req.include_builtin_rules)})
    _o1, _ob = anonymize_text_block(_oc, _o2)
    _o7 = _count_lines(_o1)
    logger.info('preview_done', extra={'lines_in': _o6, 'lines_out': _o7, 'rules': len(_o2), 'replacements': _ob.total_replacements, 'triggered_rules': len(_ob.triggered_rules)})
    _o4 = _oc.splitlines()
    _o9 = _o1.splitlines()
    _o5: list[PreviewLineDetail] = []
    for _o3 in range(max(len(_o4), len(_o9))):
        _o8 = _o4[_o3] if _o3 < len(_o4) else ''
        _o0 = _o9[_o3] if _o3 < len(_o9) else ''
        _o5.append(PreviewLineDetail(original=_o8, anonymized=_o0, changed_spans=compute_changed_spans(_o8, _o0)))
    return PreviewAnonymizationResult(anonymized_text=_o1, lines_in=_o6, lines_out=_o7, rules_count=len(_o2), stats=_ob, line_details=tuple(_o5))

def _count_lines(text: str) -> int:
    if not text:
        return 0
    return len(text.splitlines())
