from __future__ import annotations

from log_anonymizer.connectors.base import Connector, DocumentHandle

__all__ = ["Connector", "DocumentHandle"]
