from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, TypeVar
TDocument = TypeVar('TDocument')

class DocumentHandle(ABC, Generic[TDocument]):
    """
    Context-managed handle for documents that require deterministic cleanup
    (e.g., PDFs / database connections).
    """

    @abstractmethod
    def __enter__(self) -> TDocument:
        ...

    @abstractmethod
    def __exit__(self, exc_type, exc, tb) -> bool | None:
        ...

class Connector(ABC, Generic[TDocument]):
    """
    Opens a source into a typed document representation.

    A connector must be side-effect free: it must not modify the source.
    """

    @abstractmethod
    def can_open(self, source_path: Path) -> bool:
        ...

    @abstractmethod
    def open(self, source_path: Path) -> DocumentHandle[TDocument]:
        ...
