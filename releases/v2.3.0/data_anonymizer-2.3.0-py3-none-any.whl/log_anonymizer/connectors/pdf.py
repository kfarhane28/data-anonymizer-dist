from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from log_anonymizer.connectors.base import Connector, DocumentHandle

def _is_pdf_path(path: Path) -> bool:
    return path.suffix.lower() == '.pdf'

def _import_fitz() -> Any:
    try:
        import fitz
    except Exception as exc:
        raise RuntimeError("PDF support requires the optional dependency 'pymupdf'. Install with: pip install 'data-anonymizer[pdf]'") from _o0
    return fitz

def pdf_support_available() -> bool:
    try:
        _import_fitz()
        return True
    except Exception:
        return False

@dataclass
class PdfDocumentHandle(DocumentHandle[Any]):
    path: Path

    def __enter__(self) -> Any:
        _o0 = _import_fitz()
        self._doc = _o0.open(str(self.path))
        return self._doc

    def __exit__(self, exc_type, exc, tb) -> bool | None:
        _o0 = getattr(self, '_doc', None)
        try:
            if _o0 is not None:
                _o0.close()
        finally:
            self._doc = None
        return None

class PdfConnector(Connector[Any]):

    def can_open(self, source_path: Path) -> bool:
        return _is_pdf_path(source_path)

    def open(self, source_path: Path) -> PdfDocumentHandle:
        if not self.can_open(source_path):
            raise ValueError(f'Not a PDF: {source_path}')
        return PdfDocumentHandle(path=source_path)
