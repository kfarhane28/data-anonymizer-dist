from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable
from log_anonymizer.analyzers.base import Analyzer
from log_anonymizer.rules_engine import RuleOutputBehavior, iter_rule_match_spans, order_rules_for_evaluation
from log_anonymizer.rules_loader import Rule

@dataclass(frozen=True)
class PdfRedactionTarget:
    page_index: int
    x0: float
    y0: float
    x1: float
    y1: float
    rule_key: str

@dataclass(frozen=True)
class PdfAnalysis:
    has_extractable_text: bool
    targets: tuple[PdfRedactionTarget, ...]
    triggered_rules: tuple[str, ...]

    @property
    def redactions_applied(self) -> int:
        return len(self.targets)

    @property
    def pages_affected(self) -> tuple[int, ...]:
        _o0 = sorted({_o1.page_index + 1 for _o1 in self.targets})
        return tuple(_o0)

class PdfAnalyzer(Analyzer[Any, PdfAnalysis]):
    """
    Extracts text from a PDF page-by-page (word boxes) and locates regex matches.

    Notes:
    - Only native-text PDFs are supported. No OCR is performed.
    - Matching is done per-line reconstructed from word boxes. This is sufficient
      for typical PII patterns (emails, IPs, tokens) without needing char-level geometry.
    """

    def analyze(self, document: Any, rules: Iterable[Rule]) -> PdfAnalysis:
        _o9 = order_rules_for_evaluation(rules)
        _ob: list[PdfRedactionTarget] = []
        _oe: set[str] = set()
        _o2 = False
        for _o7 in range(getattr(document, 'page_count', 0)):
            _o6 = document.load_page(_o7)
            _o11 = list(_o6.get_text('words') or [])
            if _o11:
                _o2 = True
            if not _o11:
                continue
            _o11.sort(key=lambda w: (int(_of[5]), int(_of[6]), int(_of[7]), float(_of[0])))
            _o5: dict[tuple[int, int], list[tuple[float, float, float, float, str]]] = {}
            for _of in _o11:
                _o1 = int(_of[5])
                _o3 = int(_of[6])
                _o5.setdefault((_o1, _o3), []).append((float(_of[0]), float(_of[1]), float(_of[2]), float(_of[3]), str(_of[4])))
            for _o0, _o4 in _o5.items():
                _o4.sort(key=lambda w: _of[0])
                _od, _o10 = _line_text_with_spans(_o4)
                if not _od.strip():
                    continue
                for _oa in iter_rule_match_spans(_od, _o9, require_output=RuleOutputBehavior.pdf_redaction):
                    _o8 = _match_rect(_oa.start, _oa.end, _o10)
                    if _o8 is None:
                        continue
                    _oe.add(_oa.rule_key)
                    _ob.append(PdfRedactionTarget(page_index=_o7, x0=_o8[0], y0=_o8[1], x1=_o8[2], y1=_o8[3], rule_key=_oa.rule_key))
        _oc = tuple(_ob)
        return PdfAnalysis(has_extractable_text=bool(_o2), targets=_oc, triggered_rules=tuple(sorted(_oe)))

def _line_text_with_spans(line_words: list[tuple[float, float, float, float, str]]) -> tuple[str, list[tuple[int, int, tuple[float, float, float, float]]]]:
    """
    Returns:
      - reconstructed line text (words separated by single spaces)
      - mapping spans: [(start, end_exclusive, (x0,y0,x1,y1)), ...] for each word
    """
    _o2: list[str] = []
    _o4: list[tuple[int, int, tuple[float, float, float, float]]] = []
    _o3 = 0
    for _o1, (_o7, _o9, _o8, _oa, _o6) in enumerate(line_words):
        if _o1:
            _o2.append(' ')
            _o3 += 1
        _o5 = _o3
        _o2.append(_o6)
        _o3 += len(_o6)
        _o0 = _o3
        _o4.append((_o5, _o0, (_o7, _o9, _o8, _oa)))
    return (''.join(_o2), _o4)

def _match_rect(start: int, end: int, word_spans: list[tuple[int, int, tuple[float, float, float, float]]]) -> tuple[float, float, float, float] | None:
    _o0: list[tuple[float, float, float, float]] = []
    for _o3, _o2, _o1 in word_spans:
        if _o2 <= start or _o3 >= end:
            continue
        _o0.append(_o1)
    if not _o0:
        return None
    _o4 = min((r[0] for r in _o0))
    _o6 = min((r[1] for r in _o0))
    _o5 = max((r[2] for r in _o0))
    _o7 = max((r[3] for r in _o0))
    return (_o4, _o6, _o5, _o7)
