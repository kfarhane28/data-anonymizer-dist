from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Generic, Iterable, TypeVar
from log_anonymizer.rules_loader import Rule
TDocument = TypeVar('TDocument')
TAnalysis = TypeVar('TAnalysis')

class Analyzer(ABC, Generic[TDocument, TAnalysis]):
    """
    Produces analysis results from a document (e.g., matches, redaction targets).
    """

    @abstractmethod
    def analyze(self, document: TDocument, rules: Iterable[Rule]) -> TAnalysis:
        ...
