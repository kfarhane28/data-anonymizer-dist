from __future__ import annotations

from log_anonymizer.analyzers.base import Analyzer

__all__ = ["Analyzer"]
