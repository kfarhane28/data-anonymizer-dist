from __future__ import annotations

from log_anonymizer.transformers.base import Transformer

__all__ = ["Transformer"]
