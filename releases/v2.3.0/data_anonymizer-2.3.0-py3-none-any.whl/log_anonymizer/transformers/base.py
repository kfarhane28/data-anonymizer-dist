from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Generic, TypeVar
TDocument = TypeVar('TDocument')
TAnalysis = TypeVar('TAnalysis')
TTransformed = TypeVar('TTransformed')

class Transformer(ABC, Generic[TDocument, TAnalysis, TTransformed]):
    """
    Applies transformations to a document based on analysis output.
    """

    @abstractmethod
    def transform(self, document: TDocument, analysis: TAnalysis) -> TTransformed:
        ...
